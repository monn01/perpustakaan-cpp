/*************************************************************
 * auth_service.cpp
 * Implementasi Layanan Autentikasi
 *************************************************************/

#include "../../include/auth/auth_service.h"
#include "../../include/auth/session.h"
#include "../../include/core/file_io.h"
#include "../../include/config.h"
#include <iostream>
#include <cstring>
#include <ctime>

namespace LibSystem {

    // ============ AUTHENTICATION ============

    bool AuthService::login(LinkedList<User>& userList, 
                           const char* username, 
                           const char* password) {
        // Cari user dengan username yang cocok
        Node<User>* userNode = findUserByUsername(userList, username);
        
        if (userNode == NULL) {
            return false;  // Username tidak ditemukan
        }
        
        // Cek password
        if (strcmp(userNode->data.password, password) != 0) {
            return false;  // Password salah
        }
        
        // Cek apakah akun aktif
        if (!userNode->data.aktif) {
            std::cout << "[!] Akun Anda telah dinonaktifkan. Hubungi admin.\n";
            return false;
        }
        
        // Login berhasil, set session
        Session::setSession(&(userNode->data));
        return true;
    }

    void AuthService::logout() {
        Session::clearSession();
    }

    // ============ REGISTRATION ============

    bool AuthService::registerUser(LinkedList<User>& userList,
                                  const char* username,
                                  const char* password,
                                  const char* namaLengkap,
                                  const char* noTelp) {
        // Validasi username
        if (!isValidUsername(username)) {
            std::cout << "[!] Username tidak valid! (Min 4 karakter, alfanumerik)\n";
            return false;
        }
        
        // Validasi password
        if (!isValidPassword(password)) {
            std::cout << "[!] Password tidak valid! (Min 6 karakter)\n";
            return false;
        }
        
        // Cek apakah username sudah ada
        if (isUsernameExists(userList, username)) {
            std::cout << "[!] Username sudah digunakan!\n";
            return false;
        }
        
        // Buat user baru
        User newUser;
        newUser.id = FileIO::getNextUserId(userList);
        strncpy(newUser.username, username, MAX_USERNAME - 1);
        strncpy(newUser.password, password, MAX_PASSWORD - 1);
        strncpy(newUser.namaLengkap, namaLengkap, 49);
        strncpy(newUser.role, ROLE_USER, MAX_ROLE - 1);
        strncpy(newUser.noTelp, noTelp, 14);
        newUser.aktif = true;
        
        // Tambah ke list
        userList.pushBack(newUser);
        
        std::cout << "[OK] Registrasi berhasil! Silakan login.\n";
        return true;
    }

    bool AuthService::registerAdmin(LinkedList<User>& userList,
                                   const char* username,
                                   const char* password,
                                   const char* namaLengkap,
                                   const char* noTelp) {
        // Hanya admin yang bisa membuat admin baru
        if (!Session::isAdmin()) {
            std::cout << MSG_ACCESS_DENIED << "\n";
            return false;
        }
        
        // Validasi
        if (!isValidUsername(username) || !isValidPassword(password)) {
            std::cout << "[!] Username atau password tidak valid!\n";
            return false;
        }
        
        if (isUsernameExists(userList, username)) {
            std::cout << "[!] Username sudah digunakan!\n";
            return false;
        }
        
        // Buat admin baru
        User newAdmin;
        newAdmin.id = FileIO::getNextUserId(userList);
        strncpy(newAdmin.username, username, MAX_USERNAME - 1);
        strncpy(newAdmin.password, password, MAX_PASSWORD - 1);
        strncpy(newAdmin.namaLengkap, namaLengkap, 49);
        strncpy(newAdmin.role, ROLE_ADMIN, MAX_ROLE - 1);
        strncpy(newAdmin.noTelp, noTelp, 14);
        newAdmin.aktif = true;
        
        userList.pushBack(newAdmin);
        
        std::cout << "[OK] Admin baru berhasil ditambahkan!\n";
        return true;
    }

    // ============ VALIDATION ============

    bool AuthService::isUsernameExists(LinkedList<User>& userList, 
                                      const char* username) {
        return findUserByUsername(userList, username) != NULL;
    }

    bool AuthService::isValidUsername(const char* username) {
        if (username == NULL) return false;
        
        int len = strlen(username);
        
        // Minimal 4 karakter
        if (len < 4 || len >= MAX_USERNAME) return false;
        
        // Hanya alfanumerik dan underscore
        for (int i = 0; i < len; i++) {
            char c = username[i];
            bool isAlpha = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
            bool isNum = (c >= '0' && c <= '9');
            bool isUnderscore = (c == '_');
            
            if (!isAlpha && !isNum && !isUnderscore) {
                return false;
            }
        }
        
        return true;
    }

    bool AuthService::isValidPassword(const char* password) {
        if (password == NULL) return false;
        
        int len = strlen(password);
        
        // Minimal 6 karakter
        return (len >= 6 && len < MAX_PASSWORD);
    }

    // ============ PASSWORD MANAGEMENT ============

    bool AuthService::changePassword(LinkedList<User>& userList,
                                    const char* oldPassword,
                                    const char* newPassword) {
        if (!Session::isLoggedIn()) {
            std::cout << "[!] Anda belum login!\n";
            return false;
        }
        
        User* currentUser = Session::getCurrentUser();
        
        // Verifikasi password lama
        if (strcmp(currentUser->password, oldPassword) != 0) {
            std::cout << "[!] Password lama salah!\n";
            return false;
        }
        
        // Validasi password baru
        if (!isValidPassword(newPassword)) {
            std::cout << "[!] Password baru tidak valid! (Min 6 karakter)\n";
            return false;
        }
        
        // Update password
        strncpy(currentUser->password, newPassword, MAX_PASSWORD - 1);
        
        std::cout << "[OK] Password berhasil diubah!\n";
        return true;
    }

    bool AuthService::resetPassword(LinkedList<User>& userList,
                                   int userId,
                                   const char* newPassword) {
        // Hanya admin yang bisa reset password
        if (!Session::isAdmin()) {
            std::cout << MSG_ACCESS_DENIED << "\n";
            return false;
        }
        
        // Cari user
        Node<User>* userNode = findUserById(userList, userId);
        
        if (userNode == NULL) {
            std::cout << "[!] User tidak ditemukan!\n";
            return false;
        }
        
        // Validasi password baru
        if (!isValidPassword(newPassword)) {
            std::cout << "[!] Password tidak valid! (Min 6 karakter)\n";
            return false;
        }
        
        // Reset password
        strncpy(userNode->data.password, newPassword, MAX_PASSWORD - 1);
        
        std::cout << "[OK] Password user " << userNode->data.username 
                  << " berhasil direset!\n";
        return true;
    }

    // ============ ACTIVITY LOGGING ============

    void AuthService::logActivity(Stack<SessionLog>& logStack,
                                 const char* aktivitas) {
        if (!Session::isLoggedIn()) return;
        
        SessionLog log;
        log.idUser = Session::getCurrentUserId();
        strncpy(log.username, Session::getCurrentUsername(), MAX_USERNAME - 1);
        strncpy(log.aktivitas, aktivitas, MAX_AKTIVITAS - 1);
        
        // Set waktu
        time_t now = time(0);
        struct tm* timeinfo = localtime(&now);
        strftime(log.waktu, MAX_TANGGAL, "%d-%m-%Y %H:%M:%S", timeinfo);
        
        logStack.push(log);
    }

    // ============ PRIVATE HELPERS ============

    Node<User>* AuthService::findUserByUsername(LinkedList<User>& userList,
                                                const char* username) {
        Node<User>* current = userList.getHead();
        
        while (current != NULL) {
            if (strcmp(current->data.username, username) == 0) {
                return current;
            }
            current = current->next;
        }
        
        return NULL;
    }

    Node<User>* AuthService::findUserById(LinkedList<User>& userList, int id) {
        Node<User>* current = userList.getHead();
        
        while (current != NULL) {
            if (current->data.id == id) {
                return current;
            }
            current = current->next;
        }
        
        return NULL;
    }

}
