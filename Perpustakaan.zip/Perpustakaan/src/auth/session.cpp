/*************************************************************
 * session.cpp
 * Implementasi Manajemen Session
 *************************************************************/

#include "../../include/auth/session.h"
#include "../../include/config.h"
#include <iostream>
#include <cstring>
#include <ctime>

namespace LibSystem {

    // ============ STATIC MEMBER INITIALIZATION ============
    User* Session::currentUser = NULL;
    char Session::loginTime[MAX_TANGGAL] = "";

    // ============ SESSION CONTROL ============

    void Session::setSession(User* user) {
        currentUser = user;
        
        // Catat waktu login
        time_t now = time(0);
        struct tm* timeinfo = localtime(&now);
        strftime(loginTime, MAX_TANGGAL, "%d-%m-%Y %H:%M:%S", timeinfo);
    }

    void Session::clearSession() {
        currentUser = NULL;
        loginTime[0] = '\0';
    }

    // ============ SESSION INFO ============

    User* Session::getCurrentUser() {
        return currentUser;
    }

    int Session::getCurrentUserId() {
        if (currentUser == NULL) return -1;
        return currentUser->id;
    }

    const char* Session::getCurrentUsername() {
        if (currentUser == NULL) return "";
        return currentUser->username;
    }

    const char* Session::getLoginTime() {
        return loginTime;
    }

    // ============ SESSION CHECK ============

    bool Session::isLoggedIn() {
        return currentUser != NULL;
    }

    bool Session::isAdmin() {
        if (currentUser == NULL) return false;
        return (strcmp(currentUser->role, ROLE_ADMIN) == 0);
    }

    bool Session::isUser() {
        if (currentUser == NULL) return false;
        return (strcmp(currentUser->role, ROLE_USER) == 0);
    }

    // ============ UTILITY ============

    void Session::displaySessionInfo() {
        if (!isLoggedIn()) {
            std::cout << "[Session] Tidak ada user yang login.\n";
            return;
        }

        std::cout << "\n========== INFO SESSION ==========\n";
        std::cout << "User ID    : " << currentUser->id << "\n";
        std::cout << "Username   : " << currentUser->username << "\n";
        std::cout << "Nama       : " << currentUser->namaLengkap << "\n";
        std::cout << "Role       : " << currentUser->role << "\n";
        std::cout << "Login Time : " << loginTime << "\n";
        std::cout << "==================================\n";
    }

}
