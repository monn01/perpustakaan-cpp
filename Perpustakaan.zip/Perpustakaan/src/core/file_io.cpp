/*************************************************************
 * file_io.cpp
 * Implementasi Input/Output File
 * 
 * Format File:
 * - users.txt    : id|username|password|namaLengkap|role|noTelp|aktif
 * - buku.txt     : id|judul|penulis|kategori|tahun|stok|stokAwal|tersedia
 * - peminjaman.txt: idTrans|idUser|idBuku|tglPinjam|tglHarusKembali|tglKembali|sudahKembali|denda
 *************************************************************/

#include "../../include/core/file_io.h"
#include "../../include/config.h"
#include <fstream>
#include <iostream>
#include <cstring>

namespace LibSystem {

    // ============ LOAD FUNCTIONS ============

    bool FileIO::loadUsers(LinkedList<User>& list) {
        std::ifstream file(FILE_USER);
        
        if (!file.is_open()) {
            std::cout << "[Info] File users.txt tidak ditemukan, membuat baru...\n";
            createFileIfNotExists(FILE_USER);
            return false;
        }

        User temp;
        char line[300];
        
        while (file.getline(line, 300)) {
            // Skip baris kosong
            if (strlen(line) == 0) continue;
            
            // Parse format: id|username|password|namaLengkap|role|noTelp|aktif
            char* token = strtok(line, "|");
            if (token == NULL) continue;
            
            temp.id = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.username, token, MAX_USERNAME - 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.password, token, MAX_PASSWORD - 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.namaLengkap, token, 49);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.role, token, MAX_ROLE - 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.noTelp, token, 14);
            
            token = strtok(NULL, "|");
            if (token) temp.aktif = (atoi(token) == 1);
            
            list.pushBack(temp);
        }

        file.close();
        return true;
    }

    bool FileIO::loadBuku(LinkedList<Buku>& list) {
        std::ifstream file(FILE_BUKU);
        
        if (!file.is_open()) {
            std::cout << "[Info] File buku.txt tidak ditemukan, membuat baru...\n";
            createFileIfNotExists(FILE_BUKU);
            return false;
        }

        Buku temp;
        char line[400];
        
        while (file.getline(line, 400)) {
            if (strlen(line) == 0) continue;
            
            // Parse format: id|judul|penulis|kategori|tahun|stok|stokAwal|tersedia
            char* token = strtok(line, "|");
            if (token == NULL) continue;
            
            temp.id = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.judul, token, MAX_JUDUL - 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.penulis, token, MAX_PENULIS - 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.kategori, token, 29);
            
            token = strtok(NULL, "|");
            if (token) temp.tahunTerbit = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) temp.stok = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) temp.stokAwal = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) temp.tersedia = (atoi(token) == 1);
            
            list.pushBack(temp);
        }

        file.close();
        return true;
    }

    bool FileIO::loadPeminjaman(LinkedList<Peminjaman>& list) {
        std::ifstream file(FILE_PINJAM);
        
        if (!file.is_open()) {
            std::cout << "[Info] File peminjaman.txt tidak ditemukan, membuat baru...\n";
            createFileIfNotExists(FILE_PINJAM);
            return false;
        }

        Peminjaman temp;
        char line[500];
        
        while (file.getline(line, 500)) {
            if (strlen(line) == 0) continue;
            
            // Parse: idTrans|idUser|idBuku|tglPinjam|tglHarusKembali|tglKembali|sudahKembali|denda|dendaDibayar|tglBayarDenda
            char* token = strtok(line, "|");
            if (token == NULL) continue;
            
            temp.idTransaksi = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) temp.idUser = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) temp.idBuku = atoi(token);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.tglPinjam, token, MAX_TANGGAL - 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.tglHarusKembali, token, MAX_TANGGAL - 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.tglKembali, token, MAX_TANGGAL - 1);
            
            token = strtok(NULL, "|");
            if (token) temp.sudahKembali = (atoi(token) == 1);
            
            token = strtok(NULL, "|");
            if (token) temp.denda = atol(token);
            
            token = strtok(NULL, "|");
            if (token) temp.dendaDibayar = (atoi(token) == 1);
            
            token = strtok(NULL, "|");
            if (token) strncpy(temp.tglBayarDenda, token, MAX_TANGGAL - 1);
            
            list.pushBack(temp);
        }

        file.close();
        return true;
    }

    // ============ SAVE FUNCTIONS ============

    bool FileIO::saveUsers(LinkedList<User>& list) {
        std::ofstream file(FILE_USER, std::ios::trunc);
        
        if (!file.is_open()) {
            std::cout << "[Error] Gagal membuka file users.txt untuk menulis!\n";
            return false;
        }

        Node<User>* current = list.getHead();
        
        while (current != NULL) {
            file << current->data.id << "|"
                 << current->data.username << "|"
                 << current->data.password << "|"
                 << current->data.namaLengkap << "|"
                 << current->data.role << "|"
                 << current->data.noTelp << "|"
                 << (current->data.aktif ? 1 : 0) << "\n";
            
            current = current->next;
        }

        file.close();
        return true;
    }

    bool FileIO::saveBuku(LinkedList<Buku>& list) {
        std::ofstream file(FILE_BUKU, std::ios::trunc);
        
        if (!file.is_open()) {
            std::cout << "[Error] Gagal membuka file buku.txt untuk menulis!\n";
            return false;
        }

        Node<Buku>* current = list.getHead();
        
        while (current != NULL) {
            file << current->data.id << "|"
                 << current->data.judul << "|"
                 << current->data.penulis << "|"
                 << current->data.kategori << "|"
                 << current->data.tahunTerbit << "|"
                 << current->data.stok << "|"
                 << current->data.stokAwal << "|"
                 << (current->data.tersedia ? 1 : 0) << "\n";
            
            current = current->next;
        }

        file.close();
        return true;
    }

    bool FileIO::savePeminjaman(LinkedList<Peminjaman>& list) {
        std::ofstream file(FILE_PINJAM, std::ios::trunc);
        
        if (!file.is_open()) {
            std::cout << "[Error] Gagal membuka file peminjaman.txt untuk menulis!\n";
            return false;
        }

        Node<Peminjaman>* current = list.getHead();
        
        while (current != NULL) {
            file << current->data.idTransaksi << "|"
                 << current->data.idUser << "|"
                 << current->data.idBuku << "|"
                 << current->data.tglPinjam << "|"
                 << current->data.tglHarusKembali << "|"
                 << current->data.tglKembali << "|"
                 << (current->data.sudahKembali ? 1 : 0) << "|"
                 << current->data.denda << "|"
                 << (current->data.dendaDibayar ? 1 : 0) << "|"
                 << current->data.tglBayarDenda << "\n";
            
            current = current->next;
        }

        file.close();
        return true;
    }

    // ============ UTILITY ============

    bool FileIO::fileExists(const char* filepath) {
        std::ifstream file(filepath);
        bool exists = file.good();
        file.close();
        return exists;
    }

    bool FileIO::createFileIfNotExists(const char* filepath) {
        if (!fileExists(filepath)) {
            std::ofstream file(filepath);
            if (file.is_open()) {
                file.close();
                return true;
            }
            return false;
        }
        return true;
    }

    bool FileIO::backupFile(const char* filepath) {
        if (!fileExists(filepath)) return false;
        
        // Buat nama file backup
        char backupPath[256];
        snprintf(backupPath, 256, "%s.bak", filepath);
        
        // Copy file
        std::ifstream src(filepath, std::ios::binary);
        std::ofstream dst(backupPath, std::ios::binary);
        
        if (!src.is_open() || !dst.is_open()) return false;
        
        dst << src.rdbuf();
        
        src.close();
        dst.close();
        return true;
    }

    // ============ ID GENERATOR ============

    int FileIO::getNextUserId(LinkedList<User>& list) {
        if (list.isEmpty()) return 1;
        
        int maxId = 0;
        Node<User>* current = list.getHead();
        
        while (current != NULL) {
            if (current->data.id > maxId) {
                maxId = current->data.id;
            }
            current = current->next;
        }
        
        return maxId + 1;
    }

    int FileIO::getNextBukuId(LinkedList<Buku>& list) {
        if (list.isEmpty()) return 1;
        
        int maxId = 0;
        Node<Buku>* current = list.getHead();
        
        while (current != NULL) {
            if (current->data.id > maxId) {
                maxId = current->data.id;
            }
            current = current->next;
        }
        
        return maxId + 1;
    }

    int FileIO::getNextTransaksiId(LinkedList<Peminjaman>& list) {
        if (list.isEmpty()) return 1;
        
        int maxId = 0;
        Node<Peminjaman>* current = list.getHead();
        
        while (current != NULL) {
            if (current->data.idTransaksi > maxId) {
                maxId = current->data.idTransaksi;
            }
            current = current->next;
        }
        
        return maxId + 1;
    }

}
