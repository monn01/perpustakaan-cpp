/*************************************************************
 * validator.cpp
 * Implementasi Utilitas Validasi Input
 *************************************************************/

#include "../../include/core/validator.h"
#include <iostream>
#include <limits>
#include <cstring>
#include <cstdlib>

namespace LibSystem {

    // ============ INPUT FUNCTIONS ============

    int Validator::getIntInput(const char* prompt) {
        int input;
        
        while (true) {
            std::cout << prompt;
            
            if (std::cin >> input) {
                // Input berhasil, bersihkan buffer
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                return input;
            } else {
                // Input gagal (bukan angka)
                std::cout << "[!] Error: Masukkan angka yang valid!\n";
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
        }
    }

    int Validator::getIntInputRange(const char* prompt, int min, int max) {
        int input;
        
        while (true) {
            input = getIntInput(prompt);
            
            if (input >= min && input <= max) {
                return input;
            } else {
                std::cout << "[!] Error: Masukkan angka antara " 
                          << min << " - " << max << "!\n";
            }
        }
    }

    void Validator::getStringInput(const char* prompt, char* buffer, int maxLength) {
        std::cout << prompt;
        std::cin.getline(buffer, maxLength);
        
        // Trim whitespace
        trim(buffer);
    }

    void Validator::getStringInputRequired(const char* prompt, char* buffer, int maxLength) {
        while (true) {
            getStringInput(prompt, buffer, maxLength);
            
            if (!isEmpty(buffer)) {
                return;
            }
            
            std::cout << "[!] Error: Input tidak boleh kosong!\n";
        }
    }

    // ============ CONFIRMATION ============

    bool Validator::konfirmasi(const char* pesan) {
        char pilihan;
        
        while (true) {
            std::cout << pesan << " (y/n): ";
            std::cin >> pilihan;
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            
            if (pilihan == 'y' || pilihan == 'Y') {
                return true;
            } else if (pilihan == 'n' || pilihan == 'N') {
                return false;
            } else {
                std::cout << "[!] Error: Masukkan 'y' untuk Ya atau 'n' untuk Tidak!\n";
            }
        }
    }

    // ============ VALIDATION FUNCTIONS ============

    bool Validator::isNumeric(const char* str) {
        if (str == NULL || str[0] == '\0') return false;
        
        int i = 0;
        // Izinkan tanda minus di awal untuk angka negatif
        if (str[0] == '-') i = 1;
        
        for (; str[i] != '\0'; i++) {
            if (str[i] < '0' || str[i] > '9') {
                return false;
            }
        }
        
        return true;
    }

    bool Validator::isEmpty(const char* str) {
        if (str == NULL) return true;
        
        for (int i = 0; str[i] != '\0'; i++) {
            // Jika ada karakter selain whitespace, tidak kosong
            if (str[i] != ' ' && str[i] != '\t' && str[i] != '\n' && str[i] != '\r') {
                return false;
            }
        }
        
        return true;
    }

    bool Validator::isLengthValid(const char* str, int minLen, int maxLen) {
        if (str == NULL) return false;
        
        int len = strlen(str);
        return (len >= minLen && len <= maxLen);
    }

    // ============ UTILITY ============

    void Validator::clearScreen() {
        // Untuk Windows (Dev-C++)
        #ifdef _WIN32
            system("cls");
        #else
            // Untuk Linux/Mac
            system("clear");
        #endif
    }

    void Validator::pause() {
        pause("Tekan Enter untuk melanjutkan...");
    }

    void Validator::pause(const char* pesan) {
        std::cout << pesan;
        std::cin.get();
    }

    void Validator::trim(char* str) {
        if (str == NULL) return;
        
        int len = strlen(str);
        if (len == 0) return;
        
        // Trim trailing whitespace
        int end = len - 1;
        while (end >= 0 && (str[end] == ' ' || str[end] == '\t' || 
               str[end] == '\n' || str[end] == '\r')) {
            end--;
        }
        str[end + 1] = '\0';
        
        // Trim leading whitespace
        int start = 0;
        while (str[start] == ' ' || str[start] == '\t' || 
               str[start] == '\n' || str[start] == '\r') {
            start++;
        }
        
        // Shift string ke awal jika ada leading whitespace
        if (start > 0) {
            int i = 0;
            while (str[start + i] != '\0') {
                str[i] = str[start + i];
                i++;
            }
            str[i] = '\0';
        }
    }

}
