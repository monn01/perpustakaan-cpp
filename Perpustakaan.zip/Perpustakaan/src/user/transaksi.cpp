/*************************************************************
 * transaksi.cpp
 * Implementasi Manajemen Transaksi Peminjaman
 *************************************************************/

#include "../../include/user/transaksi.h"
#include "../../include/config.h"
#include <iostream>
#include <iomanip>
#include <cstring>
#include <ctime>

namespace LibSystem {

    // Constructor
    TransaksiManager::TransaksiManager(LinkedList<Peminjaman>& lp, 
                                       LinkedList<Buku>& lb,
                                       LinkedList<User>& lu,
                                       Queue<AntrianBuku>& q)
        : listPinjam(lp), listBuku(lb), listUser(lu), antrianBuku(q) {}

    // ============ HELPER FUNCTIONS ============

    Node<Buku>* TransaksiManager::cariBuku(int idBuku) {
        Node<Buku>* current = listBuku.getHead();
        while (current != NULL) {
            if (current->data.id == idBuku) {
                return current;
            }
            current = current->next;
        }
        return NULL;
    }

    Node<User>* TransaksiManager::cariUser(int idUser) {
        Node<User>* current = listUser.getHead();
        while (current != NULL) {
            if (current->data.id == idUser) {
                return current;
            }
            current = current->next;
        }
        return NULL;
    }

    const char* TransaksiManager::getJudulBuku(int idBuku) {
        Node<Buku>* buku = cariBuku(idBuku);
        if (buku != NULL) {
            return buku->data.judul;
        }
        return "Tidak Diketahui";
    }

    void TransaksiManager::getTanggalSekarang(char* buffer) {
        time_t now = time(0);
        struct tm* timeinfo = localtime(&now);
        strftime(buffer, MAX_TANGGAL, "%d-%m-%Y", timeinfo);
    }

    void TransaksiManager::getTanggalJatuhTempo(char* buffer, int hariTambahan) {
        time_t now = time(0);
        now += hariTambahan * 24 * 60 * 60;  // Tambah hari dalam detik
        struct tm* timeinfo = localtime(&now);
        strftime(buffer, MAX_TANGGAL, "%d-%m-%Y", timeinfo);
    }

    int TransaksiManager::hitungSelisihHari(const char* tgl1, const char* tgl2) {
        // Parse tanggal format DD-MM-YYYY
        int d1, m1, y1, d2, m2, y2;
        sscanf(tgl1, "%d-%d-%d", &d1, &m1, &y1);
        sscanf(tgl2, "%d-%d-%d", &d2, &m2, &y2);
        
        // Konversi ke struct tm
        struct tm tm1 = {0}, tm2 = {0};
        tm1.tm_mday = d1; tm1.tm_mon = m1 - 1; tm1.tm_year = y1 - 1900;
        tm2.tm_mday = d2; tm2.tm_mon = m2 - 1; tm2.tm_year = y2 - 1900;
        
        // Hitung selisih
        time_t time1 = mktime(&tm1);
        time_t time2 = mktime(&tm2);
        
        double diff = difftime(time2, time1);
        return (int)(diff / (24 * 60 * 60));
    }

    // ============ PRINT HELPERS ============

    void TransaksiManager::printSeparator() {
        std::cout << "+-------+------------------------------+------------+------------+--------+-----------+\n";
    }

    void TransaksiManager::printTransaksiHeader() {
        printSeparator();
        std::cout << "| " << std::left << std::setw(5) << "ID" << " | "
                  << std::setw(28) << "Judul Buku" << " | "
                  << std::setw(10) << "Tgl Pinjam" << " | "
                  << std::setw(10) << "Jatuh Tempo" << " | "
                  << std::setw(6) << "Status" << " | "
                  << std::setw(9) << "Denda" << " |\n";
        printSeparator();
    }

    void TransaksiManager::printTransaksiRow(const Peminjaman& p) {
        char judulShort[29];
        strncpy(judulShort, getJudulBuku(p.idBuku), 28);
        judulShort[28] = '\0';
        
        std::cout << "| " << std::left << std::setw(5) << p.idTransaksi << " | "
                  << std::setw(28) << judulShort << " | "
                  << std::setw(10) << p.tglPinjam << " | "
                  << std::setw(10) << p.tglHarusKembali << " | "
                  << std::setw(6) << (p.sudahKembali ? "Selesai" : "Aktif") << " | "
                  << "Rp" << std::setw(6) << p.denda << " |\n";
    }

    // ============ PEMINJAMAN ============

    int TransaksiManager::pinjamBuku(int idUser, int idBuku) {
        // Cek user
        Node<User>* user = cariUser(idUser);
        if (user == NULL) {
            std::cout << "[!] User tidak ditemukan.\n";
            return -1;
        }
        
        // Cek apakah user terblokir karena denda
        if (terblokirKarenaDenda(idUser)) {
            long totalDenda = getTotalDendaUser(idUser);
            std::cout << "[!] Anda tidak dapat meminjam buku!\n";
            std::cout << "    Total denda belum bayar: Rp " << totalDenda << "\n";
            std::cout << "    Silakan bayar denda terlebih dahulu.\n";
            return -3;  // Kode khusus: terblokir denda
        }
        
        // Cek buku
        Node<Buku>* buku = cariBuku(idBuku);
        if (buku == NULL) {
            std::cout << "[!] Buku tidak ditemukan.\n";
            return -1;
        }
        
        // Cek batas peminjaman
        if (!bisaMeminjam(idUser)) {
            std::cout << "[!] Anda sudah mencapai batas maksimal peminjaman (" 
                      << MAX_PINJAM_PER_USER << " buku).\n";
            return -1;
        }
        
        // Cek apakah user sudah meminjam buku yang sama
        Node<Peminjaman>* curr = listPinjam.getHead();
        while (curr != NULL) {
            if (curr->data.idUser == idUser && 
                curr->data.idBuku == idBuku && 
                !curr->data.sudahKembali) {
                std::cout << "[!] Anda sudah meminjam buku ini dan belum mengembalikan.\n";
                return -1;
            }
            curr = curr->next;
        }
        
        // Cek stok
        if (buku->data.stok <= 0) {
            std::cout << "[!] Maaf, stok buku \"" << buku->data.judul << "\" sedang habis.\n";
            
            // Tawarkan untuk masuk antrian
            if (!sudahDalamAntrian(idUser, idBuku)) {
                std::cout << "    Apakah Anda ingin masuk ke antrian reservasi?\n";
                std::cout << "    (Anda akan diberitahu saat buku tersedia)\n";
            } else {
                std::cout << "    Anda sudah terdaftar dalam antrian untuk buku ini.\n";
            }
            return -2;  // Kode khusus: stok habis
        }
        
        // Buat transaksi baru
        Peminjaman pinjamBaru;
        pinjamBaru.idTransaksi = generateIdTransaksi();
        pinjamBaru.idUser = idUser;
        pinjamBaru.idBuku = idBuku;
        pinjamBaru.sudahKembali = false;
        pinjamBaru.denda = 0;
        pinjamBaru.dendaDibayar = false;
        strcpy(pinjamBaru.tglBayarDenda, "-");
        
        // Set tanggal
        getTanggalSekarang(pinjamBaru.tglPinjam);
        getTanggalJatuhTempo(pinjamBaru.tglHarusKembali, DURASI_PINJAM_HARI);
        strcpy(pinjamBaru.tglKembali, "-");
        
        // Kurangi stok buku
        buku->data.stok--;
        if (buku->data.stok == 0) {
            buku->data.tersedia = false;
        }
        
        // Tambah ke list peminjaman
        listPinjam.pushBack(pinjamBaru);
        
        std::cout << "\n[OK] Peminjaman berhasil!\n";
        std::cout << "     ID Transaksi    : " << pinjamBaru.idTransaksi << "\n";
        std::cout << "     Buku            : " << buku->data.judul << "\n";
        std::cout << "     Tanggal Pinjam  : " << pinjamBaru.tglPinjam << "\n";
        std::cout << "     Jatuh Tempo     : " << pinjamBaru.tglHarusKembali << "\n";
        std::cout << "     Denda per hari  : Rp " << DENDA_PER_HARI << " (jika telat)\n";
        
        return pinjamBaru.idTransaksi;
    }

    bool TransaksiManager::bisaMeminjam(int idUser) {
        return hitungPinjamanAktif(idUser) < MAX_PINJAM_PER_USER;
    }

    int TransaksiManager::hitungPinjamanAktif(int idUser) {
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && !current->data.sudahKembali) {
                count++;
            }
            current = current->next;
        }
        
        return count;
    }

    // ============ PENGEMBALIAN ============

    bool TransaksiManager::kembalikanBuku(int idTransaksi) {
        Node<Peminjaman>* transaksi = cariTransaksi(idTransaksi);
        
        if (transaksi == NULL) {
            std::cout << "[!] Transaksi dengan ID " << idTransaksi << " tidak ditemukan.\n";
            return false;
        }
        
        if (transaksi->data.sudahKembali) {
            std::cout << "[!] Buku sudah dikembalikan sebelumnya.\n";
            return false;
        }
        
        // Set tanggal kembali
        getTanggalSekarang(transaksi->data.tglKembali);
        
        // Hitung denda jika telat
        transaksi->data.denda = hitungDenda(transaksi->data.tglPinjam, 
                                            transaksi->data.tglHarusKembali);
        
        // Update status
        transaksi->data.sudahKembali = true;
        
        // Tambah stok buku kembali
        Node<Buku>* buku = cariBuku(transaksi->data.idBuku);
        if (buku != NULL) {
            buku->data.stok++;
            buku->data.tersedia = true;
            
            std::cout << "\n[OK] Pengembalian berhasil!\n";
            std::cout << "     Buku            : " << buku->data.judul << "\n";
            std::cout << "     Tanggal Kembali : " << transaksi->data.tglKembali << "\n";
            
            if (transaksi->data.denda > 0) {
                std::cout << "     [!] DENDA       : Rp " << transaksi->data.denda << "\n";
                std::cout << "         (Terlambat mengembalikan)\n";
            } else {
                std::cout << "     Denda           : Rp 0 (Tepat waktu, terima kasih!)\n";
            }
            
            // Proses antrian jika ada
            prosesAntrian(transaksi->data.idBuku);
        }
        
        return true;
    }

    bool TransaksiManager::kembalikanBukuByUserBuku(int idUser, int idBuku) {
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && 
                current->data.idBuku == idBuku && 
                !current->data.sudahKembali) {
                return kembalikanBuku(current->data.idTransaksi);
            }
            current = current->next;
        }
        
        std::cout << "[!] Tidak ditemukan peminjaman aktif untuk buku ini.\n";
        return false;
    }

    long TransaksiManager::hitungDenda(const char* tglPinjam, const char* tglHarusKembali) {
        char tglSekarang[MAX_TANGGAL];
        getTanggalSekarang(tglSekarang);
        
        int selisih = hitungSelisihHari(tglHarusKembali, tglSekarang);
        
        if (selisih > 0) {
            return selisih * DENDA_PER_HARI;
        }
        
        return 0;
    }

    // ============ ANTRIAN / QUEUE ============

    void TransaksiManager::masukAntrian(int idUser, int idBuku) {
        if (sudahDalamAntrian(idUser, idBuku)) {
            std::cout << "[!] Anda sudah terdaftar dalam antrian untuk buku ini.\n";
            return;
        }
        
        AntrianBuku antrian;
        antrian.idUser = idUser;
        antrian.idBuku = idBuku;
        getTanggalSekarang(antrian.waktuDaftar);
        
        antrianBuku.enqueue(antrian);
        
        Node<Buku>* buku = cariBuku(idBuku);
        std::cout << "[OK] Anda berhasil masuk antrian untuk buku \"" 
                  << (buku ? buku->data.judul : "Unknown") << "\".\n";
        std::cout << "     Anda akan diberitahu saat buku tersedia.\n";
    }

    void TransaksiManager::prosesAntrian(int idBuku) {
        if (antrianBuku.isEmpty()) return;
        
        // Cari antrian untuk buku ini
        QueueNode<AntrianBuku>* current = antrianBuku.getFrontNode();
        
        while (current != NULL) {
            if (current->data.idBuku == idBuku) {
                Node<User>* user = cariUser(current->data.idUser);
                Node<Buku>* buku = cariBuku(idBuku);
                
                std::cout << "\n[NOTIFIKASI ANTRIAN]\n";
                std::cout << "   Buku \"" << (buku ? buku->data.judul : "Unknown") 
                          << "\" sekarang tersedia!\n";
                std::cout << "   User " << (user ? user->data.username : "Unknown")
                          << " (ID: " << current->data.idUser << ") "
                          << "berada di urutan depan antrian.\n";
                
                // Hapus dari antrian
                antrianBuku.removeNode(current);
                return;
            }
            current = current->next;
        }
    }

    void TransaksiManager::tampilkanAntrianBuku(int idBuku) {
        Node<Buku>* buku = cariBuku(idBuku);
        
        std::cout << "\n====== Antrian untuk Buku: " 
                  << (buku ? buku->data.judul : "Unknown") << " ======\n";
        
        if (antrianBuku.isEmpty()) {
            std::cout << "Tidak ada antrian.\n";
            return;
        }
        
        int pos = 1;
        bool ada = false;
        QueueNode<AntrianBuku>* current = antrianBuku.getFrontNode();
        
        while (current != NULL) {
            if (current->data.idBuku == idBuku) {
                Node<User>* user = cariUser(current->data.idUser);
                std::cout << pos << ". " << (user ? user->data.username : "Unknown")
                          << " (Daftar: " << current->data.waktuDaftar << ")\n";
                pos++;
                ada = true;
            }
            current = current->next;
        }
        
        if (!ada) {
            std::cout << "Tidak ada antrian untuk buku ini.\n";
        }
    }

    void TransaksiManager::tampilkanSemuaAntrian() {
        std::cout << "\n====== DAFTAR SEMUA ANTRIAN RESERVASI ======\n";
        
        if (antrianBuku.isEmpty()) {
            std::cout << "Tidak ada antrian reservasi.\n";
            return;
        }
        
        std::cout << "+-----+----------------+------------------------------+------------+\n";
        std::cout << "| No  | Username       | Judul Buku                   | Tgl Daftar |\n";
        std::cout << "+-----+----------------+------------------------------+------------+\n";
        
        int no = 1;
        QueueNode<AntrianBuku>* current = antrianBuku.getFrontNode();
        
        while (current != NULL) {
            Node<User>* user = cariUser(current->data.idUser);
            
            char judulShort[29];
            strncpy(judulShort, getJudulBuku(current->data.idBuku), 28);
            judulShort[28] = '\0';
            
            std::cout << "| " << std::left << std::setw(3) << no << " | "
                      << std::setw(14) << (user ? user->data.username : "Unknown") << " | "
                      << std::setw(28) << judulShort << " | "
                      << std::setw(10) << current->data.waktuDaftar << " |\n";
            
            current = current->next;
            no++;
        }
        
        std::cout << "+-----+----------------+------------------------------+------------+\n";
        std::cout << "Total " << (no - 1) << " antrian.\n";
    }

    bool TransaksiManager::sudahDalamAntrian(int idUser, int idBuku) {
        QueueNode<AntrianBuku>* current = antrianBuku.getFrontNode();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && current->data.idBuku == idBuku) {
                return true;
            }
            current = current->next;
        }
        
        return false;
    }

    bool TransaksiManager::batalkanAntrian(int idUser, int idBuku) {
        QueueNode<AntrianBuku>* current = antrianBuku.getFrontNode();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && current->data.idBuku == idBuku) {
                antrianBuku.removeNode(current);
                std::cout << "[OK] Antrian berhasil dibatalkan.\n";
                return true;
            }
            current = current->next;
        }
        
        std::cout << "[!] Anda tidak terdaftar dalam antrian untuk buku ini.\n";
        return false;
    }

    // ============ VIEW TRANSAKSI ============

    void TransaksiManager::tampilkanTransaksiUser(int idUser) {
        Node<User>* user = cariUser(idUser);
        
        std::cout << "\n====== Transaksi User: " 
                  << (user ? user->data.username : "Unknown") << " ======\n";
        
        printTransaksiHeader();
        
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idUser == idUser) {
                printTransaksiRow(current->data);
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        
        if (count == 0) {
            std::cout << "Belum ada transaksi.\n";
        } else {
            std::cout << "Total " << count << " transaksi.\n";
        }
    }

    void TransaksiManager::tampilkanPinjamanAktifUser(int idUser) {
        std::cout << "\n====== Buku yang Sedang Dipinjam ======\n";
        
        printTransaksiHeader();
        
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && !current->data.sudahKembali) {
                printTransaksiRow(current->data);
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        
        if (count == 0) {
            std::cout << "Tidak ada buku yang sedang dipinjam.\n";
        } else {
            std::cout << "Total " << count << " buku sedang dipinjam.\n";
            std::cout << "Sisa kuota: " << (MAX_PINJAM_PER_USER - count) << " buku lagi.\n";
        }
    }

    void TransaksiManager::tampilkanHistoryUser(int idUser) {
        std::cout << "\n====== Riwayat Peminjaman ======\n";
        
        printTransaksiHeader();
        
        int count = 0;
        long totalDenda = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && current->data.sudahKembali) {
                printTransaksiRow(current->data);
                totalDenda += current->data.denda;
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        
        if (count == 0) {
            std::cout << "Belum ada riwayat peminjaman.\n";
        } else {
            std::cout << "Total " << count << " transaksi selesai.\n";
            std::cout << "Total denda yang pernah dibayar: Rp " << totalDenda << "\n";
        }
    }

    void TransaksiManager::tampilkanDetailTransaksi(int idTransaksi) {
        Node<Peminjaman>* transaksi = cariTransaksi(idTransaksi);
        
        if (transaksi == NULL) {
            std::cout << "[!] Transaksi tidak ditemukan.\n";
            return;
        }
        
        Peminjaman& p = transaksi->data;
        Node<User>* user = cariUser(p.idUser);
        Node<Buku>* buku = cariBuku(p.idBuku);
        
        std::cout << "\n========== DETAIL TRANSAKSI ==========\n";
        std::cout << "ID Transaksi     : " << p.idTransaksi << "\n";
        std::cout << "Peminjam         : " << (user ? user->data.namaLengkap : "Unknown") << "\n";
        std::cout << "Username         : " << (user ? user->data.username : "Unknown") << "\n";
        std::cout << "Buku             : " << (buku ? buku->data.judul : "Unknown") << "\n";
        std::cout << "Tanggal Pinjam   : " << p.tglPinjam << "\n";
        std::cout << "Jatuh Tempo      : " << p.tglHarusKembali << "\n";
        std::cout << "Tanggal Kembali  : " << p.tglKembali << "\n";
        std::cout << "Status           : " << (p.sudahKembali ? "Sudah Dikembalikan" : "Masih Dipinjam") << "\n";
        std::cout << "Denda            : Rp " << p.denda << "\n";
        std::cout << "======================================\n";
    }

    // ============ UTILITY ============

    Node<Peminjaman>* TransaksiManager::cariTransaksi(int idTransaksi) {
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idTransaksi == idTransaksi) {
                return current;
            }
            current = current->next;
        }
        
        return NULL;
    }

    int TransaksiManager::generateIdTransaksi() {
        if (listPinjam.isEmpty()) return 1;
        
        int maxId = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idTransaksi > maxId) {
                maxId = current->data.idTransaksi;
            }
            current = current->next;
        }
        
        return maxId + 1;
    }

    LinkedList<Peminjaman>& TransaksiManager::getListPinjam() {
        return listPinjam;
    }

    Queue<AntrianBuku>& TransaksiManager::getAntrianBuku() {
        return antrianBuku;
    }

    // ============ MANAJEMEN DENDA ============

    long TransaksiManager::getTotalDendaUser(int idUser) {
        long total = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && 
                current->data.denda > 0 && 
                !current->data.dendaDibayar) {
                total += current->data.denda;
            }
            current = current->next;
        }
        
        return total;
    }

    bool TransaksiManager::punyaDendaBelumBayar(int idUser) {
        return getTotalDendaUser(idUser) > 0;
    }

    bool TransaksiManager::terblokirKarenaDenda(int idUser) {
        return getTotalDendaUser(idUser) >= BATAS_DENDA_BLOKIR;
    }

    bool TransaksiManager::bayarDenda(int idTransaksi) {
        Node<Peminjaman>* transaksi = cariTransaksi(idTransaksi);
        
        if (transaksi == NULL) {
            std::cout << "[!] Transaksi tidak ditemukan.\n";
            return false;
        }
        
        if (transaksi->data.denda == 0) {
            std::cout << "[!] Transaksi ini tidak memiliki denda.\n";
            return false;
        }
        
        if (transaksi->data.dendaDibayar) {
            std::cout << "[!] Denda untuk transaksi ini sudah dibayar.\n";
            return false;
        }
        
        // Set status bayar
        transaksi->data.dendaDibayar = true;
        getTanggalSekarang(transaksi->data.tglBayarDenda);
        
        std::cout << "\n[OK] Pembayaran denda berhasil!\n";
        std::cout << "     ID Transaksi  : " << idTransaksi << "\n";
        std::cout << "     Jumlah Bayar  : Rp " << transaksi->data.denda << "\n";
        std::cout << "     Tanggal Bayar : " << transaksi->data.tglBayarDenda << "\n";
        
        return true;
    }

    bool TransaksiManager::bayarSemuaDendaUser(int idUser) {
        long totalDenda = getTotalDendaUser(idUser);
        
        if (totalDenda == 0) {
            std::cout << "[!] User tidak memiliki denda yang perlu dibayar.\n";
            return false;
        }
        
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        char tglBayar[MAX_TANGGAL];
        getTanggalSekarang(tglBayar);
        
        while (current != NULL) {
            if (current->data.idUser == idUser && 
                current->data.denda > 0 && 
                !current->data.dendaDibayar) {
                
                current->data.dendaDibayar = true;
                strcpy(current->data.tglBayarDenda, tglBayar);
                count++;
            }
            current = current->next;
        }
        
        std::cout << "\n[OK] Pembayaran semua denda berhasil!\n";
        std::cout << "     Jumlah Transaksi : " << count << "\n";
        std::cout << "     Total Dibayar    : Rp " << totalDenda << "\n";
        std::cout << "     Tanggal Bayar    : " << tglBayar << "\n";
        
        return true;
    }

    void TransaksiManager::tampilkanDendaUser(int idUser) {
        Node<User>* user = cariUser(idUser);
        
        std::cout << "\n====== DENDA ANDA ======\n";
        if (user) {
            std::cout << "User: " << user->data.namaLengkap << "\n\n";
        }
        
        std::cout << "+-------+------------------------------+------------+-----------+--------+\n";
        std::cout << "| ID    | Judul Buku                   | Tgl Kembali| Denda     | Status |\n";
        std::cout << "+-------+------------------------------+------------+-----------+--------+\n";
        
        long totalBelumBayar = 0;
        long totalSudahBayar = 0;
        int countBelum = 0;
        
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.idUser == idUser && current->data.denda > 0) {
                char judulShort[29];
                strncpy(judulShort, getJudulBuku(current->data.idBuku), 28);
                judulShort[28] = '\0';
                
                const char* status = current->data.dendaDibayar ? "Lunas" : "Belum";
                
                std::cout << "| " << std::left << std::setw(5) << current->data.idTransaksi << " | "
                          << std::setw(28) << judulShort << " | "
                          << std::setw(10) << current->data.tglKembali << " | "
                          << "Rp" << std::setw(7) << current->data.denda << " | "
                          << std::setw(6) << status << " |\n";
                
                if (current->data.dendaDibayar) {
                    totalSudahBayar += current->data.denda;
                } else {
                    totalBelumBayar += current->data.denda;
                    countBelum++;
                }
            }
            current = current->next;
        }
        
        std::cout << "+-------+------------------------------+------------+-----------+--------+\n";
        
        if (totalBelumBayar == 0 && totalSudahBayar == 0) {
            std::cout << "\nAnda tidak memiliki denda. Selamat!\n";
        } else {
            std::cout << "\nRingkasan:\n";
            std::cout << "  Denda belum bayar : Rp " << totalBelumBayar << " (" << countBelum << " transaksi)\n";
            std::cout << "  Denda sudah bayar : Rp " << totalSudahBayar << "\n";
            
            if (terblokirKarenaDenda(idUser)) {
                std::cout << "\n  [!] PERHATIAN: Anda terblokir dari peminjaman!\n";
                std::cout << "      Denda Anda melebihi batas Rp " << BATAS_DENDA_BLOKIR << "\n";
                std::cout << "      Silakan bayar denda untuk dapat meminjam lagi.\n";
            }
        }
    }

    void TransaksiManager::tampilkanSemuaDendaBelumBayar() {
        std::cout << "\n=============== DAFTAR DENDA BELUM BAYAR ===============\n";
        
        std::cout << "+-------+----------------+------------------------------+-----------+------------+\n";
        std::cout << "| ID    | Username       | Judul Buku                   | Denda     | Tgl Kembali|\n";
        std::cout << "+-------+----------------+------------------------------+-----------+------------+\n";
        
        long totalDenda = 0;
        int count = 0;
        
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (current->data.denda > 0 && !current->data.dendaDibayar) {
                Node<User>* user = cariUser(current->data.idUser);
                
                char judulShort[29];
                strncpy(judulShort, getJudulBuku(current->data.idBuku), 28);
                judulShort[28] = '\0';
                
                std::cout << "| " << std::left << std::setw(5) << current->data.idTransaksi << " | "
                          << std::setw(14) << (user ? user->data.username : "Unknown") << " | "
                          << std::setw(28) << judulShort << " | "
                          << "Rp" << std::setw(7) << current->data.denda << " | "
                          << std::setw(10) << current->data.tglKembali << " |\n";
                
                totalDenda += current->data.denda;
                count++;
            }
            current = current->next;
        }
        
        std::cout << "+-------+----------------+------------------------------+-----------+------------+\n";
        
        if (count == 0) {
            std::cout << "\nTidak ada denda yang belum dibayar.\n";
        } else {
            std::cout << "\nTotal: " << count << " transaksi dengan denda\n";
            std::cout << "Total denda belum bayar: Rp " << totalDenda << "\n";
        }
    }

}
