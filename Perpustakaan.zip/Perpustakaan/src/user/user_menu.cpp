/*************************************************************
 * user_menu.cpp
 * Implementasi Menu Utama User
 *************************************************************/

#include "../../include/user/user_menu.h"
#include "../../include/auth/session.h"
#include "../../include/auth/auth_service.h"
#include "../../include/core/validator.h"
#include "../../include/config.h"
#include <iostream>
#include <iomanip>
#include <cstring>

namespace LibSystem {

    // Constructor
    UserMenu::UserMenu(ManagerBuku& mb, TransaksiManager& tm)
        : managerBuku(mb), transaksiManager(tm) {}

    // ============ MENU UTAMA ============

    void UserMenu::tampilkanMenu() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            User* currentUser = Session::getCurrentUser();
            int pinjamanAktif = transaksiManager.hitungPinjamanAktif(currentUser->id);
            long totalDenda = transaksiManager.getTotalDendaUser(currentUser->id);
            
            std::cout << "\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "�       SELAMAT DATANG DI PERPUSTAKAAN     �\n";
            std::cout << "�------------------------------------------�\n";
            std::cout << "�  Halo, " << std::left << std::setw(32) 
                      << currentUser->namaLengkap << " �\n";
            std::cout << "�  Buku dipinjam: " << pinjamanAktif << "/" << MAX_PINJAM_PER_USER
                      << std::setw(23) << " " << " �\n";
            
            if (totalDenda > 0) {
                char dendaStr[30];
                snprintf(dendaStr, 30, "Denda: Rp %ld", totalDenda);
                std::cout << "�  " << std::left << std::setw(39) << dendaStr << " �\n";
            }
            
            std::cout << "�------------------------------------------�\n";
            std::cout << "�  1. Lihat & Cari Buku                    �\n";
            std::cout << "�  2. Pinjam Buku                          �\n";
            std::cout << "�  3. Kembalikan Buku                      �\n";
            std::cout << "�  4. Lihat Denda Saya                     �\n";
            std::cout << "�  5. Antrian Reservasi Saya               �\n";
            std::cout << "�  6. Profil & Riwayat Saya                �\n";
            std::cout << "�  0. Logout                               �\n";
            std::cout << "+------------------------------------------+\n";
            
            if (transaksiManager.terblokirKarenaDenda(currentUser->id)) {
                std::cout << "\n[!] PERHATIAN: Anda terblokir karena denda melebihi batas!\n";
                std::cout << "    Silakan bayar denda untuk dapat meminjam lagi.\n";
            }
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    menuLihatBuku();
                    break;
                case 2:
                    menuPinjamBuku();
                    break;
                case 3:
                    menuKembalikanBuku();
                    break;
                case 4:
                    transaksiManager.tampilkanDendaUser(currentUser->id);
                    Validator::pause();
                    break;
                case 5:
                    menuAntrianSaya();
                    break;
                case 6:
                    menuProfilSaya();
                    break;
                case 0:
                    if (Validator::konfirmasi("Yakin ingin logout?")) {
                        std::cout << "\n[OK] Terima kasih telah berkunjung!\n";
                    } else {
                        pilihan = -1;
                    }
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ SUB-MENU LIHAT BUKU ============

    void UserMenu::menuLihatBuku() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            std::cout << "\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "�           KATALOG BUKU                   �\n";
            std::cout << "�------------------------------------------�\n";
            std::cout << "�  1. Lihat Semua Buku                     �\n";
            std::cout << "�  2. Lihat Buku Tersedia                  �\n";
            std::cout << "�  3. Cari Buku                            �\n";
            std::cout << "�  4. Lihat Detail Buku                    �\n";
            std::cout << "�  0. Kembali                              �\n";
            std::cout << "+------------------------------------------+\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    managerBuku.tampilkanSemuaBuku();
                    Validator::pause();
                    break;
                case 2:
                    managerBuku.tampilkanBukuTersedia();
                    Validator::pause();
                    break;
                case 3:
                    formCariBuku();
                    break;
                case 4: {
                    int id = Validator::getIntInput("Masukkan ID Buku: ");
                    managerBuku.tampilkanDetailBuku(id);
                    Validator::pause();
                    break;
                }
                case 0:
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ SUB-MENU PINJAM BUKU ============

    void UserMenu::menuPinjamBuku() {
        Validator::clearScreen();
        
        User* currentUser = Session::getCurrentUser();
        int pinjamanAktif = transaksiManager.hitungPinjamanAktif(currentUser->id);
        
        std::cout << "\n====== PINJAM BUKU ======\n";
        std::cout << "Buku yang sedang Anda pinjam: " << pinjamanAktif 
                  << "/" << MAX_PINJAM_PER_USER << "\n";
        
        if (pinjamanAktif >= MAX_PINJAM_PER_USER) {
            std::cout << "\n[!] Maaf, Anda sudah mencapai batas maksimal peminjaman.\n";
            std::cout << "    Kembalikan buku terlebih dahulu untuk meminjam yang baru.\n";
            Validator::pause();
            return;
        }
        
        std::cout << "\nDaftar Buku Tersedia:\n";
        managerBuku.tampilkanBukuTersedia();
        
        formPinjamBuku();
    }

    void UserMenu::formPinjamBuku() {
        User* currentUser = Session::getCurrentUser();
        
        int idBuku = Validator::getIntInput("\nMasukkan ID Buku yang ingin dipinjam (0=batal): ");
        
        if (idBuku == 0) {
            std::cout << "[Info] Dibatalkan.\n";
            Validator::pause();
            return;
        }
        
        // Coba pinjam
        int result = transaksiManager.pinjamBuku(currentUser->id, idBuku);
        
        if (result == -2) {
            // Stok habis, tawarkan antrian
            if (Validator::konfirmasi("Masuk ke antrian reservasi?")) {
                formMasukAntrian(idBuku);
            }
        }
        
        Validator::pause();
    }

    void UserMenu::formMasukAntrian(int idBuku) {
        User* currentUser = Session::getCurrentUser();
        transaksiManager.masukAntrian(currentUser->id, idBuku);
    }

    // ============ SUB-MENU KEMBALIKAN BUKU ============

    void UserMenu::menuKembalikanBuku() {
        Validator::clearScreen();
        
        User* currentUser = Session::getCurrentUser();
        
        std::cout << "\n====== KEMBALIKAN BUKU ======\n";
        
        // Tampilkan buku yang sedang dipinjam
        transaksiManager.tampilkanPinjamanAktifUser(currentUser->id);
        
        int pinjamanAktif = transaksiManager.hitungPinjamanAktif(currentUser->id);
        
        if (pinjamanAktif == 0) {
            std::cout << "\n[Info] Tidak ada buku yang perlu dikembalikan.\n";
            Validator::pause();
            return;
        }
        
        formKembalikanBuku();
    }

    void UserMenu::formKembalikanBuku() {
        int idTransaksi = Validator::getIntInput("\nMasukkan ID Transaksi yang ingin dikembalikan (0=batal): ");
        
        if (idTransaksi == 0) {
            std::cout << "[Info] Dibatalkan.\n";
            Validator::pause();
            return;
        }
        
        // Verifikasi bahwa transaksi milik user yang login
        Node<Peminjaman>* transaksi = transaksiManager.cariTransaksi(idTransaksi);
        
        if (transaksi == NULL) {
            std::cout << "[!] Transaksi tidak ditemukan.\n";
            Validator::pause();
            return;
        }
        
        if (transaksi->data.idUser != Session::getCurrentUserId()) {
            std::cout << "[!] Transaksi ini bukan milik Anda.\n";
            Validator::pause();
            return;
        }
        
        if (transaksi->data.sudahKembali) {
            std::cout << "[!] Buku sudah dikembalikan sebelumnya.\n";
            Validator::pause();
            return;
        }
        
        if (Validator::konfirmasi("Konfirmasi pengembalian buku?")) {
            transaksiManager.kembalikanBuku(idTransaksi);
        } else {
            std::cout << "[Info] Dibatalkan.\n";
        }
        
        Validator::pause();
    }

    // ============ SUB-MENU ANTRIAN ============

    void UserMenu::menuAntrianSaya() {
        Validator::clearScreen();
        
        User* currentUser = Session::getCurrentUser();
        
        std::cout << "\n====== ANTRIAN RESERVASI SAYA ======\n";
        
        // Cari antrian milik user ini
        Queue<AntrianBuku>& antrian = transaksiManager.getAntrianBuku();
        
        if (antrian.isEmpty()) {
            std::cout << "\nAnda tidak memiliki antrian reservasi.\n";
            Validator::pause();
            return;
        }
        
        std::cout << "\n+-----+------------------------------+------------+\n";
        std::cout << "| No  | Judul Buku                   | Tgl Daftar |\n";
        std::cout << "+-----+------------------------------+------------+\n";
        
        int no = 1;
        bool adaAntrian = false;
        QueueNode<AntrianBuku>* curr = antrian.getFrontNode();
        
        while (curr != NULL) {
            if (curr->data.idUser == currentUser->id) {
                Node<Buku>* buku = managerBuku.cariBukuById(curr->data.idBuku);
                
                char judulShort[29];
                if (buku) {
                    strncpy(judulShort, buku->data.judul, 28);
                } else {
                    strcpy(judulShort, "Unknown");
                }
                judulShort[28] = '\0';
                
                std::cout << "| " << std::left << std::setw(3) << no << " | "
                          << std::setw(28) << judulShort << " | "
                          << std::setw(10) << curr->data.waktuDaftar << " |\n";
                no++;
                adaAntrian = true;
            }
            curr = curr->next;
        }
        
        std::cout << "+-----+------------------------------+------------+\n";
        
        if (!adaAntrian) {
            std::cout << "\nAnda tidak memiliki antrian reservasi.\n";
        } else {
            std::cout << "\nTotal " << (no - 1) << " antrian.\n";
            
            // Opsi batalkan antrian
            if (Validator::konfirmasi("\nApakah ingin membatalkan salah satu antrian?")) {
                int idBuku = Validator::getIntInput("Masukkan ID Buku yang ingin dibatalkan: ");
                transaksiManager.batalkanAntrian(currentUser->id, idBuku);
            }
        }
        
        Validator::pause();
    }

    // ============ SUB-MENU PROFIL ============

    void UserMenu::menuProfilSaya() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            User* currentUser = Session::getCurrentUser();
            
            std::cout << "\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "�             PROFIL SAYA                  �\n";
            std::cout << "�------------------------------------------�\n";
            std::cout << "�  ID        : " << std::left << std::setw(27) 
                      << currentUser->id << " �\n";
            std::cout << "�  Username  : " << std::left << std::setw(27) 
                      << currentUser->username << " �\n";
            std::cout << "�  Nama      : " << std::left << std::setw(27) 
                      << currentUser->namaLengkap << " �\n";
            std::cout << "�  Telepon   : " << std::left << std::setw(27) 
                      << currentUser->noTelp << " �\n";
            std::cout << "�  Role      : " << std::left << std::setw(27) 
                      << currentUser->role << " �\n";
            std::cout << "�------------------------------------------�\n";
            std::cout << "�  1. Lihat Buku yang Sedang Dipinjam      �\n";
            std::cout << "�  2. Lihat Riwayat Peminjaman             �\n";
            std::cout << "�  3. Ganti Password                       �\n";
            std::cout << "�  0. Kembali                              �\n";
            std::cout << "+------------------------------------------+\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    transaksiManager.tampilkanPinjamanAktifUser(currentUser->id);
                    Validator::pause();
                    break;
                case 2:
                    transaksiManager.tampilkanHistoryUser(currentUser->id);
                    Validator::pause();
                    break;
                case 3: {
                    char oldPass[MAX_PASSWORD], newPass[MAX_PASSWORD];
                    Validator::getStringInputRequired("Password lama: ", oldPass, MAX_PASSWORD);
                    Validator::getStringInputRequired("Password baru: ", newPass, MAX_PASSWORD);
                    
                    // Kita perlu akses ke listUser, tapi tidak ada di sini
                    // Untuk sementara, langsung update currentUser
                    if (strcmp(currentUser->password, oldPass) == 0) {
                        if (strlen(newPass) >= 6) {
                            strncpy(currentUser->password, newPass, MAX_PASSWORD - 1);
                            std::cout << "[OK] Password berhasil diubah!\n";
                        } else {
                            std::cout << "[!] Password baru minimal 6 karakter!\n";
                        }
                    } else {
                        std::cout << "[!] Password lama salah!\n";
                    }
                    Validator::pause();
                    break;
                }
                case 0:
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ FORM CARI BUKU ============

    void UserMenu::formCariBuku() {
        Validator::clearScreen();
        
        std::cout << "\n====== CARI BUKU ======\n";
        std::cout << "1. Cari berdasarkan Judul\n";
        std::cout << "2. Cari berdasarkan Penulis\n";
        std::cout << "3. Cari berdasarkan Kategori\n";
        
        int pilihan = Validator::getIntInput("\nPilih metode pencarian: ");
        
        char keyword[100];
        
        switch (pilihan) {
            case 1:
                Validator::getStringInputRequired("Masukkan kata kunci judul: ", keyword, 100);
                managerBuku.cariBukuByJudul(keyword);
                break;
            case 2:
                Validator::getStringInputRequired("Masukkan nama penulis: ", keyword, 100);
                managerBuku.cariBukuByPenulis(keyword);
                break;
            case 3:
                Validator::getStringInputRequired("Masukkan kategori: ", keyword, 100);
                managerBuku.cariBukuByKategori(keyword);
                break;
            default:
                std::cout << "[!] Pilihan tidak valid.\n";
        }
        
        Validator::pause();
    }

}
