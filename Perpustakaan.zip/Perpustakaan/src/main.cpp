/*************************************************************
 * main.cpp
 * Sistem Manajemen Perpustakaan
 * 
 * Program utama yang menghubungkan semua modul:
 * - Struktur Data: LinkedList, Stack, Queue, BST
 * - Auth: Login, Register, Session
 * - Admin: Kelola Buku, User, Denda, Laporan
 * - User: Pinjam, Kembalikan, Antrian
 * 
 * Dibuat untuk tugas kuliah Struktur Data
 *************************************************************/

#include <iostream>
#include <cstring>

// Config dan Types
#include "../include/config.h"
#include "../include/common_types.h"

// Struktur Data
#include "../include/structures/linkedlist.h"
#include "../include/structures/stack.h"
#include "../include/structures/queue.h"
#include "../include/structures/bst.h"

// Core Utilities
#include "../include/core/file_io.h"
#include "../include/core/validator.h"

// Auth System
#include "../include/auth/session.h"
#include "../include/auth/auth_service.h"

// Admin Module
#include "../include/admin/manager_buku.h"
#include "../include/admin/manager_user.h"
#include "../include/admin/laporan.h"
#include "../include/admin/admin_menu.h"

// User Module
#include "../include/user/transaksi.h"
#include "../include/user/user_menu.h"

using namespace LibSystem;

// ==================== FUNGSI PROTOTYPES ====================
void tampilkanHeader();
void tampilkanMenuUtama();
void menuLogin(LinkedList<User>& listUser);
void menuRegister(LinkedList<User>& listUser);
void inisialisasiData(LinkedList<User>& listUser, 
                      LinkedList<Buku>& listBuku,
                      LinkedList<Peminjaman>& listPinjam);
void simpanSemuaData(LinkedList<User>& listUser, 
                     LinkedList<Buku>& listBuku,
                     LinkedList<Peminjaman>& listPinjam);
void buatDataAwal(LinkedList<User>& listUser, LinkedList<Buku>& listBuku);

// ==================== MAIN FUNCTION ====================
int main() {
    // ========== DEKLARASI STRUKTUR DATA ==========
    
    // LinkedList untuk data utama
    LinkedList<User> listUser;
    LinkedList<Buku> listBuku;
    LinkedList<Peminjaman> listPinjam;
    
    // Stack untuk activity log
    Stack<SessionLog> activityLog;
    
    // Queue untuk antrian reservasi buku
    Queue<AntrianBuku> antrianBuku;
    
    // BST untuk index pencarian buku (by ID)
    BST<Buku> indexBuku;
    
    // ========== INISIALISASI DATA ==========
    
    Validator::clearScreen();
    std::cout << "\n[System] Memuat data...\n";
    
    inisialisasiData(listUser, listBuku, listPinjam);
    
    // Build BST index untuk buku
    Node<Buku>* bukuCurr = listBuku.getHead();
    while (bukuCurr != NULL) {
        indexBuku.insert(bukuCurr->data.id, bukuCurr);
        bukuCurr = bukuCurr->next;
    }
    
    std::cout << "[System] Data berhasil dimuat!\n";
    std::cout << "         - " << listUser.getSize() << " user\n";
    std::cout << "         - " << listBuku.getSize() << " buku\n";
    std::cout << "         - " << listPinjam.getSize() << " transaksi\n";
    
    Validator::pause();
    
    // ========== INISIALISASI MANAGER ==========
    
    ManagerBuku managerBuku(listBuku, indexBuku);
    ManagerUser managerUser(listUser, activityLog);
    TransaksiManager transaksiManager(listPinjam, listBuku, listUser, antrianBuku);
    Laporan laporan(listPinjam, listBuku, listUser);
    
    // ========== MENU UTAMA ==========
    
    int pilihan;
    bool running = true;
    
    while (running) {
        Validator::clearScreen();
        tampilkanHeader();
        tampilkanMenuUtama();
        
        pilihan = Validator::getIntInput("Pilih menu: ");
        
        switch (pilihan) {
            case 1: {
                // LOGIN
                menuLogin(listUser);
                
                if (Session::isLoggedIn()) {
                    // Log aktivitas login
                    managerUser.tambahLog("Login ke sistem");
                    
                    if (Session::isAdmin()) {
                        // Menu Admin
                        AdminMenu adminMenu(managerBuku, managerUser, laporan, transaksiManager);
                        adminMenu.tampilkanMenu();
                    } else {
                        // Menu User
                        UserMenu userMenu(managerBuku, transaksiManager);
                        userMenu.tampilkanMenu();
                    }
                    
                    // Setelah logout, simpan data
                    simpanSemuaData(listUser, listBuku, listPinjam);
                    Session::clearSession();
                }
                break;
            }
            
            case 2: {
                // REGISTER
                menuRegister(listUser);
                break;
            }
            
            case 0: {
                // EXIT
                if (Validator::konfirmasi("Yakin ingin keluar dari program?")) {
                    std::cout << "\n[System] Menyimpan data...\n";
                    simpanSemuaData(listUser, listBuku, listPinjam);
                    
                    std::cout << "\n";
                    std::cout << "+------------------------------------------+\n";
                    std::cout << "�     Terima kasih telah menggunakan       �\n";
                    std::cout << "�       Sistem Perpustakaan Digital        �\n";
                    std::cout << "�                                          �\n";
                    std::cout << "�           Sampai Jumpa! ??               �\n";
                    std::cout << "+------------------------------------------+\n\n";
                    
                    running = false;
                }
                break;
            }
            
            default:
                std::cout << "\n[!] Pilihan tidak valid!\n";
                Validator::pause();
        }
    }
    
    return 0;
}

// ==================== IMPLEMENTASI FUNGSI ====================

void tampilkanHeader() {
    std::cout << "\n";
    std::cout << "+----------------------------------------------------------+\n";
    std::cout << "�                                                          �\n";
    std::cout << "�     ������+ �������+������+ ������+ ��+   ��+�������+    �\n";
    std::cout << "�     ��+--��+��+----+��+--��+��+--��+���   �����+----+    �\n";
    std::cout << "�     ������++�����+  ������++������++���   ����������+    �\n";
    std::cout << "�     ��+---+ ��+--+  ��+--��+��+---+ ���   ���+----���    �\n";
    std::cout << "�     ���     �������+���  ������     +������++��������    �\n";
    std::cout << "�     +-+     +------++-+  +-++-+      +-----+ +------+    �\n";
    std::cout << "�                                                          �\n";
    std::cout << "�           SISTEM MANAJEMEN PERPUSTAKAAN DIGITAL          �\n";
    std::cout << "�                                                          �\n";
    std::cout << "�----------------------------------------------------------�\n";
    std::cout << "�                         Kelompok 14                      �\n";
    std::cout << "+----------------------------------------------------------+\n";
}

void tampilkanMenuUtama() {
    std::cout << "\n";
    std::cout << "  +----------------------------+\n";
    std::cout << "  �       MENU UTAMA           �\n";
    std::cout << "  +----------------------------�\n";
    std::cout << "  �  1. Login                  �\n";
    std::cout << "  �  2. Register (User Baru)   �\n";
    std::cout << "  �  0. Keluar                 �\n";
    std::cout << "  +----------------------------+\n";
    std::cout << "\n";
}

void menuLogin(LinkedList<User>& listUser) {
    Validator::clearScreen();
    
    std::cout << "\n";
    std::cout << "+------------------------------------------+\n";
    std::cout << "�                 LOGIN                    �\n";
    std::cout << "+------------------------------------------+\n\n";
    
    char username[MAX_USERNAME];
    char password[MAX_PASSWORD];
    
    Validator::getStringInputRequired("Username: ", username, MAX_USERNAME);
    Validator::getStringInputRequired("Password: ", password, MAX_PASSWORD);
    
    std::cout << "\n";
    
    if (AuthService::login(listUser, username, password)) {
        std::cout << "\n[OK] Login berhasil!\n";
        std::cout << "     Selamat datang, " << Session::getCurrentUser()->namaLengkap << "!\n";
        std::cout << "     Role: " << Session::getCurrentUser()->role << "\n";
        Validator::pause();
    } else {
        Validator::pause();
    }
}

void menuRegister(LinkedList<User>& listUser) {
    Validator::clearScreen();
    
    std::cout << "\n";
    std::cout << "+------------------------------------------+\n";
    std::cout << "�           REGISTRASI USER BARU           �\n";
    std::cout << "+------------------------------------------+\n\n";
    
    char username[MAX_USERNAME];
    char password[MAX_PASSWORD];
    char namaLengkap[50];
    char noTelp[15];
    
    std::cout << "Syarat:\n";
    std::cout << "  - Username: minimal 4 karakter, alfanumerik\n";
    std::cout << "  - Password: minimal 6 karakter\n\n";
    
    Validator::getStringInputRequired("Username     : ", username, MAX_USERNAME);
    Validator::getStringInputRequired("Password     : ", password, MAX_PASSWORD);
    Validator::getStringInputRequired("Nama Lengkap : ", namaLengkap, 50);
    Validator::getStringInput("No. Telepon  : ", noTelp, 15);
    
    std::cout << "\n";
    
    if (Validator::konfirmasi("Daftarkan akun ini?")) {
        if (AuthService::registerUser(listUser, username, password, namaLengkap, noTelp)) {
            // Simpan ke file
            FileIO::saveUsers(listUser);
        }
    } else {
        std::cout << "[Info] Registrasi dibatalkan.\n";
    }
    
    Validator::pause();
}

void inisialisasiData(LinkedList<User>& listUser, 
                      LinkedList<Buku>& listBuku,
                      LinkedList<Peminjaman>& listPinjam) {
    
    // Coba load dari file
    bool userLoaded = FileIO::loadUsers(listUser);
    bool bukuLoaded = FileIO::loadBuku(listBuku);
    bool pinjamLoaded = FileIO::loadPeminjaman(listPinjam);
    
    // Jika tidak ada data, buat data awal
    if (!userLoaded || listUser.isEmpty()) {
        std::cout << "[Info] Membuat data awal...\n";
        buatDataAwal(listUser, listBuku);
        
        // Simpan data awal
        FileIO::saveUsers(listUser);
        FileIO::saveBuku(listBuku);
    }
}

void simpanSemuaData(LinkedList<User>& listUser, 
                     LinkedList<Buku>& listBuku,
                     LinkedList<Peminjaman>& listPinjam) {
    
    FileIO::saveUsers(listUser);
    FileIO::saveBuku(listBuku);
    FileIO::savePeminjaman(listPinjam);
    
    std::cout << "[OK] Semua data berhasil disimpan.\n";
}

void buatDataAwal(LinkedList<User>& listUser, LinkedList<Buku>& listBuku) {
    
    // ========== ADMIN DEFAULT ==========
    User admin;
    admin.id = 1;
    strcpy(admin.username, "admin");
    strcpy(admin.password, "admin123");
    strcpy(admin.namaLengkap, "Administrator");
    strcpy(admin.role, ROLE_ADMIN);
    strcpy(admin.noTelp, "081234567890");
    admin.aktif = true;
    listUser.pushBack(admin);
    
    // ========== USER SAMPLE ==========
    User user1;
    user1.id = 2;
    strcpy(user1.username, "budi");
    strcpy(user1.password, "budi123");
    strcpy(user1.namaLengkap, "Budi Santoso");
    strcpy(user1.role, ROLE_USER);
    strcpy(user1.noTelp, "081111111111");
    user1.aktif = true;
    listUser.pushBack(user1);
    
    User user2;
    user2.id = 3;
    strcpy(user2.username, "ani");
    strcpy(user2.password, "ani123");
    strcpy(user2.namaLengkap, "Ani Wijaya");
    strcpy(user2.role, ROLE_USER);
    strcpy(user2.noTelp, "082222222222");
    user2.aktif = true;
    listUser.pushBack(user2);
    
    // ========== BUKU SAMPLE ==========
    Buku b1;
    b1.id = 1;
    strcpy(b1.judul, "Pemrograman C++ untuk Pemula");
    strcpy(b1.penulis, "Rinaldi Munir");
    strcpy(b1.kategori, "Pemrograman");
    b1.tahunTerbit = 2020;
    b1.stok = 5;
    b1.stokAwal = 5;
    b1.tersedia = true;
    listBuku.pushBack(b1);
    
    Buku b2;
    b2.id = 2;
    strcpy(b2.judul, "Struktur Data dan Algoritma");
    strcpy(b2.penulis, "Thomas H. Cormen");
    strcpy(b2.kategori, "Pemrograman");
    b2.tahunTerbit = 2019;
    b2.stok = 3;
    b2.stokAwal = 3;
    b2.tersedia = true;
    listBuku.pushBack(b2);
    
    Buku b3;
    b3.id = 3;
    strcpy(b3.judul, "Laskar Pelangi");
    strcpy(b3.penulis, "Andrea Hirata");
    strcpy(b3.kategori, "Novel");
    b3.tahunTerbit = 2005;
    b3.stok = 4;
    b3.stokAwal = 4;
    b3.tersedia = true;
    listBuku.pushBack(b3);
    
    Buku b4;
    b4.id = 4;
    strcpy(b4.judul, "Bumi Manusia");
    strcpy(b4.penulis, "Pramoedya Ananta Toer");
    strcpy(b4.kategori, "Novel");
    b4.tahunTerbit = 1980;
    b4.stok = 2;
    b4.stokAwal = 2;
    b4.tersedia = true;
    listBuku.pushBack(b4);
    
    Buku b5;
    b5.id = 5;
    strcpy(b5.judul, "Filosofi Teras");
    strcpy(b5.penulis, "Henry Manampiring");
    strcpy(b5.kategori, "Self-Help");
    b5.tahunTerbit = 2018;
    b5.stok = 3;
    b5.stokAwal = 3;
    b5.tersedia = true;
    listBuku.pushBack(b5);
    
    Buku b6;
    b6.id = 6;
    strcpy(b6.judul, "Atomic Habits");
    strcpy(b6.penulis, "James Clear");
    strcpy(b6.kategori, "Self-Help");
    b6.tahunTerbit = 2018;
    b6.stok = 4;
    b6.stokAwal = 4;
    b6.tersedia = true;
    listBuku.pushBack(b6);
    
    Buku b7;
    b7.id = 7;
    strcpy(b7.judul, "Sejarah Indonesia Modern");
    strcpy(b7.penulis, "M.C. Ricklefs");
    strcpy(b7.kategori, "Sejarah");
    b7.tahunTerbit = 2008;
    b7.stok = 2;
    b7.stokAwal = 2;
    b7.tersedia = true;
    listBuku.pushBack(b7);
    
    Buku b8;
    b8.id = 8;
    strcpy(b8.judul, "Fisika Dasar");
    strcpy(b8.penulis, "Halliday & Resnick");
    strcpy(b8.kategori, "Sains");
    b8.tahunTerbit = 2015;
    b8.stok = 3;
    b8.stokAwal = 3;
    b8.tersedia = true;
    listBuku.pushBack(b8);
    
    Buku b9;
    b9.id = 9;
    strcpy(b9.judul, "Kalkulus Jilid 1");
    strcpy(b9.penulis, "Purcell & Varberg");
    strcpy(b9.kategori, "Matematika");
    b9.tahunTerbit = 2010;
    b9.stok = 5;
    b9.stokAwal = 5;
    b9.tersedia = true;
    listBuku.pushBack(b9);
    
    Buku b10;
    b10.id = 10;
    strcpy(b10.judul, "Database System Concepts");
    strcpy(b10.penulis, "Silberschatz");
    strcpy(b10.kategori, "Pemrograman");
    b10.tahunTerbit = 2019;
    b10.stok = 3;
    b10.stokAwal = 3;
    b10.tersedia = true;
    listBuku.pushBack(b10);
    
    std::cout << "[OK] Data awal berhasil dibuat.\n";
    std::cout << "     Admin default: admin / admin123\n";
    std::cout << "     User sample  : budi / budi123\n";
    std::cout << "                  : ani / ani123\n";
}
