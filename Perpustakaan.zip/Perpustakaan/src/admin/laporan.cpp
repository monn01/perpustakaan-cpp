/*************************************************************
 * laporan.cpp
 * Implementasi Modul Laporan dan Statistik
 *************************************************************/

#include "../../include/admin/laporan.h"
#include "../../include/config.h"
#include <iostream>
#include <iomanip>
#include <cstring>

namespace LibSystem {

    // Constructor
    Laporan::Laporan(LinkedList<Peminjaman>& lp, LinkedList<Buku>& lb, LinkedList<User>& lu)
        : listPinjam(lp), listBuku(lb), listUser(lu) {}

    // ============ PRINT HELPERS ============

    void Laporan::printSeparator() {
        std::cout << "+-------+----------+------------------------------+------------+------------+--------+-----------+\n";
    }

    void Laporan::printTransaksiHeader() {
        printSeparator();
        std::cout << "| " << std::left << std::setw(5) << "ID" << " | "
                  << std::setw(8) << "User" << " | "
                  << std::setw(28) << "Judul Buku" << " | "
                  << std::setw(10) << "Tgl Pinjam" << " | "
                  << std::setw(10) << "Tgl Kembali" << " | "
                  << std::setw(6) << "Status" << " | "
                  << std::setw(9) << "Denda" << " |\n";
        printSeparator();
    }

    void Laporan::printTransaksiRow(const Peminjaman& p) {
        char judulShort[29];
        const char* judul = getJudulBuku(p.idBuku);
        strncpy(judulShort, judul, 28);
        judulShort[28] = '\0';
        
        char tglPinjamShort[11], tglKembaliShort[11];
        strncpy(tglPinjamShort, p.tglPinjam, 10);
        tglPinjamShort[10] = '\0';
        
        if (p.sudahKembali) {
            strncpy(tglKembaliShort, p.tglKembali, 10);
        } else {
            strcpy(tglKembaliShort, "-");
        }
        tglKembaliShort[10] = '\0';
        
        std::cout << "| " << std::left << std::setw(5) << p.idTransaksi << " | "
                  << std::setw(8) << getUsername(p.idUser) << " | "
                  << std::setw(28) << judulShort << " | "
                  << std::setw(10) << tglPinjamShort << " | "
                  << std::setw(10) << tglKembaliShort << " | "
                  << std::setw(6) << (p.sudahKembali ? "Selesai" : "Aktif") << " | "
                  << "Rp" << std::setw(6) << p.denda << " |\n";
    }

    const char* Laporan::getJudulBuku(int idBuku) {
        Node<Buku>* current = listBuku.getHead();
        while (current != NULL) {
            if (current->data.id == idBuku) {
                return current->data.judul;
            }
            current = current->next;
        }
        return "Buku Tidak Ditemukan";
    }

    const char* Laporan::getUsername(int idUser) {
        Node<User>* current = listUser.getHead();
        while (current != NULL) {
            if (current->data.id == idUser) {
                return current->data.username;
            }
            current = current->next;
        }
        return "Unknown";
    }

    int Laporan::hitungPeminjamanBuku(int idBuku) {
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        while (current != NULL) {
            if (current->data.idBuku == idBuku) {
                count++;
            }
            current = current->next;
        }
        return count;
    }

    // ============ LAPORAN TRANSAKSI ============

    void Laporan::tampilkanSemuaTransaksi() {
        if (listPinjam.isEmpty()) {
            std::cout << "\n[Info] Belum ada transaksi peminjaman.\n";
            return;
        }

        std::cout << "\n=============== LAPORAN SEMUA TRANSAKSI ===============\n";
        std::cout << "Total: " << listPinjam.getSize() << " transaksi\n\n";
        
        printTransaksiHeader();
        
        Node<Peminjaman>* current = listPinjam.getHead();
        while (current != NULL) {
            printTransaksiRow(current->data);
            current = current->next;
        }
        
        printSeparator();
    }

    void Laporan::tampilkanTransaksiAktif() {
        if (listPinjam.isEmpty()) {
            std::cout << "\n[Info] Belum ada transaksi peminjaman.\n";
            return;
        }

        std::cout << "\n========== TRANSAKSI AKTIF (Belum Dikembalikan) ==========\n";
        
        printTransaksiHeader();
        
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        while (current != NULL) {
            if (!current->data.sudahKembali) {
                printTransaksiRow(current->data);
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        std::cout << "Total " << count << " transaksi aktif.\n";
    }

    void Laporan::tampilkanTransaksiSelesai() {
        if (listPinjam.isEmpty()) {
            std::cout << "\n[Info] Belum ada transaksi peminjaman.\n";
            return;
        }

        std::cout << "\n========== TRANSAKSI SELESAI ==========\n";
        
        printTransaksiHeader();
        
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        while (current != NULL) {
            if (current->data.sudahKembali) {
                printTransaksiRow(current->data);
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        std::cout << "Total " << count << " transaksi selesai.\n";
    }

    void Laporan::tampilkanTransaksiByUser(int idUser) {
        std::cout << "\n====== Transaksi User: " << getUsername(idUser) << " ======\n";
        
        printTransaksiHeader();
        
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        while (current != NULL) {
            if (current->data.idUser == idUser) {
                printTransaksiRow(current->data);
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        
        if (count == 0) {
            std::cout << "User ini belum pernah meminjam buku.\n";
        } else {
            std::cout << "Total " << count << " transaksi.\n";
        }
    }

    // ============ LAPORAN DENDA ============

    void Laporan::tampilkanDaftarDenda() {
        std::cout << "\n=============== DAFTAR DENDA ===============\n";
        
        bool adaDenda = false;
        long totalLunas = 0;
        long totalBelum = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        std::cout << "+-------+----------+------------------------------+-----------+--------+\n";
        std::cout << "| " << std::left << std::setw(5) << "ID" << " | "
                  << std::setw(8) << "User" << " | "
                  << std::setw(28) << "Judul Buku" << " | "
                  << std::setw(9) << "Denda" << " | "
                  << std::setw(6) << "Status" << " |\n";
        std::cout << "+-------+----------+------------------------------+-----------+--------+\n";
        
        while (current != NULL) {
            if (current->data.denda > 0) {
                char judulShort[29];
                strncpy(judulShort, getJudulBuku(current->data.idBuku), 28);
                judulShort[28] = '\0';
                
                const char* status = current->data.dendaDibayar ? "Lunas" : "Belum";
                
                std::cout << "| " << std::left << std::setw(5) << current->data.idTransaksi << " | "
                          << std::setw(8) << getUsername(current->data.idUser) << " | "
                          << std::setw(28) << judulShort << " | "
                          << "Rp" << std::setw(6) << current->data.denda << " | "
                          << std::setw(6) << status << " |\n";
                adaDenda = true;
                
                if (current->data.dendaDibayar) {
                    totalLunas += current->data.denda;
                } else {
                    totalBelum += current->data.denda;
                }
            }
            current = current->next;
        }
        
        std::cout << "+-------+----------+------------------------------+-----------+--------+\n";
        
        if (!adaDenda) {
            std::cout << "Tidak ada denda.\n";
        } else {
            std::cout << "\nRingkasan Denda:\n";
            std::cout << "  Denda sudah dibayar : Rp " << totalLunas << "\n";
            std::cout << "  Denda belum dibayar : Rp " << totalBelum << "\n";
            std::cout << "  Total               : Rp " << (totalLunas + totalBelum) << "\n";
        }
    }

    long Laporan::hitungTotalDenda() {
        long total = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            total += current->data.denda;
            current = current->next;
        }
        
        return total;
    }

    long Laporan::hitungDendaBelumBayar() {
        long total = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (!current->data.sudahKembali && current->data.denda > 0) {
                total += current->data.denda;
            }
            current = current->next;
        }
        
        return total;
    }

    // ============ STATISTIK BUKU ============

    void Laporan::tampilkanBukuTerpopuler(int top) {
        if (listBuku.isEmpty()) {
            std::cout << "\n[Info] Belum ada buku dalam koleksi.\n";
            return;
        }

        std::cout << "\n========== TOP " << top << " BUKU TERPOPULER ==========\n\n";
        
        // Buat array untuk sorting sederhana
        const int MAX = 100;
        int idBuku[MAX], jumlahPinjam[MAX];
        int count = 0;
        
        Node<Buku>* curr = listBuku.getHead();
        while (curr != NULL && count < MAX) {
            idBuku[count] = curr->data.id;
            jumlahPinjam[count] = hitungPeminjamanBuku(curr->data.id);
            count++;
            curr = curr->next;
        }
        
        // Simple bubble sort (descending)
        for (int i = 0; i < count - 1; i++) {
            for (int j = 0; j < count - i - 1; j++) {
                if (jumlahPinjam[j] < jumlahPinjam[j + 1]) {
                    // Swap
                    int tempId = idBuku[j];
                    int tempJml = jumlahPinjam[j];
                    idBuku[j] = idBuku[j + 1];
                    jumlahPinjam[j] = jumlahPinjam[j + 1];
                    idBuku[j + 1] = tempId;
                    jumlahPinjam[j + 1] = tempJml;
                }
            }
        }
        
        // Tampilkan top N
        std::cout << "+------+--------------------------------+---------------+\n";
        std::cout << "| Rank | Judul Buku                     | Jml Dipinjam  |\n";
        std::cout << "+------+--------------------------------+---------------+\n";
        
        for (int i = 0; i < top && i < count; i++) {
            char judulShort[31];
            strncpy(judulShort, getJudulBuku(idBuku[i]), 30);
            judulShort[30] = '\0';
            
            std::cout << "| " << std::left << std::setw(4) << (i + 1) << " | "
                      << std::setw(30) << judulShort << " | "
                      << std::setw(13) << jumlahPinjam[i] << " |\n";
        }
        
        std::cout << "+------+--------------------------------+---------------+\n";
    }

    void Laporan::tampilkanBukuDipinjam() {
        std::cout << "\n========== BUKU YANG SEDANG DIPINJAM ==========\n";
        
        std::cout << "+------+--------------------------------+----------------+\n";
        std::cout << "| ID   | Judul Buku                     | Dipinjam Oleh  |\n";
        std::cout << "+------+--------------------------------+----------------+\n";
        
        int count = 0;
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            if (!current->data.sudahKembali) {
                char judulShort[31];
                strncpy(judulShort, getJudulBuku(current->data.idBuku), 30);
                judulShort[30] = '\0';
                
                std::cout << "| " << std::left << std::setw(4) << current->data.idBuku << " | "
                          << std::setw(30) << judulShort << " | "
                          << std::setw(14) << getUsername(current->data.idUser) << " |\n";
                count++;
            }
            current = current->next;
        }
        
        std::cout << "+------+--------------------------------+----------------+\n";
        std::cout << "Total " << count << " buku sedang dipinjam.\n";
    }

    void Laporan::tampilkanStatistikKategori() {
        std::cout << "\n========== STATISTIK PER KATEGORI ==========\n\n";
        
        // Simple counting (max 20 kategori)
        const int MAX_KAT = 20;
        char kategori[MAX_KAT][30];
        int jumlah[MAX_KAT];
        int numKat = 0;
        
        Node<Buku>* curr = listBuku.getHead();
        while (curr != NULL) {
            // Cek apakah kategori sudah ada
            bool found = false;
            for (int i = 0; i < numKat; i++) {
                if (strcmp(kategori[i], curr->data.kategori) == 0) {
                    jumlah[i]++;
                    found = true;
                    break;
                }
            }
            
            // Tambah kategori baru
            if (!found && numKat < MAX_KAT) {
                strncpy(kategori[numKat], curr->data.kategori, 29);
                jumlah[numKat] = 1;
                numKat++;
            }
            
            curr = curr->next;
        }
        
        // Tampilkan
        std::cout << "+----------------------+----------+\n";
        std::cout << "| Kategori             | Jumlah   |\n";
        std::cout << "+----------------------+----------+\n";
        
        for (int i = 0; i < numKat; i++) {
            std::cout << "| " << std::left << std::setw(20) << kategori[i] << " | "
                      << std::setw(8) << jumlah[i] << " |\n";
        }
        
        std::cout << "+----------------------+----------+\n";
    }

    // ============ RINGKASAN SISTEM ============

    void Laporan::tampilkanDashboard() {
        std::cout << "\n";
        std::cout << "+----------------------------------------------------------+\n";
        std::cout << "�              DASHBOARD SISTEM PERPUSTAKAAN               �\n";
        std::cout << "�----------------------------------------------------------�\n";
        
        // Statistik Buku
        int totalBuku = listBuku.getSize();
        int bukuTersedia = 0;
        int totalStok = 0;
        Node<Buku>* bCurr = listBuku.getHead();
        while (bCurr != NULL) {
            if (bCurr->data.tersedia) bukuTersedia++;
            totalStok += bCurr->data.stok;
            bCurr = bCurr->next;
        }
        
        std::cout << "�  BUKU                                                     �\n";
        std::cout << "�    Total Judul     : " << std::left << std::setw(37) << totalBuku << "�\n";
        std::cout << "�    Buku Tersedia   : " << std::left << std::setw(37) << bukuTersedia << "�\n";
        std::cout << "�    Total Stok      : " << std::left << std::setw(37) << totalStok << "�\n";
        
        std::cout << "�----------------------------------------------------------�\n";
        
        // Statistik User
        int totalUser = listUser.getSize();
        int userAktif = 0;
        Node<User>* uCurr = listUser.getHead();
        while (uCurr != NULL) {
            if (uCurr->data.aktif) userAktif++;
            uCurr = uCurr->next;
        }
        
        std::cout << "�  USER                                                     �\n";
        std::cout << "�    Total User      : " << std::left << std::setw(37) << totalUser << "�\n";
        std::cout << "�    User Aktif      : " << std::left << std::setw(37) << userAktif << "�\n";
        
        std::cout << "�----------------------------------------------------------�\n";
        
        // Statistik Transaksi
        int totalTransaksi = listPinjam.getSize();
        int transaksiAktif = 0;
        Node<Peminjaman>* pCurr = listPinjam.getHead();
        while (pCurr != NULL) {
            if (!pCurr->data.sudahKembali) transaksiAktif++;
            pCurr = pCurr->next;
        }
        
        std::cout << "�  TRANSAKSI                                                �\n";
        std::cout << "�    Total Transaksi : " << std::left << std::setw(37) << totalTransaksi << "�\n";
        std::cout << "�    Sedang Dipinjam : " << std::left << std::setw(37) << transaksiAktif << "�\n";
        
        char dendaStr[40];
        snprintf(dendaStr, 40, "Rp %ld", hitungTotalDenda());
        std::cout << "�    Total Denda     : " << std::left << std::setw(37) << dendaStr << "�\n";
        
        std::cout << "+----------------------------------------------------------+\n";
    }

    void Laporan::tampilkanStatistikLengkap() {
        tampilkanDashboard();
        std::cout << "\n";
        tampilkanBukuTerpopuler(5);
        std::cout << "\n";
        tampilkanStatistikKategori();
    }

}
