/*************************************************************
 * admin_menu.cpp
 * Implementasi Menu Utama Admin
 *************************************************************/

#include "../../include/admin/admin_menu.h"
#include "../../include/auth/session.h"
#include "../../include/auth/auth_service.h"
#include "../../include/core/validator.h"
#include "../../include/core/file_io.h"
#include "../../include/config.h"
#include <iostream>
#include <iomanip>
#include <cstring>

namespace LibSystem {

    // Constructor
    AdminMenu::AdminMenu(ManagerBuku& mb, ManagerUser& mu, Laporan& lap, TransaksiManager& tm)
        : managerBuku(mb), managerUser(mu), laporan(lap), transaksiManager(tm) {}

    // ============ MENU UTAMA ============

    void AdminMenu::tampilkanMenu() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            std::cout << "\n";
            std::cout << "+==========================================+\n";
            std::cout << "|       PANEL ADMIN PERPUSTAKAAN           |\n";
            std::cout << "+==========================================+\n";
            std::cout << "|  Selamat datang, " << std::left << std::setw(22) 
                      << Session::getCurrentUsername() << "  |\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "|  1. Kelola Buku                          |\n";
            std::cout << "|  2. Kelola User                          |\n";
            std::cout << "|  3. Kelola Denda                         |\n";
            std::cout << "|  4. Laporan & Statistik                  |\n";
            std::cout << "|  5. Pengaturan                           |\n";
            std::cout << "|  0. Logout                               |\n";
            std::cout << "+==========================================+\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    menuKelolaBuku();
                    break;
                case 2:
                    menuKelolaUser();
                    break;
                case 3:
                    menuKelolaDenda();
                    break;
                case 4:
                    menuLaporan();
                    break;
                case 5:
                    menuPengaturan();
                    break;
                case 0:
                    if (Validator::konfirmasi("Yakin ingin logout?")) {
                        managerUser.tambahLog("Logout dari sistem");
                        std::cout << "\n[OK] Logout berhasil. Sampai jumpa!\n";
                    } else {
                        pilihan = -1;  // Cancel logout
                    }
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ SUB-MENU KELOLA BUKU ============

    void AdminMenu::menuKelolaBuku() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            std::cout << "\n";
            std::cout << "+==========================================+\n";
            std::cout << "|          KELOLA DATA BUKU                |\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "|  1. Lihat Semua Buku                     |\n";
            std::cout << "|  2. Tambah Buku Baru                     |\n";
            std::cout << "|  3. Edit Data Buku                       |\n";
            std::cout << "|  4. Hapus Buku                           |\n";
            std::cout << "|  5. Cari Buku                            |\n";
            std::cout << "|  6. Update Stok Buku                     |\n";
            std::cout << "|  0. Kembali                              |\n";
            std::cout << "+==========================================+\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    managerBuku.tampilkanSemuaBuku();
                    Validator::pause();
                    break;
                case 2:
                    formTambahBuku();
                    break;
                case 3:
                    formEditBuku();
                    break;
                case 4:
                    formHapusBuku();
                    break;
                case 5:
                    formCariBuku();
                    break;
                case 6: {
                    managerBuku.tampilkanSemuaBuku();
                    int id = Validator::getIntInput("\nMasukkan ID Buku: ");
                    int stok = Validator::getIntInput("Stok baru: ");
                    managerBuku.updateStok(id, stok);
                    managerUser.tambahLog("Update stok buku");
                    Validator::pause();
                    break;
                }
                case 0:
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ SUB-MENU KELOLA USER ============

    void AdminMenu::menuKelolaUser() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            std::cout << "\n";
            std::cout << "+==========================================+\n";
            std::cout << "|          KELOLA DATA USER                |\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "|  1. Lihat Semua User                     |\n";
            std::cout << "|  2. Tambah User/Admin Baru               |\n";
            std::cout << "|  3. Edit Data User                       |\n";
            std::cout << "|  4. Aktifkan/Nonaktifkan User            |\n";
            std::cout << "|  5. Reset Password User                  |\n";
            std::cout << "|  6. Lihat Riwayat Aktivitas              |\n";
            std::cout << "|  0. Kembali                              |\n";
            std::cout << "+==========================================+\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    managerUser.tampilkanSemuaUser();
                    Validator::pause();
                    break;
                case 2:
                    formTambahUser();
                    break;
                case 3:
                    formEditUser();
                    break;
                case 4: {
                    managerUser.tampilkanSemuaUser();
                    int id = Validator::getIntInput("\nMasukkan ID User: ");
                    int aksi = Validator::getIntInput("1=Aktifkan, 2=Nonaktifkan: ");
                    if (aksi == 1) {
                        managerUser.aktifkanUser(id);
                    } else if (aksi == 2) {
                        managerUser.nonaktifkanUser(id);
                    }
                    Validator::pause();
                    break;
                }
                case 5:
                    formResetPassword();
                    break;
                case 6:
                    managerUser.tampilkanRiwayatAktivitas();
                    Validator::pause();
                    break;
                case 0:
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ SUB-MENU LAPORAN ============

    void AdminMenu::menuLaporan() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            std::cout << "\n";
            std::cout << "+==========================================+\n";
            std::cout << "|        LAPORAN & STATISTIK               |\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "|  1. Dashboard Ringkasan                  |\n";
            std::cout << "|  2. Laporan Semua Transaksi              |\n";
            std::cout << "|  3. Transaksi Aktif (Belum Kembali)      |\n";
            std::cout << "|  4. Daftar Denda                         |\n";
            std::cout << "|  5. Buku Terpopuler                      |\n";
            std::cout << "|  6. Statistik per Kategori               |\n";
            std::cout << "|  7. Statistik Lengkap                    |\n";
            std::cout << "|  0. Kembali                              |\n";
            std::cout << "+==========================================+\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    laporan.tampilkanDashboard();
                    Validator::pause();
                    break;
                case 2:
                    laporan.tampilkanSemuaTransaksi();
                    Validator::pause();
                    break;
                case 3:
                    laporan.tampilkanTransaksiAktif();
                    Validator::pause();
                    break;
                case 4:
                    laporan.tampilkanDaftarDenda();
                    Validator::pause();
                    break;
                case 5: {
                    int top = Validator::getIntInputRange("Tampilkan top berapa? (1-20): ", 1, 20);
                    laporan.tampilkanBukuTerpopuler(top);
                    Validator::pause();
                    break;
                }
                case 6:
                    laporan.tampilkanStatistikKategori();
                    Validator::pause();
                    break;
                case 7:
                    laporan.tampilkanStatistikLengkap();
                    Validator::pause();
                    break;
                case 0:
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ SUB-MENU PENGATURAN ============

    void AdminMenu::menuPengaturan() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            std::cout << "\n";
            std::cout << "+==========================================+\n";
            std::cout << "|            PENGATURAN                    |\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "|  1. Simpan Data ke File                  |\n";
            std::cout << "|  2. Lihat Info Session                   |\n";
            std::cout << "|  3. Ganti Password Saya                  |\n";
            std::cout << "|  4. Bersihkan Log Aktivitas              |\n";
            std::cout << "|  0. Kembali                              |\n";
            std::cout << "+==========================================+\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    std::cout << "\nMenyimpan data...\n";
                    FileIO::saveBuku(managerBuku.getListBuku());
                    FileIO::saveUsers(managerUser.getListUser());
                    std::cout << MSG_SAVE_SUCCESS << "\n";
                    managerUser.tambahLog("Menyimpan data ke file");
                    Validator::pause();
                    break;
                case 2:
                    Session::displaySessionInfo();
                    Validator::pause();
                    break;
                case 3: {
                    char oldPass[MAX_PASSWORD], newPass[MAX_PASSWORD];
                    Validator::getStringInputRequired("Password lama: ", oldPass, MAX_PASSWORD);
                    Validator::getStringInputRequired("Password baru: ", newPass, MAX_PASSWORD);
                    AuthService::changePassword(managerUser.getListUser(), oldPass, newPass);
                    Validator::pause();
                    break;
                }
                case 4:
                    if (Validator::konfirmasi("Yakin hapus semua log aktivitas?")) {
                        managerUser.clearLog();
                    }
                    Validator::pause();
                    break;
                case 0:
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    // ============ FORM INPUT ============

    void AdminMenu::formTambahBuku() {
        Validator::clearScreen();
        std::cout << "\n====== TAMBAH BUKU BARU ======\n\n";
        
        char judul[MAX_JUDUL], penulis[MAX_PENULIS], kategori[30];
        int tahun, stok;
        
        Validator::getStringInputRequired("Judul Buku    : ", judul, MAX_JUDUL);
        Validator::getStringInputRequired("Penulis       : ", penulis, MAX_PENULIS);
        Validator::getStringInputRequired("Kategori      : ", kategori, 30);
        tahun = Validator::getIntInputRange("Tahun Terbit  : ", 1800, 2030);
        stok = Validator::getIntInputRange("Jumlah Stok   : ", 0, 1000);
        
        std::cout << "\n";
        if (Validator::konfirmasi("Simpan data buku ini?")) {
            if (managerBuku.tambahBuku(judul, penulis, kategori, tahun, stok)) {
                managerUser.tambahLog("Menambah buku baru");
            }
        } else {
            std::cout << "[Info] Dibatalkan.\n";
        }
        
        Validator::pause();
    }

    void AdminMenu::formEditBuku() {
        managerBuku.tampilkanSemuaBuku();
        
        int id = Validator::getIntInput("\nMasukkan ID Buku yang akan diedit: ");
        
        Node<Buku>* buku = managerBuku.cariBukuById(id);
        if (buku == NULL) {
            std::cout << "[!] Buku tidak ditemukan.\n";
            Validator::pause();
            return;
        }
        
        std::cout << "\nData saat ini:\n";
        managerBuku.tampilkanDetailBuku(id);
        
        std::cout << "\nMasukkan data baru (kosongkan jika tidak diubah):\n";
        
        char judul[MAX_JUDUL], penulis[MAX_PENULIS], kategori[30];
        int tahun;
        
        Validator::getStringInput("Judul baru    : ", judul, MAX_JUDUL);
        Validator::getStringInput("Penulis baru  : ", penulis, MAX_PENULIS);
        Validator::getStringInput("Kategori baru : ", kategori, 30);
        
        std::cout << "Tahun baru (0=tidak ubah): ";
        tahun = Validator::getIntInput("");
        
        if (Validator::konfirmasi("\nSimpan perubahan?")) {
            if (managerBuku.editBuku(id, judul, penulis, kategori, tahun)) {
                managerUser.tambahLog("Mengedit data buku");
            }
        }
        
        Validator::pause();
    }

    void AdminMenu::formHapusBuku() {
        managerBuku.tampilkanSemuaBuku();
        
        int id = Validator::getIntInput("\nMasukkan ID Buku yang akan dihapus: ");
        
        Node<Buku>* buku = managerBuku.cariBukuById(id);
        if (buku == NULL) {
            std::cout << "[!] Buku tidak ditemukan.\n";
            Validator::pause();
            return;
        }
        
        std::cout << "\nBuku yang akan dihapus: " << buku->data.judul << "\n";
        
        if (Validator::konfirmasi("Yakin ingin menghapus buku ini?")) {
            if (managerBuku.hapusBuku(id)) {
                managerUser.tambahLog("Menghapus buku");
            }
        } else {
            std::cout << "[Info] Dibatalkan.\n";
        }
        
        Validator::pause();
    }

    void AdminMenu::formCariBuku() {
        Validator::clearScreen();
        std::cout << "\n====== CARI BUKU ======\n";
        std::cout << "1. Cari berdasarkan Judul\n";
        std::cout << "2. Cari berdasarkan Penulis\n";
        std::cout << "3. Cari berdasarkan Kategori\n";
        std::cout << "4. Cari berdasarkan ID\n";
        
        int pilihan = Validator::getIntInput("\nPilih metode pencarian: ");
        
        char keyword[100];
        
        switch (pilihan) {
            case 1:
                Validator::getStringInputRequired("Masukkan kata kunci judul: ", keyword, 100);
                managerBuku.cariBukuByJudul(keyword);
                break;
            case 2:
                Validator::getStringInputRequired("Masukkan nama penulis: ", keyword, 100);
                managerBuku.cariBukuByPenulis(keyword);
                break;
            case 3:
                Validator::getStringInputRequired("Masukkan kategori: ", keyword, 100);
                managerBuku.cariBukuByKategori(keyword);
                break;
            case 4: {
                int id = Validator::getIntInput("Masukkan ID Buku: ");
                managerBuku.tampilkanDetailBuku(id);
                break;
            }
            default:
                std::cout << "[!] Pilihan tidak valid.\n";
        }
        
        Validator::pause();
    }

    void AdminMenu::formTambahUser() {
        Validator::clearScreen();
        std::cout << "\n====== TAMBAH USER/ADMIN BARU ======\n\n";
        
        char username[MAX_USERNAME], password[MAX_PASSWORD];
        char namaLengkap[50], noTelp[15];
        
        Validator::getStringInputRequired("Username      : ", username, MAX_USERNAME);
        Validator::getStringInputRequired("Password      : ", password, MAX_PASSWORD);
        Validator::getStringInputRequired("Nama Lengkap  : ", namaLengkap, 50);
        Validator::getStringInput("No. Telepon   : ", noTelp, 15);
        
        int tipe = Validator::getIntInput("Tipe (1=User, 2=Admin): ");
        
        std::cout << "\n";
        if (Validator::konfirmasi("Simpan user baru ini?")) {
            if (tipe == 2) {
                AuthService::registerAdmin(managerUser.getListUser(), 
                                          username, password, namaLengkap, noTelp);
                managerUser.tambahLog("Menambah admin baru");
            } else {
                AuthService::registerUser(managerUser.getListUser(), 
                                         username, password, namaLengkap, noTelp);
                managerUser.tambahLog("Menambah user baru");
            }
        }
        
        Validator::pause();
    }

    void AdminMenu::formEditUser() {
        managerUser.tampilkanSemuaUser();
        
        int id = Validator::getIntInput("\nMasukkan ID User yang akan diedit: ");
        
        Node<User>* user = managerUser.cariUserById(id);
        if (user == NULL) {
            std::cout << "[!] User tidak ditemukan.\n";
            Validator::pause();
            return;
        }
        
        managerUser.tampilkanDetailUser(id);
        
        std::cout << "\nMasukkan data baru (kosongkan jika tidak diubah):\n";
        
        char namaLengkap[50], noTelp[15];
        Validator::getStringInput("Nama Lengkap baru : ", namaLengkap, 50);
        Validator::getStringInput("No. Telepon baru  : ", noTelp, 15);
        
        if (Validator::konfirmasi("\nSimpan perubahan?")) {
            managerUser.editUser(id, namaLengkap, noTelp);
        }
        
        Validator::pause();
    }

    void AdminMenu::formResetPassword() {
        managerUser.tampilkanSemuaUser();
        
        int id = Validator::getIntInput("\nMasukkan ID User untuk reset password: ");
        
        Node<User>* user = managerUser.cariUserById(id);
        if (user == NULL) {
            std::cout << "[!] User tidak ditemukan.\n";
            Validator::pause();
            return;
        }
        
        std::cout << "User: " << user->data.username << " (" << user->data.namaLengkap << ")\n";
        
        char newPass[MAX_PASSWORD];
        Validator::getStringInputRequired("Password baru: ", newPass, MAX_PASSWORD);
        
        if (Validator::konfirmasi("Reset password user ini?")) {
            AuthService::resetPassword(managerUser.getListUser(), id, newPass);
            managerUser.tambahLog("Reset password user");
        }
        
        Validator::pause();
    }

    // ============ SUB-MENU KELOLA DENDA ============

    void AdminMenu::menuKelolaDenda() {
        int pilihan;
        
        do {
            Validator::clearScreen();
            
            std::cout << "\n";
            std::cout << "+==========================================+\n";
            std::cout << "|          KELOLA DENDA                    |\n";
            std::cout << "+------------------------------------------+\n";
            std::cout << "|  1. Lihat Semua Denda Belum Bayar        |\n";
            std::cout << "|  2. Lihat Denda User Tertentu            |\n";
            std::cout << "|  3. Konfirmasi Pembayaran Denda          |\n";
            std::cout << "|  4. Bayar Semua Denda User               |\n";
            std::cout << "|  0. Kembali                              |\n";
            std::cout << "+==========================================+\n";
            
            std::cout << "\nInfo: Denda Rp " << DENDA_PER_HARI << "/hari keterlambatan\n";
            std::cout << "      Batas blokir: Rp " << BATAS_DENDA_BLOKIR << "\n";
            
            pilihan = Validator::getIntInput("\nPilih menu: ");
            
            switch (pilihan) {
                case 1:
                    transaksiManager.tampilkanSemuaDendaBelumBayar();
                    Validator::pause();
                    break;
                case 2: {
                    managerUser.tampilkanSemuaUser();
                    int idUser = Validator::getIntInput("\nMasukkan ID User: ");
                    transaksiManager.tampilkanDendaUser(idUser);
                    Validator::pause();
                    break;
                }
                case 3:
                    formBayarDenda();
                    break;
                case 4: {
                    managerUser.tampilkanSemuaUser();
                    int idUser = Validator::getIntInput("\nMasukkan ID User untuk bayar semua denda: ");
                    
                    long totalDenda = transaksiManager.getTotalDendaUser(idUser);
                    if (totalDenda == 0) {
                        std::cout << "[!] User tidak memiliki denda.\n";
                    } else {
                        std::cout << "Total denda yang akan dibayar: Rp " << totalDenda << "\n";
                        if (Validator::konfirmasi("Konfirmasi pembayaran semua denda?")) {
                            transaksiManager.bayarSemuaDendaUser(idUser);
                            managerUser.tambahLog("Membayar semua denda user");
                        }
                    }
                    Validator::pause();
                    break;
                }
                case 0:
                    break;
                default:
                    std::cout << "\n[!] Pilihan tidak valid!\n";
                    Validator::pause();
            }
            
        } while (pilihan != 0);
    }

    void AdminMenu::formBayarDenda() {
        transaksiManager.tampilkanSemuaDendaBelumBayar();
        
        int idTransaksi = Validator::getIntInput("\nMasukkan ID Transaksi untuk bayar denda (0=batal): ");
        
        if (idTransaksi == 0) {
            std::cout << "[Info] Dibatalkan.\n";
            Validator::pause();
            return;
        }
        
        Node<Peminjaman>* transaksi = transaksiManager.cariTransaksi(idTransaksi);
        
        if (transaksi == NULL) {
            std::cout << "[!] Transaksi tidak ditemukan.\n";
            Validator::pause();
            return;
        }
        
        if (transaksi->data.denda == 0) {
            std::cout << "[!] Transaksi ini tidak memiliki denda.\n";
            Validator::pause();
            return;
        }
        
        if (transaksi->data.dendaDibayar) {
            std::cout << "[!] Denda untuk transaksi ini sudah dibayar.\n";
            Validator::pause();
            return;
        }
        
        std::cout << "\nDetail Denda:\n";
        std::cout << "  ID Transaksi : " << transaksi->data.idTransaksi << "\n";
        std::cout << "  Jumlah Denda : Rp " << transaksi->data.denda << "\n";
        
        if (Validator::konfirmasi("\nKonfirmasi pembayaran denda?")) {
            transaksiManager.bayarDenda(idTransaksi);
            managerUser.tambahLog("Menerima pembayaran denda");
        } else {
            std::cout << "[Info] Dibatalkan.\n";
        }
        
        Validator::pause();
    }

}
