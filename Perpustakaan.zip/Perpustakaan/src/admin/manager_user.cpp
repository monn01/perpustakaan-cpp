/*************************************************************
 * manager_user.cpp
 * Implementasi Manajemen Data User
 *************************************************************/

#include "../../include/admin/manager_user.h"
#include "../../include/auth/session.h"
#include "../../include/config.h"
#include <iostream>
#include <iomanip>
#include <cstring>
#include <ctime>

namespace LibSystem {

    // Constructor
    ManagerUser::ManagerUser(LinkedList<User>& list, Stack<SessionLog>& log)
        : listUser(list), activityLog(log) {}

    // ============ PRINT HELPERS ============

    void ManagerUser::printSeparator() {
        std::cout << "+------+----------------+--------------------+----------+---------------+--------+\n";
    }

    void ManagerUser::printTableHeader() {
        printSeparator();
        std::cout << "| " << std::left << std::setw(4) << "ID" << " | "
                  << std::setw(14) << "Username" << " | "
                  << std::setw(18) << "Nama Lengkap" << " | "
                  << std::setw(8) << "Role" << " | "
                  << std::setw(13) << "No. Telp" << " | "
                  << std::setw(6) << "Status" << " |\n";
        printSeparator();
    }

    void ManagerUser::printUserRow(const User& user) {
        char namaShort[19];
        strncpy(namaShort, user.namaLengkap, 18);
        namaShort[18] = '\0';
        
        std::cout << "| " << std::left << std::setw(4) << user.id << " | "
                  << std::setw(14) << user.username << " | "
                  << std::setw(18) << namaShort << " | "
                  << std::setw(8) << user.role << " | "
                  << std::setw(13) << user.noTelp << " | "
                  << std::setw(6) << (user.aktif ? "Aktif" : "Non") << " |\n";
    }

    // ============ READ ============

    void ManagerUser::tampilkanSemuaUser() {
        if (listUser.isEmpty()) {
            std::cout << "\n" << MSG_EMPTY_DATA << "\n";
            std::cout << "Belum ada user terdaftar.\n";
            return;
        }

        std::cout << "\n=============== DAFTAR SEMUA USER ===============\n";
        std::cout << "Total: " << listUser.getSize() << " user terdaftar\n\n";
        
        printTableHeader();
        
        Node<User>* current = listUser.getHead();
        while (current != NULL) {
            printUserRow(current->data);
            current = current->next;
        }
        
        printSeparator();
        
        std::cout << "\nRingkasan: Admin=" << getTotalAdmin() 
                  << ", User=" << (getTotalUser() - getTotalAdmin())
                  << ", Aktif=" << getTotalUserAktif() << "\n";
    }

    void ManagerUser::tampilkanUserAktif() {
        if (listUser.isEmpty()) {
            std::cout << "\n" << MSG_EMPTY_DATA << "\n";
            return;
        }

        std::cout << "\n============ USER AKTIF ============\n";
        
        printTableHeader();
        
        int count = 0;
        Node<User>* current = listUser.getHead();
        while (current != NULL) {
            if (current->data.aktif) {
                printUserRow(current->data);
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        std::cout << "Total " << count << " user aktif.\n";
    }

    void ManagerUser::tampilkanDetailUser(int id) {
        Node<User>* userNode = cariUserById(id);
        
        if (userNode == NULL) {
            std::cout << "[!] User dengan ID " << id << " tidak ditemukan.\n";
            return;
        }

        User& u = userNode->data;
        
        std::cout << "\n========== DETAIL USER ==========\n";
        std::cout << "ID           : " << u.id << "\n";
        std::cout << "Username     : " << u.username << "\n";
        std::cout << "Nama Lengkap : " << u.namaLengkap << "\n";
        std::cout << "Role         : " << u.role << "\n";
        std::cout << "No. Telepon  : " << u.noTelp << "\n";
        std::cout << "Status       : " << (u.aktif ? "Aktif" : "Nonaktif") << "\n";
        std::cout << "=================================\n";
    }

    Node<User>* ManagerUser::cariUserById(int id) {
        Node<User>* current = listUser.getHead();
        
        while (current != NULL) {
            if (current->data.id == id) {
                return current;
            }
            current = current->next;
        }
        
        return NULL;
    }

    Node<User>* ManagerUser::cariUserByUsername(const char* username) {
        Node<User>* current = listUser.getHead();
        
        while (current != NULL) {
            if (strcmp(current->data.username, username) == 0) {
                return current;
            }
            current = current->next;
        }
        
        return NULL;
    }

    // ============ UPDATE ============

    bool ManagerUser::aktifkanUser(int id) {
        Node<User>* userNode = cariUserById(id);
        
        if (userNode == NULL) {
            std::cout << "[!] User tidak ditemukan.\n";
            return false;
        }

        if (userNode->data.aktif) {
            std::cout << "[!] User sudah aktif.\n";
            return false;
        }

        userNode->data.aktif = true;
        
        // Log aktivitas
        char logMsg[100];
        snprintf(logMsg, 100, "Mengaktifkan user: %s", userNode->data.username);
        tambahLog(logMsg);
        
        std::cout << "[OK] User " << userNode->data.username << " berhasil diaktifkan.\n";
        return true;
    }

    bool ManagerUser::nonaktifkanUser(int id) {
        Node<User>* userNode = cariUserById(id);
        
        if (userNode == NULL) {
            std::cout << "[!] User tidak ditemukan.\n";
            return false;
        }

        // Tidak bisa menonaktifkan diri sendiri
        if (Session::isLoggedIn() && Session::getCurrentUserId() == id) {
            std::cout << "[!] Tidak bisa menonaktifkan akun Anda sendiri!\n";
            return false;
        }

        if (!userNode->data.aktif) {
            std::cout << "[!] User sudah nonaktif.\n";
            return false;
        }

        userNode->data.aktif = false;
        
        // Log aktivitas
        char logMsg[100];
        snprintf(logMsg, 100, "Menonaktifkan user: %s", userNode->data.username);
        tambahLog(logMsg);
        
        std::cout << "[OK] User " << userNode->data.username << " berhasil dinonaktifkan.\n";
        return true;
    }

    bool ManagerUser::editUser(int id, const char* namaLengkap, const char* noTelp) {
        Node<User>* userNode = cariUserById(id);
        
        if (userNode == NULL) {
            std::cout << "[!] User tidak ditemukan.\n";
            return false;
        }

        if (strlen(namaLengkap) > 0) {
            strncpy(userNode->data.namaLengkap, namaLengkap, 49);
        }
        if (strlen(noTelp) > 0) {
            strncpy(userNode->data.noTelp, noTelp, 14);
        }

        // Log aktivitas
        char logMsg[100];
        snprintf(logMsg, 100, "Mengedit data user: %s", userNode->data.username);
        tambahLog(logMsg);
        
        std::cout << "[OK] Data user berhasil diperbarui.\n";
        return true;
    }

    bool ManagerUser::ubahRole(int id, const char* roleBaru) {
        Node<User>* userNode = cariUserById(id);
        
        if (userNode == NULL) {
            std::cout << "[!] User tidak ditemukan.\n";
            return false;
        }

        // Validasi role
        if (strcmp(roleBaru, ROLE_ADMIN) != 0 && strcmp(roleBaru, ROLE_USER) != 0) {
            std::cout << "[!] Role tidak valid! Gunakan ADMIN atau USER.\n";
            return false;
        }

        // Tidak bisa mengubah role sendiri
        if (Session::isLoggedIn() && Session::getCurrentUserId() == id) {
            std::cout << "[!] Tidak bisa mengubah role akun Anda sendiri!\n";
            return false;
        }

        char roleSebelum[MAX_ROLE];
        strcpy(roleSebelum, userNode->data.role);
        
        strncpy(userNode->data.role, roleBaru, MAX_ROLE - 1);
        
        // Log aktivitas
        char logMsg[100];
        snprintf(logMsg, 100, "Mengubah role %s: %s -> %s", 
                 userNode->data.username, roleSebelum, roleBaru);
        tambahLog(logMsg);
        
        std::cout << "[OK] Role user berhasil diubah menjadi " << roleBaru << ".\n";
        return true;
    }

    // ============ DELETE ============

    bool ManagerUser::hapusUser(int id) {
        // Untuk keamanan, gunakan soft delete (nonaktifkan)
        return nonaktifkanUser(id);
    }

    // ============ ACTIVITY LOG (Stack) ============

    void ManagerUser::tambahLog(const char* aktivitas) {
        SessionLog log;
        
        if (Session::isLoggedIn()) {
            log.idUser = Session::getCurrentUserId();
            strncpy(log.username, Session::getCurrentUsername(), MAX_USERNAME - 1);
        } else {
            log.idUser = 0;
            strcpy(log.username, "System");
        }
        
        strncpy(log.aktivitas, aktivitas, MAX_AKTIVITAS - 1);
        
        // Set waktu
        time_t now = time(0);
        struct tm* timeinfo = localtime(&now);
        strftime(log.waktu, MAX_TANGGAL, "%d-%m-%Y %H:%M:%S", timeinfo);
        
        activityLog.push(log);
    }

    void ManagerUser::tampilkanRiwayatAktivitas() {
        if (activityLog.isEmpty()) {
            std::cout << "\n[Info] Belum ada riwayat aktivitas.\n";
            return;
        }

        std::cout << "\n============ RIWAYAT AKTIVITAS ============\n";
        std::cout << "(Menampilkan dari yang terbaru)\n\n";
        
        // Iterasi dari top stack
        StackNode<SessionLog>* current = activityLog.getTop();
        int no = 1;
        
        while (current != NULL && no <= 20) {  // Batasi 20 entri
            std::cout << no << ". [" << current->data.waktu << "]\n";
            std::cout << "   User: " << current->data.username 
                      << " (ID: " << current->data.idUser << ")\n";
            std::cout << "   Aksi: " << current->data.aktivitas << "\n\n";
            
            current = current->next;
            no++;
        }
        
        std::cout << "Menampilkan " << (no - 1) << " dari " 
                  << activityLog.getSize() << " aktivitas.\n";
    }

    void ManagerUser::tampilkanAktivitasTerakhir(int n) {
        if (activityLog.isEmpty()) {
            std::cout << "\n[Info] Belum ada riwayat aktivitas.\n";
            return;
        }

        std::cout << "\n====== " << n << " Aktivitas Terakhir ======\n\n";
        
        StackNode<SessionLog>* current = activityLog.getTop();
        int no = 1;
        
        while (current != NULL && no <= n) {
            std::cout << no << ". " << current->data.aktivitas;
            std::cout << " (" << current->data.username << ", " 
                      << current->data.waktu << ")\n";
            
            current = current->next;
            no++;
        }
    }

    void ManagerUser::clearLog() {
        activityLog.clear();
        std::cout << "[OK] Log aktivitas berhasil dihapus.\n";
    }

    // ============ UTILITY ============

    int ManagerUser::getTotalUser() {
        return listUser.getSize();
    }

    int ManagerUser::getTotalUserAktif() {
        int count = 0;
        Node<User>* current = listUser.getHead();
        
        while (current != NULL) {
            if (current->data.aktif) count++;
            current = current->next;
        }
        
        return count;
    }

    int ManagerUser::getTotalAdmin() {
        int count = 0;
        Node<User>* current = listUser.getHead();
        
        while (current != NULL) {
            if (strcmp(current->data.role, ROLE_ADMIN) == 0) count++;
            current = current->next;
        }
        
        return count;
    }

    LinkedList<User>& ManagerUser::getListUser() {
        return listUser;
    }

    Stack<SessionLog>& ManagerUser::getActivityLog() {
        return activityLog;
    }

}
