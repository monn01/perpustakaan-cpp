/*************************************************************
 * manager_buku.cpp
 * Implementasi Manajemen Data Buku
 *************************************************************/

#include "../../include/admin/manager_buku.h"
#include "../../include/core/file_io.h"
#include "../../include/config.h"
#include <iostream>
#include <iomanip>
#include <cstring>

namespace LibSystem {

    // Constructor
    ManagerBuku::ManagerBuku(LinkedList<Buku>& list, BST<Buku>& index) 
        : listBuku(list), indexBuku(index) {}

    // ============ CREATE ============

    bool ManagerBuku::tambahBuku(const char* judul, 
                                const char* penulis, 
                                const char* kategori,
                                int tahunTerbit, 
                                int stok) {
        int newId = FileIO::getNextBukuId(listBuku);
        return tambahBukuWithId(newId, judul, penulis, kategori, tahunTerbit, stok);
    }

    bool ManagerBuku::tambahBukuWithId(int id,
                                      const char* judul, 
                                      const char* penulis, 
                                      const char* kategori,
                                      int tahunTerbit, 
                                      int stok) {
        // Cek apakah ID sudah ada
        if (indexBuku.contains(id)) {
            std::cout << "[!] Error: ID buku " << id << " sudah digunakan!\n";
            return false;
        }
        
        // Validasi input
        if (strlen(judul) == 0) {
            std::cout << "[!] Error: Judul tidak boleh kosong!\n";
            return false;
        }
        
        if (stok < 0) {
            std::cout << "[!] Error: Stok tidak boleh negatif!\n";
            return false;
        }
        
        // Buat buku baru
        Buku bukuBaru;
        bukuBaru.id = id;
        strncpy(bukuBaru.judul, judul, MAX_JUDUL - 1);
        strncpy(bukuBaru.penulis, penulis, MAX_PENULIS - 1);
        strncpy(bukuBaru.kategori, kategori, 29);
        bukuBaru.tahunTerbit = tahunTerbit;
        bukuBaru.stok = stok;
        bukuBaru.stokAwal = stok;
        bukuBaru.tersedia = (stok > 0);
        
        // Tambah ke linked list
        listBuku.pushBack(bukuBaru);
        
        // Tambah ke index BST
        indexBuku.insert(id, listBuku.getTail());
        
        std::cout << "[OK] Buku \"" << judul << "\" berhasil ditambahkan dengan ID: " << id << "\n";
        return true;
    }

    // ============ READ ============

    void ManagerBuku::printSeparator() {
        std::cout << "+------+--------------------------------+----------------------+------------+------+------+--------+\n";
    }

    void ManagerBuku::printTableHeader() {
        printSeparator();
        std::cout << "| " << std::left << std::setw(4) << "ID" << " | "
                  << std::setw(30) << "Judul" << " | "
                  << std::setw(20) << "Penulis" << " | "
                  << std::setw(10) << "Kategori" << " | "
                  << std::setw(4) << "Thn" << " | "
                  << std::setw(4) << "Stok" << " | "
                  << std::setw(6) << "Status" << " |\n";
        printSeparator();
    }

    void ManagerBuku::printBukuRow(const Buku& buku) {
        // Potong string jika terlalu panjang
        char judulShort[31], penulisShort[21], kategoriShort[11];
        
        strncpy(judulShort, buku.judul, 30);
        judulShort[30] = '\0';
        
        strncpy(penulisShort, buku.penulis, 20);
        penulisShort[20] = '\0';
        
        strncpy(kategoriShort, buku.kategori, 10);
        kategoriShort[10] = '\0';
        
        std::cout << "| " << std::left << std::setw(4) << buku.id << " | "
                  << std::setw(30) << judulShort << " | "
                  << std::setw(20) << penulisShort << " | "
                  << std::setw(10) << kategoriShort << " | "
                  << std::setw(4) << buku.tahunTerbit << " | "
                  << std::setw(4) << buku.stok << " | "
                  << std::setw(6) << (buku.tersedia ? "Ada" : "Habis") << " |\n";
    }

    void ManagerBuku::tampilkanSemuaBuku() {
        if (listBuku.isEmpty()) {
            std::cout << "\n" << MSG_EMPTY_DATA << "\n";
            std::cout << "Belum ada buku dalam koleksi.\n";
            return;
        }

        std::cout << "\n=============== DAFTAR SEMUA BUKU ===============\n";
        std::cout << "Total: " << listBuku.getSize() << " judul buku\n\n";
        
        printTableHeader();
        
        Node<Buku>* current = listBuku.getHead();
        while (current != NULL) {
            printBukuRow(current->data);
            current = current->next;
        }
        
        printSeparator();
    }

    void ManagerBuku::tampilkanBukuTersedia() {
        if (listBuku.isEmpty()) {
            std::cout << "\n" << MSG_EMPTY_DATA << "\n";
            return;
        }

        std::cout << "\n============ BUKU YANG TERSEDIA ============\n";
        
        printTableHeader();
        
        int count = 0;
        Node<Buku>* current = listBuku.getHead();
        while (current != NULL) {
            if (current->data.tersedia && current->data.stok > 0) {
                printBukuRow(current->data);
                count++;
            }
            current = current->next;
        }
        
        printSeparator();
        std::cout << "Total " << count << " buku tersedia untuk dipinjam.\n";
    }

    void ManagerBuku::tampilkanDetailBuku(int id) {
        Node<Buku>* bukuNode = cariBukuById(id);
        
        if (bukuNode == NULL) {
            std::cout << "[!] Buku dengan ID " << id << " tidak ditemukan.\n";
            return;
        }

        Buku& b = bukuNode->data;
        
        std::cout << "\n========== DETAIL BUKU ==========\n";
        std::cout << "ID           : " << b.id << "\n";
        std::cout << "Judul        : " << b.judul << "\n";
        std::cout << "Penulis      : " << b.penulis << "\n";
        std::cout << "Kategori     : " << b.kategori << "\n";
        std::cout << "Tahun Terbit : " << b.tahunTerbit << "\n";
        std::cout << "Stok Saat Ini: " << b.stok << "\n";
        std::cout << "Stok Awal    : " << b.stokAwal << "\n";
        std::cout << "Status       : " << (b.tersedia ? "Tersedia" : "Tidak Tersedia") << "\n";
        std::cout << "Dipinjam     : " << (b.stokAwal - b.stok) << " eksemplar\n";
        std::cout << "=================================\n";
    }

    Node<Buku>* ManagerBuku::cariBukuById(int id) {
        return indexBuku.search(id);
    }

    void ManagerBuku::cariBukuByJudul(const char* keyword) {
        if (listBuku.isEmpty()) {
            std::cout << MSG_EMPTY_DATA << "\n";
            return;
        }

        std::cout << "\n====== Hasil Pencarian: \"" << keyword << "\" ======\n";
        
        printTableHeader();
        
        int found = 0;
        Node<Buku>* current = listBuku.getHead();
        
        while (current != NULL) {
            // Case-insensitive search (sederhana)
            char judulLower[MAX_JUDUL], keywordLower[MAX_JUDUL];
            strcpy(judulLower, current->data.judul);
            strcpy(keywordLower, keyword);
            
            // Convert ke lowercase
            for (int i = 0; judulLower[i]; i++) {
                if (judulLower[i] >= 'A' && judulLower[i] <= 'Z')
                    judulLower[i] = judulLower[i] + 32;
            }
            for (int i = 0; keywordLower[i]; i++) {
                if (keywordLower[i] >= 'A' && keywordLower[i] <= 'Z')
                    keywordLower[i] = keywordLower[i] + 32;
            }
            
            if (strstr(judulLower, keywordLower) != NULL) {
                printBukuRow(current->data);
                found++;
            }
            current = current->next;
        }
        
        printSeparator();
        
        if (found == 0) {
            std::cout << "Tidak ada buku dengan judul mengandung \"" << keyword << "\".\n";
        } else {
            std::cout << "Ditemukan " << found << " buku.\n";
        }
    }

    void ManagerBuku::cariBukuByPenulis(const char* keyword) {
        if (listBuku.isEmpty()) {
            std::cout << MSG_EMPTY_DATA << "\n";
            return;
        }

        std::cout << "\n====== Buku oleh Penulis: \"" << keyword << "\" ======\n";
        
        printTableHeader();
        
        int found = 0;
        Node<Buku>* current = listBuku.getHead();
        
        while (current != NULL) {
            char penulisLower[MAX_PENULIS], keywordLower[MAX_PENULIS];
            strcpy(penulisLower, current->data.penulis);
            strcpy(keywordLower, keyword);
            
            for (int i = 0; penulisLower[i]; i++) {
                if (penulisLower[i] >= 'A' && penulisLower[i] <= 'Z')
                    penulisLower[i] = penulisLower[i] + 32;
            }
            for (int i = 0; keywordLower[i]; i++) {
                if (keywordLower[i] >= 'A' && keywordLower[i] <= 'Z')
                    keywordLower[i] = keywordLower[i] + 32;
            }
            
            if (strstr(penulisLower, keywordLower) != NULL) {
                printBukuRow(current->data);
                found++;
            }
            current = current->next;
        }
        
        printSeparator();
        std::cout << "Ditemukan " << found << " buku.\n";
    }

    void ManagerBuku::cariBukuByKategori(const char* kategori) {
        if (listBuku.isEmpty()) {
            std::cout << MSG_EMPTY_DATA << "\n";
            return;
        }

        std::cout << "\n====== Kategori: " << kategori << " ======\n";
        
        printTableHeader();
        
        int found = 0;
        Node<Buku>* current = listBuku.getHead();
        
        while (current != NULL) {
            if (strcmp(current->data.kategori, kategori) == 0) {
                printBukuRow(current->data);
                found++;
            }
            current = current->next;
        }
        
        printSeparator();
        std::cout << "Ditemukan " << found << " buku dalam kategori ini.\n";
    }

    // ============ UPDATE ============

    bool ManagerBuku::editBuku(int id, 
                              const char* judulBaru, 
                              const char* penulisBaru,
                              const char* kategoriBaru,
                              int tahunBaru) {
        Node<Buku>* bukuNode = cariBukuById(id);
        
        if (bukuNode == NULL) {
            std::cout << "[!] Buku dengan ID " << id << " tidak ditemukan.\n";
            return false;
        }

        // Update data (hanya yang tidak kosong)
        if (strlen(judulBaru) > 0) {
            strncpy(bukuNode->data.judul, judulBaru, MAX_JUDUL - 1);
        }
        if (strlen(penulisBaru) > 0) {
            strncpy(bukuNode->data.penulis, penulisBaru, MAX_PENULIS - 1);
        }
        if (strlen(kategoriBaru) > 0) {
            strncpy(bukuNode->data.kategori, kategoriBaru, 29);
        }
        if (tahunBaru > 0) {
            bukuNode->data.tahunTerbit = tahunBaru;
        }

        std::cout << "[OK] Data buku berhasil diperbarui.\n";
        return true;
    }

    bool ManagerBuku::updateStok(int id, int stokBaru) {
        Node<Buku>* bukuNode = cariBukuById(id);
        
        if (bukuNode == NULL) {
            std::cout << "[!] Buku tidak ditemukan.\n";
            return false;
        }

        if (stokBaru < 0) {
            std::cout << "[!] Stok tidak boleh negatif.\n";
            return false;
        }

        bukuNode->data.stok = stokBaru;
        bukuNode->data.tersedia = (stokBaru > 0);
        
        // Update stok awal jika stok baru lebih besar
        if (stokBaru > bukuNode->data.stokAwal) {
            bukuNode->data.stokAwal = stokBaru;
        }

        std::cout << "[OK] Stok buku diperbarui menjadi " << stokBaru << ".\n";
        return true;
    }

    bool ManagerBuku::kurangiStok(int id) {
        Node<Buku>* bukuNode = cariBukuById(id);
        
        if (bukuNode == NULL) return false;
        if (bukuNode->data.stok <= 0) return false;

        bukuNode->data.stok--;
        bukuNode->data.tersedia = (bukuNode->data.stok > 0);
        
        return true;
    }

    bool ManagerBuku::tambahStok(int id) {
        Node<Buku>* bukuNode = cariBukuById(id);
        
        if (bukuNode == NULL) return false;

        bukuNode->data.stok++;
        bukuNode->data.tersedia = true;
        
        return true;
    }

    // ============ DELETE ============

    bool ManagerBuku::hapusBuku(int id) {
        Node<Buku>* bukuNode = cariBukuById(id);
        
        if (bukuNode == NULL) {
            std::cout << "[!] Buku dengan ID " << id << " tidak ditemukan.\n";
            return false;
        }

        // Simpan nama untuk konfirmasi
        char judulHapus[MAX_JUDUL];
        strcpy(judulHapus, bukuNode->data.judul);

        // Hapus dari list
        listBuku.remove(bukuNode);
        
        // Rebuild index BST
        rebuildIndex();

        std::cout << "[OK] Buku \"" << judulHapus << "\" berhasil dihapus.\n";
        return true;
    }

    // ============ UTILITY ============

    void ManagerBuku::rebuildIndex() {
        indexBuku.clear();
        
        Node<Buku>* current = listBuku.getHead();
        while (current != NULL) {
            indexBuku.insert(current->data.id, current);
            current = current->next;
        }
    }

    int ManagerBuku::getTotalBuku() {
        return listBuku.getSize();
    }

    int ManagerBuku::getTotalStok() {
        int total = 0;
        Node<Buku>* current = listBuku.getHead();
        
        while (current != NULL) {
            total += current->data.stok;
            current = current->next;
        }
        
        return total;
    }

    bool ManagerBuku::bisaDihapus(int id, LinkedList<Peminjaman>& listPinjam) {
        Node<Peminjaman>* current = listPinjam.getHead();
        
        while (current != NULL) {
            // Jika ada peminjaman aktif untuk buku ini
            if (current->data.idBuku == id && !current->data.sudahKembali) {
                return false;
            }
            current = current->next;
        }
        
        return true;
    }

    LinkedList<Buku>& ManagerBuku::getListBuku() {
        return listBuku;
    }

}
