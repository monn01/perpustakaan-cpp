/*************************************************************
 * validator.h
 * Utilitas Validasi Input User
 * 
 * Berisi fungsi-fungsi untuk:
 * - Mengambil input angka dengan validasi
 * - Mengambil input string dengan validasi
 * - Konfirmasi Yes/No
 * - Validasi format data
 *************************************************************/

#ifndef VALIDATOR_H
#define VALIDATOR_H

namespace LibSystem {

    class Validator {
    public:
        // ============ INPUT FUNCTIONS ============
        
        // Mengambil input integer dengan validasi
        static int getIntInput(const char* prompt);
        
        // Mengambil input integer dalam range tertentu
        static int getIntInputRange(const char* prompt, int min, int max);
        
        // Mengambil input string (char array)
        static void getStringInput(const char* prompt, char* buffer, int maxLength);
        
        // Mengambil input string yang tidak boleh kosong
        static void getStringInputRequired(const char* prompt, char* buffer, int maxLength);
        
        // ============ CONFIRMATION ============
        
        // Konfirmasi Ya/Tidak
        static bool konfirmasi(const char* pesan);
        
        // ============ VALIDATION FUNCTIONS ============
        
        // Cek apakah string hanya berisi angka
        static bool isNumeric(const char* str);
        
        // Cek apakah string kosong atau hanya whitespace
        static bool isEmpty(const char* str);
        
        // Cek panjang string dalam range
        static bool isLengthValid(const char* str, int minLen, int maxLen);
        
        // ============ UTILITY ============
        
        // Membersihkan layar console (cross-platform attempt)
        static void clearScreen();
        
        // Pause dan tunggu user tekan Enter
        static void pause();
        
        // Pause dengan pesan custom
        static void pause(const char* pesan);
        
        // Trim whitespace dari string
        static void trim(char* str);
    };

}

#endif
