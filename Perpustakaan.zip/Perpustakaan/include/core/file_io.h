/*************************************************************
 * file_io.h
 * Utilitas Input/Output File (Persistence)
 * 
 * Berisi fungsi-fungsi untuk:
 * - Load data dari file ke LinkedList
 * - Save data dari LinkedList ke file
 * - Format file: pipe-delimited (|)
 *************************************************************/

#ifndef FILE_IO_H
#define FILE_IO_H

#include "../structures/linkedlist.h"
#include "../common_types.h"

namespace LibSystem {

    class FileIO {
    public:
        // ============ LOAD FUNCTIONS ============
        // Memuat data dari file ke LinkedList
        
        static bool loadUsers(LinkedList<User>& list);
        static bool loadBuku(LinkedList<Buku>& list);
        static bool loadPeminjaman(LinkedList<Peminjaman>& list);
        
        // ============ SAVE FUNCTIONS ============
        // Menyimpan data dari LinkedList ke file
        
        static bool saveUsers(LinkedList<User>& list);
        static bool saveBuku(LinkedList<Buku>& list);
        static bool savePeminjaman(LinkedList<Peminjaman>& list);
        
        // ============ UTILITY ============
        
        // Cek apakah file ada
        static bool fileExists(const char* filepath);
        
        // Membuat file kosong jika belum ada
        static bool createFileIfNotExists(const char* filepath);
        
        // Backup file sebelum overwrite
        static bool backupFile(const char* filepath);
        
        // ============ ID GENERATOR ============
        // Mengambil ID terakhir + 1 untuk auto-increment
        
        static int getNextUserId(LinkedList<User>& list);
        static int getNextBukuId(LinkedList<Buku>& list);
        static int getNextTransaksiId(LinkedList<Peminjaman>& list);
    };

}

#endif
