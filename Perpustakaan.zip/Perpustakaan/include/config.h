/*************************************************************
 * config.h
 * Konfigurasi global untuk Sistem Perpustakaan
 * 
 * File ini berisi konstanta dan pengaturan yang digunakan
 * di seluruh program
 *************************************************************/

#ifndef CONFIG_H
#define CONFIG_H

namespace LibSystem {

    // ==================== PATH FILE DATABASE ====================
    const char FILE_USER[]      = "data/users.txt";
    const char FILE_BUKU[]      = "data/buku.txt";
    const char FILE_PINJAM[]    = "data/peminjaman.txt";
    const char FILE_LOG[]       = "data/app.log";

    // ==================== BATASAN SISTEM ====================
    const int MAX_JUDUL         = 100;   // Panjang maksimal judul buku
    const int MAX_PENULIS       = 50;    // Panjang maksimal nama penulis
    const int MAX_USERNAME      = 30;    // Panjang maksimal username
    const int MAX_PASSWORD      = 30;    // Panjang maksimal password
    const int MAX_ROLE          = 10;    // Panjang maksimal role (ADMIN/USER)
    const int MAX_TANGGAL       = 20;    // Panjang maksimal string tanggal
    const int MAX_AKTIVITAS     = 100;   // Panjang maksimal log aktivitas

    // ==================== PENGATURAN PEMINJAMAN ====================
    const int DURASI_PINJAM_HARI    = 7;     // Durasi peminjaman (hari)
    const int DENDA_PER_HARI        = 3000;  // Denda keterlambatan (Rupiah)
    const int MAX_PINJAM_PER_USER   = 3;     // Maksimal buku dipinjam per user
    const int BATAS_DENDA_BLOKIR    = 15000; // Batas denda untuk blokir peminjaman

    // ==================== PESAN SISTEM ====================
    const char MSG_ACCESS_DENIED[]  = "Maaf, Anda tidak memiliki akses ke fitur ini!";
    const char MSG_SAVE_SUCCESS[]   = "Data berhasil disimpan ke database.";
    const char MSG_LOAD_SUCCESS[]   = "Data berhasil dimuat dari database.";
    const char MSG_NOT_FOUND[]      = "Data tidak ditemukan.";
    const char MSG_EMPTY_DATA[]     = "Tidak ada data untuk ditampilkan.";

    // ==================== ROLE USER ====================
    const char ROLE_ADMIN[] = "ADMIN";
    const char ROLE_USER[]  = "USER";

}

#endif
