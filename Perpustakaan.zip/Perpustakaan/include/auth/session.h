/*************************************************************
 * session.h
 * Manajemen Session User yang Sedang Login
 * 
 * Menyimpan informasi user yang sedang aktif dalam sistem
 * Menggunakan static member untuk akses global
 *************************************************************/

#ifndef SESSION_H
#define SESSION_H

#include "../common_types.h"

namespace LibSystem {

    class Session {
    private:
        // Static pointer ke user yang sedang login
        static User* currentUser;
        
        // Waktu login (untuk tracking durasi session)
        static char loginTime[MAX_TANGGAL];

    public:
        // ============ SESSION CONTROL ============
        
        // Set session saat login berhasil
        static void setSession(User* user);
        
        // Hapus session saat logout
        static void clearSession();
        
        // ============ SESSION INFO ============
        
        // Mendapatkan pointer user yang sedang login
        static User* getCurrentUser();
        
        // Mendapatkan ID user yang sedang login
        static int getCurrentUserId();
        
        // Mendapatkan username user yang sedang login
        static const char* getCurrentUsername();
        
        // Mendapatkan waktu login
        static const char* getLoginTime();
        
        // ============ SESSION CHECK ============
        
        // Cek apakah ada user yang sedang login
        static bool isLoggedIn();
        
        // Cek apakah user yang login adalah Admin
        static bool isAdmin();
        
        // Cek apakah user yang login adalah User biasa
        static bool isUser();
        
        // ============ UTILITY ============
        
        // Menampilkan info session saat ini
        static void displaySessionInfo();
    };

}

#endif
