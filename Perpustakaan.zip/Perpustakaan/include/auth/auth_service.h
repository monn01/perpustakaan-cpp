/*************************************************************
 * auth_service.h
 * Layanan Autentikasi User
 * 
 * Berisi fungsi-fungsi untuk:
 * - Login user
 * - Logout user
 * - Register user baru
 * - Validasi kredensial
 * - Ganti password
 *************************************************************/

#ifndef AUTH_SERVICE_H
#define AUTH_SERVICE_H

#include "../structures/linkedlist.h"
#include "../structures/stack.h"
#include "../common_types.h"

namespace LibSystem {

    class AuthService {
    public:
        // ============ AUTHENTICATION ============
        
        // Login dengan username dan password
        // Return: true jika berhasil, false jika gagal
        static bool login(LinkedList<User>& userList, 
                         const char* username, 
                         const char* password);
        
        // Logout user yang sedang login
        static void logout();
        
        // ============ REGISTRATION ============
        
        // Register user baru (role: USER)
        // Return: true jika berhasil
        static bool registerUser(LinkedList<User>& userList,
                                const char* username,
                                const char* password,
                                const char* namaLengkap,
                                const char* noTelp);
        
        // Register admin baru (hanya bisa dilakukan oleh admin)
        static bool registerAdmin(LinkedList<User>& userList,
                                 const char* username,
                                 const char* password,
                                 const char* namaLengkap,
                                 const char* noTelp);
        
        // ============ VALIDATION ============
        
        // Cek apakah username sudah dipakai
        static bool isUsernameExists(LinkedList<User>& userList, 
                                    const char* username);
        
        // Validasi format username (min 4 karakter, alfanumerik)
        static bool isValidUsername(const char* username);
        
        // Validasi format password (min 6 karakter)
        static bool isValidPassword(const char* password);
        
        // ============ PASSWORD MANAGEMENT ============
        
        // Ganti password user yang sedang login
        static bool changePassword(LinkedList<User>& userList,
                                  const char* oldPassword,
                                  const char* newPassword);
        
        // Reset password (admin only)
        static bool resetPassword(LinkedList<User>& userList,
                                 int userId,
                                 const char* newPassword);
        
        // ============ ACTIVITY LOGGING ============
        
        // Catat aktivitas login ke stack log
        static void logActivity(Stack<SessionLog>& logStack,
                               const char* aktivitas);
    
    private:
        // Helper: Mencari user berdasarkan username
        static Node<User>* findUserByUsername(LinkedList<User>& userList,
                                              const char* username);
        
        // Helper: Mencari user berdasarkan ID
        static Node<User>* findUserById(LinkedList<User>& userList, int id);
    };

}

#endif
