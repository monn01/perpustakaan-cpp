/*************************************************************
 * stack.h
 * Implementasi Stack - Last In First Out (Template)
 * 
 * Digunakan untuk:
 * - Menyimpan riwayat aktivitas (Activity Log)
 * - Fitur Undo (jika diperlukan)
 * - History navigasi
 *************************************************************/

#ifndef STACK_H
#define STACK_H

#include <iostream>

namespace LibSystem {

    // ==================== STACK NODE ====================
    template <typename T>
    struct StackNode {
        T data;
        StackNode* next;

        StackNode(T val) : data(val), next(NULL) {}
    };

    // ==================== STACK CLASS ====================
    template <typename T>
    class Stack {
    private:
        StackNode<T>* top;
        int _size;
        int _maxSize;  // Batas maksimal (0 = unlimited)

    public:
        // ============ CONSTRUCTOR & DESTRUCTOR ============
        Stack(int maxSize = 0) {
            top = NULL;
            _size = 0;
            _maxSize = maxSize;
        }

        ~Stack() {
            clear();
        }

        // ============ BASIC OPERATIONS ============
        
        // Push - Menambah elemen ke atas stack
        bool push(T val) {
            // Cek apakah stack penuh (jika ada batas)
            if (_maxSize > 0 && _size >= _maxSize) {
                // Hapus elemen terbawah jika penuh (untuk log rotation)
                removeBottom();
            }

            StackNode<T>* newNode = new StackNode<T>(val);
            newNode->next = top;
            top = newNode;
            _size++;
            return true;
        }

        // Pop - Menghapus dan mengembalikan elemen teratas
        bool pop() {
            if (isEmpty()) return false;

            StackNode<T>* temp = top;
            top = top->next;
            delete temp;
            _size--;
            return true;
        }

        // Peek - Melihat elemen teratas tanpa menghapus
        T peek() const {
            if (isEmpty()) {
                // Return default object jika kosong
                return T();
            }
            return top->data;
        }

        // Peek dengan reference (lebih aman)
        bool peek(T& result) const {
            if (isEmpty()) return false;
            result = top->data;
            return true;
        }

        // ============ UTILITY FUNCTIONS ============
        
        bool isEmpty() const { 
            return top == NULL; 
        }
        
        int getSize() const { 
            return _size; 
        }

        // Menghapus semua elemen
        void clear() {
            while (!isEmpty()) {
                pop();
            }
        }

        // ============ ADVANCED OPERATIONS ============
        
        // Menampilkan semua elemen (untuk debugging/display)
        void display() const {
            if (isEmpty()) {
                std::cout << "Stack kosong.\n";
                return;
            }

            StackNode<T>* current = top;
            int index = 1;
            while (current != NULL) {
                std::cout << index << ". ";
                // Catatan: T harus punya cara untuk di-print
                // atau gunakan callback function
                current = current->next;
                index++;
            }
        }

        // Mengambil elemen di posisi tertentu (0 = top)
        bool getAt(int index, T& result) const {
            if (index < 0 || index >= _size) return false;

            StackNode<T>* current = top;
            for (int i = 0; i < index; i++) {
                current = current->next;
            }
            result = current->data;
            return true;
        }

        // Mendapatkan pointer ke top node (untuk iterasi)
        StackNode<T>* getTop() const {
            return top;
        }

    private:
        // Helper: Hapus elemen terbawah (untuk log rotation)
        void removeBottom() {
            if (isEmpty() || top->next == NULL) {
                pop();
                return;
            }

            StackNode<T>* current = top;
            while (current->next->next != NULL) {
                current = current->next;
            }
            
            delete current->next;
            current->next = NULL;
            _size--;
        }
    };

}

#endif
