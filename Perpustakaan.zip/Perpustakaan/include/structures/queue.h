/*************************************************************
 * queue.h
 * Implementasi Queue - First In First Out (Template)
 * 
 * Digunakan untuk:
 * - Antrian reservasi buku (jika stok habis)
 * - Antrian proses peminjaman
 *************************************************************/

#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>

namespace LibSystem {

    // ==================== QUEUE NODE ====================
    template <typename T>
    struct QueueNode {
        T data;
        QueueNode* next;

        QueueNode(T val) : data(val), next(NULL) {}
    };

    // ==================== QUEUE CLASS ====================
    template <typename T>
    class Queue {
    private:
        QueueNode<T>* front;  // Depan antrian (keluar)
        QueueNode<T>* rear;   // Belakang antrian (masuk)
        int _size;

    public:
        // ============ CONSTRUCTOR & DESTRUCTOR ============
        Queue() {
            front = NULL;
            rear = NULL;
            _size = 0;
        }

        ~Queue() {
            clear();
        }

        // ============ BASIC OPERATIONS ============
        
        // Enqueue - Menambah elemen ke belakang antrian
        void enqueue(T val) {
            QueueNode<T>* newNode = new QueueNode<T>(val);
            
            if (rear == NULL) {
                // Queue kosong
                front = rear = newNode;
            } else {
                rear->next = newNode;
                rear = newNode;
            }
            _size++;
        }

        // Dequeue - Menghapus elemen dari depan antrian
        bool dequeue() {
            if (isEmpty()) return false;

            QueueNode<T>* temp = front;
            front = front->next;

            // Jika queue menjadi kosong
            if (front == NULL) {
                rear = NULL;
            }

            delete temp;
            _size--;
            return true;
        }

        // Dequeue dengan mengambil nilainya
        bool dequeue(T& result) {
            if (isEmpty()) return false;
            
            result = front->data;
            return dequeue();
        }

        // getFront - Melihat elemen depan tanpa menghapus
        T getFront() const {
            if (isEmpty()) {
                return T();  // Return default object
            }
            return front->data;
        }

        // getFront dengan reference (lebih aman)
        bool getFront(T& result) const {
            if (isEmpty()) return false;
            result = front->data;
            return true;
        }

        // getRear - Melihat elemen belakang
        T getRear() const {
            if (isEmpty()) {
                return T();
            }
            return rear->data;
        }

        // ============ UTILITY FUNCTIONS ============
        
        bool isEmpty() const { 
            return front == NULL; 
        }
        
        int getSize() const { 
            return _size; 
        }

        // Menghapus semua elemen
        void clear() {
            while (!isEmpty()) {
                dequeue();
            }
        }

        // ============ ADVANCED OPERATIONS ============
        
        // Mendapatkan pointer ke front node (untuk iterasi)
        QueueNode<T>* getFrontNode() const {
            return front;
        }

        // Mengecek apakah elemen ada dalam queue
        // (Memerlukan operator== pada tipe T)
        bool contains(T val) const {
            QueueNode<T>* current = front;
            while (current != NULL) {
                // Perbandingan sederhana berdasarkan memory
                // Untuk perbandingan custom, perlu dimodifikasi
                if (&(current->data) == &val) return true;
                current = current->next;
            }
            return false;
        }

        // Menghapus elemen tertentu dari queue (by reference)
        bool removeNode(QueueNode<T>* target) {
            if (isEmpty() || target == NULL) return false;

            // Jika target adalah front
            if (target == front) {
                return dequeue();
            }

            // Cari node sebelum target
            QueueNode<T>* current = front;
            while (current != NULL && current->next != target) {
                current = current->next;
            }

            if (current == NULL) return false;  // Target tidak ditemukan

            // Hapus target
            current->next = target->next;
            
            // Update rear jika target adalah rear
            if (target == rear) {
                rear = current;
            }

            delete target;
            _size--;
            return true;
        }

        // Menampilkan semua elemen dalam queue
        void display() const {
            if (isEmpty()) {
                std::cout << "Antrian kosong.\n";
                return;
            }

            std::cout << "=== Isi Antrian ===\n";
            QueueNode<T>* current = front;
            int pos = 1;
            while (current != NULL) {
                std::cout << pos << ". [Data di posisi " << pos << "]\n";
                current = current->next;
                pos++;
            }
            std::cout << "Total: " << _size << " item\n";
        }
    };

}

#endif
