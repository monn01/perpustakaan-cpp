/*************************************************************
 * bst.h
 * Implementasi Binary Search Tree (Template)
 * 
 * Digunakan untuk:
 * - Index pencarian buku berdasarkan ID (O(log n))
 * - Bisa dikembangkan untuk pencarian berdasarkan judul
 *************************************************************/

#ifndef BST_H
#define BST_H

#include <iostream>
#include "linkedlist.h"

namespace LibSystem {

    // ==================== BST NODE ====================
    template <typename T>
    struct BSTNode {
        int key;                // Key untuk pencarian (biasanya ID)
        Node<T>* listPointer;   // Pointer ke node di LinkedList
        BSTNode* left;
        BSTNode* right;

        BSTNode(int k, Node<T>* ptr) {
            key = k;
            listPointer = ptr;
            left = NULL;
            right = NULL;
        }
    };

    // ==================== BST CLASS ====================
    template <typename T>
    class BST {
    private:
        BSTNode<T>* root;
        int _size;

        // ============ PRIVATE RECURSIVE HELPERS ============
        
        // Insert recursive
        BSTNode<T>* insertRecursive(BSTNode<T>* node, int key, Node<T>* ptr) {
            if (node == NULL) {
                _size++;
                return new BSTNode<T>(key, ptr);
            }

            if (key < node->key) {
                node->left = insertRecursive(node->left, key, ptr);
            } else if (key > node->key) {
                node->right = insertRecursive(node->right, key, ptr);
            }
            // Jika key sama, tidak insert (key harus unik)

            return node;
        }

        // Search recursive
        BSTNode<T>* searchRecursive(BSTNode<T>* node, int key) const {
            if (node == NULL || node->key == key) {
                return node;
            }

            if (key < node->key) {
                return searchRecursive(node->left, key);
            }
            return searchRecursive(node->right, key);
        }

        // Find minimum node (untuk delete)
        BSTNode<T>* findMin(BSTNode<T>* node) const {
            while (node != NULL && node->left != NULL) {
                node = node->left;
            }
            return node;
        }

        // Delete recursive
        BSTNode<T>* deleteRecursive(BSTNode<T>* node, int key) {
            if (node == NULL) return NULL;

            if (key < node->key) {
                node->left = deleteRecursive(node->left, key);
            } else if (key > node->key) {
                node->right = deleteRecursive(node->right, key);
            } else {
                // Node ditemukan, hapus
                
                // Case 1: Leaf node
                if (node->left == NULL && node->right == NULL) {
                    delete node;
                    _size--;
                    return NULL;
                }
                
                // Case 2: Satu anak
                if (node->left == NULL) {
                    BSTNode<T>* temp = node->right;
                    delete node;
                    _size--;
                    return temp;
                }
                if (node->right == NULL) {
                    BSTNode<T>* temp = node->left;
                    delete node;
                    _size--;
                    return temp;
                }

                // Case 3: Dua anak
                BSTNode<T>* successor = findMin(node->right);
                node->key = successor->key;
                node->listPointer = successor->listPointer;
                node->right = deleteRecursive(node->right, successor->key);
            }

            return node;
        }

        // Destroy tree recursive
        void destroyRecursive(BSTNode<T>* node) {
            if (node != NULL) {
                destroyRecursive(node->left);
                destroyRecursive(node->right);
                delete node;
            }
        }

        // Inorder traversal recursive (untuk display terurut)
        void inorderRecursive(BSTNode<T>* node) const {
            if (node != NULL) {
                inorderRecursive(node->left);
                std::cout << "Key: " << node->key << "\n";
                inorderRecursive(node->right);
            }
        }

    public:
        // ============ CONSTRUCTOR & DESTRUCTOR ============
        BST() {
            root = NULL;
            _size = 0;
        }

        ~BST() {
            clear();
        }

        // ============ BASIC OPERATIONS ============
        
        // Insert node baru
        void insert(int key, Node<T>* ptr) {
            root = insertRecursive(root, key, ptr);
        }

        // Search dan return pointer ke data di LinkedList
        Node<T>* search(int key) const {
            BSTNode<T>* result = searchRecursive(root, key);
            if (result != NULL) {
                return result->listPointer;
            }
            return NULL;
        }

        // Cek apakah key ada
        bool contains(int key) const {
            return searchRecursive(root, key) != NULL;
        }

        // Hapus node berdasarkan key
        bool remove(int key) {
            if (!contains(key)) return false;
            root = deleteRecursive(root, key);
            return true;
        }

        // Hapus semua node
        void clear() {
            destroyRecursive(root);
            root = NULL;
            _size = 0;
        }

        // ============ UTILITY FUNCTIONS ============
        
        bool isEmpty() const { 
            return root == NULL; 
        }
        
        int getSize() const { 
            return _size; 
        }

        // Display semua key (inorder = terurut)
        void displayInorder() const {
            if (isEmpty()) {
                std::cout << "BST kosong.\n";
                return;
            }
            std::cout << "=== BST Inorder ===\n";
            inorderRecursive(root);
        }

        // ============ REBUILD INDEX ============
        // Membangun ulang BST dari LinkedList
        void rebuild(LinkedList<T>& list, int (*getKey)(const T&)) {
            clear();
            Node<T>* current = list.getHead();
            while (current != NULL) {
                int key = getKey(current->data);
                insert(key, current);
                current = current->next;
            }
        }
    };

}

#endif
