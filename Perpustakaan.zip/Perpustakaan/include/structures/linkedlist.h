/*************************************************************
 * linkedlist.h
 * Implementasi Double Linked List (Template)
 * 
 * Digunakan sebagai struktur data utama untuk menyimpan:
 * - Daftar Buku
 * - Daftar User  
 * - Daftar Peminjaman
 *************************************************************/

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>

namespace LibSystem {

    // ==================== NODE STRUCTURE ====================
    template <typename T>
    struct Node {
        T data;
        Node* next;
        Node* prev;

        // Constructor
        Node(T val) {
            data = val;
            next = NULL;
            prev = NULL;
        }
    };

    // ==================== DOUBLE LINKED LIST CLASS ====================
    template <typename T>
    class LinkedList {
    private:
        Node<T>* head;
        Node<T>* tail;
        int _size;

    public:
        // ============ CONSTRUCTOR & DESTRUCTOR ============
        LinkedList() {
            head = NULL;
            tail = NULL;
            _size = 0;
        }

        ~LinkedList() {
            clear();
        }

        // ============ BASIC OPERATIONS ============
        
        // Menambah data di belakang (paling umum digunakan)
        void pushBack(T data) {
            Node<T>* newNode = new Node<T>(data);
            
            if (head == NULL) {
                head = tail = newNode;
            } else {
                tail->next = newNode;
                newNode->prev = tail;
                tail = newNode;
            }
            _size++;
        }

        // Menambah data di depan
        void pushFront(T data) {
            Node<T>* newNode = new Node<T>(data);
            
            if (head == NULL) {
                head = tail = newNode;
            } else {
                newNode->next = head;
                head->prev = newNode;
                head = newNode;
            }
            _size++;
        }

        // Menghapus node dari belakang
        bool popBack() {
            if (tail == NULL) return false;
            
            Node<T>* temp = tail;
            
            if (head == tail) {
                head = tail = NULL;
            } else {
                tail = tail->prev;
                tail->next = NULL;
            }
            
            delete temp;
            _size--;
            return true;
        }

        // Menghapus node dari depan
        bool popFront() {
            if (head == NULL) return false;
            
            Node<T>* temp = head;
            
            if (head == tail) {
                head = tail = NULL;
            } else {
                head = head->next;
                head->prev = NULL;
            }
            
            delete temp;
            _size--;
            return true;
        }

        // Menghapus node spesifik berdasarkan pointer
        bool remove(Node<T>* target) {
            if (target == NULL) return false;

            // Jika target adalah head
            if (target == head) {
                head = target->next;
            }
            
            // Jika target adalah tail
            if (target == tail) {
                tail = target->prev;
            }

            // Update link tetangga
            if (target->prev != NULL) {
                target->prev->next = target->next;
            }
            if (target->next != NULL) {
                target->next->prev = target->prev;
            }

            delete target;
            _size--;
            return true;
        }

        // Menghapus semua node
        void clear() {
            Node<T>* current = head;
            while (current != NULL) {
                Node<T>* nextNode = current->next;
                delete current;
                current = nextNode;
            }
            head = tail = NULL;
            _size = 0;
        }

        // ============ GETTER FUNCTIONS ============
        
        Node<T>* getHead() const { 
            return head; 
        }
        
        Node<T>* getTail() const { 
            return tail; 
        }
        
        int getSize() const { 
            return _size; 
        }
        
        bool isEmpty() const { 
            return head == NULL; 
        }

        // ============ SEARCH & ACCESS ============
        
        // Mencari node berdasarkan index (0-based)
        Node<T>* getAt(int index) const {
            if (index < 0 || index >= _size) return NULL;
            
            Node<T>* current = head;
            for (int i = 0; i < index; i++) {
                current = current->next;
            }
            return current;
        }

        // Insert di posisi tertentu
        bool insertAt(int index, T data) {
            if (index < 0 || index > _size) return false;
            
            if (index == 0) {
                pushFront(data);
                return true;
            }
            
            if (index == _size) {
                pushBack(data);
                return true;
            }
            
            Node<T>* current = getAt(index);
            Node<T>* newNode = new Node<T>(data);
            
            newNode->prev = current->prev;
            newNode->next = current;
            current->prev->next = newNode;
            current->prev = newNode;
            
            _size++;
            return true;
        }
    };

}

#endif
