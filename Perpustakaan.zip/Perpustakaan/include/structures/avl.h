/*************************************************************
 * avl.h
 * Implementasi AVL Tree (Self-Balancing BST) - Template
 * 
 * AVL Tree adalah BST yang selalu balance dengan perbedaan
 * tinggi subtree kiri dan kanan maksimal 1.
 * 
 * Keunggulan dibanding BST biasa:
 * - Worst case tetap O(log n) untuk search, insert, delete
 * - BST biasa worst case O(n) jika data sudah terurut
 * 
 * Digunakan untuk:
 * - Index pencarian buku berdasarkan ID (O(log n) guaranteed)
 * - Index pencarian berdasarkan judul (alphabetical order)
 * - Menyimpan data yang sering di-search dengan performa konsisten
 *************************************************************/

#ifndef AVL_H
#define AVL_H

#include <iostream>
#include <algorithm>
#include <string>
#include "linkedlist.h"

namespace LibSystem {

    // ==================== AVL NODE ====================
    template <typename T>
    struct AVLNode {
        int key;                // Key untuk pencarian (biasanya ID)
        Node<T>* listPointer;   // Pointer ke node di LinkedList
        AVLNode* left;
        AVLNode* right;
        int height;             // Tinggi node (untuk balancing)

        AVLNode(int k, Node<T>* ptr) {
            key = k;
            listPointer = ptr;
            left = NULL;
            right = NULL;
            height = 1;         // Node baru selalu height 1
        }
    };

    // ==================== AVL TREE CLASS ====================
    template <typename T>
    class AVLTree {
    private:
        AVLNode<T>* root;
        int _size;

        // ============ HEIGHT & BALANCE HELPERS ============
        
        // Mendapatkan tinggi node (NULL = 0)
        int getHeight(AVLNode<T>* node) const {
            if (node == NULL) return 0;
            return node->height;
        }

        // Update tinggi node berdasarkan anak-anaknya
        void updateHeight(AVLNode<T>* node) {
            if (node != NULL) {
                node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));
            }
        }

        // Mendapatkan balance factor (selisih tinggi kiri - kanan)
        // Balance factor: -1, 0, 1 = balanced
        // Balance factor: < -1 atau > 1 = unbalanced
        int getBalanceFactor(AVLNode<T>* node) const {
            if (node == NULL) return 0;
            return getHeight(node->left) - getHeight(node->right);
        }

        // ============ ROTATION OPERATIONS ============
        
        /*
         * Right Rotation (untuk Left-Left case)
         * 
         *       y                x
         *      / \              / \
         *     x   C    -->     A   y
         *    / \                  / \
         *   A   B                B   C
         */
        AVLNode<T>* rotateRight(AVLNode<T>* y) {
            AVLNode<T>* x = y->left;
            AVLNode<T>* B = x->right;

            // Lakukan rotasi
            x->right = y;
            y->left = B;

            // Update heights (y dulu karena sekarang jadi anak)
            updateHeight(y);
            updateHeight(x);

            return x;  // x jadi root baru
        }

        /*
         * Left Rotation (untuk Right-Right case)
         * 
         *     x                  y
         *    / \                / \
         *   A   y      -->     x   C
         *      / \            / \
         *     B   C          A   B
         */
        AVLNode<T>* rotateLeft(AVLNode<T>* x) {
            AVLNode<T>* y = x->right;
            AVLNode<T>* B = y->left;

            // Lakukan rotasi
            y->left = x;
            x->right = B;

            // Update heights (x dulu karena sekarang jadi anak)
            updateHeight(x);
            updateHeight(y);

            return y;  // y jadi root baru
        }

        // ============ BALANCE FUNCTION ============
        
        /*
         * Menyeimbangkan node setelah insert/delete
         * 
         * 4 kasus yang mungkin terjadi:
         * 1. Left-Left (LL): balance > 1 && key < node->left->key
         *    Solusi: Right rotation
         * 
         * 2. Right-Right (RR): balance < -1 && key > node->right->key
         *    Solusi: Left rotation
         * 
         * 3. Left-Right (LR): balance > 1 && key > node->left->key
         *    Solusi: Left rotation pada left child, lalu Right rotation
         * 
         * 4. Right-Left (RL): balance < -1 && key < node->right->key
         *    Solusi: Right rotation pada right child, lalu Left rotation
         */
        AVLNode<T>* balance(AVLNode<T>* node, int key) {
            // Update height
            updateHeight(node);

            // Cek balance factor
            int bf = getBalanceFactor(node);

            // Left-Left Case
            if (bf > 1 && key < node->left->key) {
                return rotateRight(node);
            }

            // Right-Right Case
            if (bf < -1 && key > node->right->key) {
                return rotateLeft(node);
            }

            // Left-Right Case
            if (bf > 1 && key > node->left->key) {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }

            // Right-Left Case
            if (bf < -1 && key < node->right->key) {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }

            // Sudah balanced
            return node;
        }

        // Balance untuk delete (berbeda karena tidak pakai key comparison)
        AVLNode<T>* balanceAfterDelete(AVLNode<T>* node) {
            if (node == NULL) return NULL;

            updateHeight(node);
            int bf = getBalanceFactor(node);

            // Left-Left Case
            if (bf > 1 && getBalanceFactor(node->left) >= 0) {
                return rotateRight(node);
            }

            // Left-Right Case
            if (bf > 1 && getBalanceFactor(node->left) < 0) {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }

            // Right-Right Case
            if (bf < -1 && getBalanceFactor(node->right) <= 0) {
                return rotateLeft(node);
            }

            // Right-Left Case
            if (bf < -1 && getBalanceFactor(node->right) > 0) {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }

            return node;
        }

        // ============ PRIVATE RECURSIVE OPERATIONS ============
        
        // Insert recursive dengan balancing
        AVLNode<T>* insertRecursive(AVLNode<T>* node, int key, Node<T>* ptr) {
            // 1. Lakukan insert BST biasa
            if (node == NULL) {
                _size++;
                return new AVLNode<T>(key, ptr);
            }

            if (key < node->key) {
                node->left = insertRecursive(node->left, key, ptr);
            } else if (key > node->key) {
                node->right = insertRecursive(node->right, key, ptr);
            } else {
                // Key sama, update pointer saja (tidak duplikat)
                node->listPointer = ptr;
                return node;
            }

            // 2. Balance node ini
            return balance(node, key);
        }

        // Search recursive (sama seperti BST)
        AVLNode<T>* searchRecursive(AVLNode<T>* node, int key) const {
            if (node == NULL || node->key == key) {
                return node;
            }

            if (key < node->key) {
                return searchRecursive(node->left, key);
            }
            return searchRecursive(node->right, key);
        }

        // Find minimum node
        AVLNode<T>* findMin(AVLNode<T>* node) const {
            while (node != NULL && node->left != NULL) {
                node = node->left;
            }
            return node;
        }

        // Find maximum node
        AVLNode<T>* findMax(AVLNode<T>* node) const {
            while (node != NULL && node->right != NULL) {
                node = node->right;
            }
            return node;
        }

        // Delete recursive dengan balancing
        AVLNode<T>* deleteRecursive(AVLNode<T>* node, int key) {
            // 1. Lakukan delete BST biasa
            if (node == NULL) return NULL;

            if (key < node->key) {
                node->left = deleteRecursive(node->left, key);
            } else if (key > node->key) {
                node->right = deleteRecursive(node->right, key);
            } else {
                // Node ditemukan
                
                // Case 1 & 2: Node dengan 0 atau 1 anak
                if (node->left == NULL || node->right == NULL) {
                    AVLNode<T>* temp = node->left ? node->left : node->right;

                    if (temp == NULL) {
                        // Tidak ada anak
                        temp = node;
                        node = NULL;
                    } else {
                        // Satu anak - copy isi
                        *node = *temp;
                    }
                    delete temp;
                    _size--;
                } else {
                    // Case 3: Node dengan 2 anak
                    // Ambil inorder successor (minimum di subtree kanan)
                    AVLNode<T>* successor = findMin(node->right);
                    node->key = successor->key;
                    node->listPointer = successor->listPointer;
                    node->right = deleteRecursive(node->right, successor->key);
                }
            }

            // Jika tree hanya punya satu node
            if (node == NULL) return NULL;

            // 2. Balance node ini
            return balanceAfterDelete(node);
        }

        // Destroy tree recursive
        void destroyRecursive(AVLNode<T>* node) {
            if (node != NULL) {
                destroyRecursive(node->left);
                destroyRecursive(node->right);
                delete node;
            }
        }

        // Inorder traversal (terurut ascending)
        void inorderRecursive(AVLNode<T>* node) const {
            if (node != NULL) {
                inorderRecursive(node->left);
                std::cout << "Key: " << node->key 
                          << " (Height: " << node->height << ")\n";
                inorderRecursive(node->right);
            }
        }

        // Preorder traversal (untuk visualisasi struktur tree)
        void preorderRecursive(AVLNode<T>* node, int level) const {
            if (node != NULL) {
                for (int i = 0; i < level; i++) std::cout << "  ";
                std::cout << "|-- " << node->key 
                          << " (h:" << node->height 
                          << ", bf:" << getBalanceFactor(node) << ")\n";
                preorderRecursive(node->left, level + 1);
                preorderRecursive(node->right, level + 1);
            }
        }

    public:
        // ============ CONSTRUCTOR & DESTRUCTOR ============
        AVLTree() {
            root = NULL;
            _size = 0;
        }

        ~AVLTree() {
            clear();
        }

        // ============ BASIC OPERATIONS ============
        
        // Insert node baru (dengan auto-balancing)
        void insert(int key, Node<T>* ptr) {
            root = insertRecursive(root, key, ptr);
        }

        // Search dan return pointer ke data di LinkedList
        Node<T>* search(int key) const {
            AVLNode<T>* result = searchRecursive(root, key);
            if (result != NULL) {
                return result->listPointer;
            }
            return NULL;
        }

        // Cek apakah key ada
        bool contains(int key) const {
            return searchRecursive(root, key) != NULL;
        }

        // Hapus node berdasarkan key (dengan auto-balancing)
        bool remove(int key) {
            if (!contains(key)) return false;
            root = deleteRecursive(root, key);
            return true;
        }

        // Hapus semua node
        void clear() {
            destroyRecursive(root);
            root = NULL;
            _size = 0;
        }

        // ============ UTILITY FUNCTIONS ============
        
        bool isEmpty() const { 
            return root == NULL; 
        }
        
        int getSize() const { 
            return _size; 
        }

        // Mendapatkan tinggi tree keseluruhan
        int getTreeHeight() const {
            return getHeight(root);
        }

        // Mendapatkan key minimum
        int getMin() const {
            AVLNode<T>* minNode = findMin(root);
            if (minNode != NULL) return minNode->key;
            return -1;  // atau throw exception
        }

        // Mendapatkan key maximum
        int getMax() const {
            AVLNode<T>* maxNode = findMax(root);
            if (maxNode != NULL) return maxNode->key;
            return -1;  // atau throw exception
        }

        // ============ DISPLAY FUNCTIONS ============
        
        // Display semua key (inorder = terurut ascending)
        void displayInorder() const {
            if (isEmpty()) {
                std::cout << "AVL Tree kosong.\n";
                return;
            }
            std::cout << "=== AVL Tree (Inorder) ===\n";
            inorderRecursive(root);
        }

        // Display struktur tree (untuk debugging)
        void displayStructure() const {
            if (isEmpty()) {
                std::cout << "AVL Tree kosong.\n";
                return;
            }
            std::cout << "=== AVL Tree Structure ===\n";
            std::cout << "Root: " << root->key << "\n";
            preorderRecursive(root, 0);
            std::cout << "Tree Height: " << getTreeHeight() << "\n";
            std::cout << "Total Nodes: " << _size << "\n";
        }

        // ============ REBUILD INDEX ============
        // Membangun ulang AVL Tree dari LinkedList
        void rebuild(LinkedList<T>& list, int (*getKey)(const T&)) {
            clear();
            Node<T>* current = list.getHead();
            while (current != NULL) {
                int key = getKey(current->data);
                insert(key, current);
                current = current->next;
            }
        }

        // ============ VALIDATION (untuk testing) ============
        
        // Cek apakah tree valid (BST property + AVL balanced)
        bool isValidAVL() const {
            return isValidAVLRecursive(root);
        }

    private:
        bool isValidAVLRecursive(AVLNode<T>* node) const {
            if (node == NULL) return true;

            // Cek balance factor
            int bf = getBalanceFactor(node);
            if (bf < -1 || bf > 1) return false;

            // Cek BST property
            if (node->left != NULL && node->left->key >= node->key) return false;
            if (node->right != NULL && node->right->key <= node->key) return false;

            // Recursive check
            return isValidAVLRecursive(node->left) && isValidAVLRecursive(node->right);
        }
    };

}

#endif
