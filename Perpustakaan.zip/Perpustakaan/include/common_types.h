/*************************************************************
 * common_types.h
 * Definisi Struktur Data (Struct) untuk Sistem Perpustakaan
 * 
 * Berisi: Buku, User, Peminjaman, SessionLog, AntrianBuku
 *************************************************************/

#ifndef COMMON_TYPES_H
#define COMMON_TYPES_H

#include "config.h"

namespace LibSystem {

    // ==================== STRUCT BUKU ====================
    struct Buku {
        int id;
        char judul[MAX_JUDUL];
        char penulis[MAX_PENULIS];
        char kategori[30];          // Fiksi, Non-Fiksi, Sains, dll
        int tahunTerbit;
        int stok;
        int stokAwal;               // Untuk tracking total koleksi
        bool tersedia;              // true jika stok > 0
        
        // Default constructor
        Buku() {
            id = 0;
            judul[0] = '\0';
            penulis[0] = '\0';
            kategori[0] = '\0';
            tahunTerbit = 0;
            stok = 0;
            stokAwal = 0;
            tersedia = false;
        }
    };

    // ==================== STRUCT USER ====================
    struct User {
        int id;
        char username[MAX_USERNAME];
        char password[MAX_PASSWORD];
        char namaLengkap[50];
        char role[MAX_ROLE];        // "ADMIN" atau "USER"
        char noTelp[15];
        bool aktif;                 // Status akun aktif/nonaktif
        
        // Default constructor
        User() {
            id = 0;
            username[0] = '\0';
            password[0] = '\0';
            namaLengkap[0] = '\0';
            role[0] = '\0';
            noTelp[0] = '\0';
            aktif = true;
        }
    };

    // ==================== STRUCT PEMINJAMAN ====================
    struct Peminjaman {
        int idTransaksi;
        int idUser;
        int idBuku;
        char tglPinjam[MAX_TANGGAL];
        char tglHarusKembali[MAX_TANGGAL];  // Tenggat waktu
        char tglKembali[MAX_TANGGAL];       // Tanggal aktual kembali
        bool sudahKembali;
        long denda;                          // Denda jika telat
        bool dendaDibayar;                   // Status pembayaran denda
        char tglBayarDenda[MAX_TANGGAL];     // Tanggal pembayaran denda
        
        // Default constructor
        Peminjaman() {
            idTransaksi = 0;
            idUser = 0;
            idBuku = 0;
            tglPinjam[0] = '\0';
            tglHarusKembali[0] = '\0';
            tglKembali[0] = '\0';
            sudahKembali = false;
            denda = 0;
            dendaDibayar = false;
            tglBayarDenda[0] = '\0';
        }
    };

    // ==================== STRUCT SESSION LOG (untuk Stack) ====================
    struct SessionLog {
        int idUser;
        char username[MAX_USERNAME];
        char aktivitas[MAX_AKTIVITAS];
        char waktu[MAX_TANGGAL];
        
        // Default constructor
        SessionLog() {
            idUser = 0;
            username[0] = '\0';
            aktivitas[0] = '\0';
            waktu[0] = '\0';
        }
    };

    // ==================== STRUCT ANTRIAN BUKU (untuk Queue) ====================
    struct AntrianBuku {
        int idUser;
        int idBuku;
        char waktuDaftar[MAX_TANGGAL];
        
        // Default constructor
        AntrianBuku() {
            idUser = 0;
            idBuku = 0;
            waktuDaftar[0] = '\0';
        }
    };

}

#endif
