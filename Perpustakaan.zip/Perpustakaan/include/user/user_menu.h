/*************************************************************
 * user_menu.h
 * Menu Utama untuk User (Anggota Perpustakaan)
 * 
 * Menampilkan dan mengelola navigasi menu user
 *************************************************************/

#ifndef USER_MENU_H
#define USER_MENU_H

#include "transaksi.h"
#include "../admin/manager_buku.h"

namespace LibSystem {

    class UserMenu {
    private:
        ManagerBuku& managerBuku;
        TransaksiManager& transaksiManager;

    public:
        // Constructor
        UserMenu(ManagerBuku& mb, TransaksiManager& tm);

        // Menu utama user
        void tampilkanMenu();

    private:
        // Sub-menu
        void menuLihatBuku();
        void menuPinjamBuku();
        void menuKembalikanBuku();
        void menuAntrianSaya();
        void menuProfilSaya();
        
        // Form
        void formCariBuku();
        void formPinjamBuku();
        void formKembalikanBuku();
        void formMasukAntrian(int idBuku);
    };

}

#endif
