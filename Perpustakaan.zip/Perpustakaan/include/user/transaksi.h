/*************************************************************
 * transaksi.h
 * Manajemen Transaksi Peminjaman & Pengembalian Buku
 * 
 * Fitur:
 * - Peminjaman buku
 * - Pengembalian buku
 * - Perhitungan denda otomatis
 * - Antrian reservasi buku (Queue)
 *************************************************************/

#ifndef TRANSAKSI_H
#define TRANSAKSI_H

#include "../structures/linkedlist.h"
#include "../structures/queue.h"
#include "../common_types.h"

namespace LibSystem {

    class TransaksiManager {
    private:
        LinkedList<Peminjaman>& listPinjam;
        LinkedList<Buku>& listBuku;
        LinkedList<User>& listUser;
        Queue<AntrianBuku>& antrianBuku;

    public:
        // Constructor
        TransaksiManager(LinkedList<Peminjaman>& lp, 
                        LinkedList<Buku>& lb,
                        LinkedList<User>& lu,
                        Queue<AntrianBuku>& q);

        // ============ PEMINJAMAN ============
        
        // Pinjam buku (return: ID transaksi, -1 jika gagal)
        int pinjamBuku(int idUser, int idBuku);
        
        // Cek apakah user bisa meminjam (belum melebihi batas)
        bool bisaMeminjam(int idUser);
        
        // Hitung jumlah buku yang sedang dipinjam user
        int hitungPinjamanAktif(int idUser);

        // ============ PENGEMBALIAN ============
        
        // Kembalikan buku berdasarkan ID transaksi
        bool kembalikanBuku(int idTransaksi);
        
        // Kembalikan buku berdasarkan ID user dan ID buku
        bool kembalikanBukuByUserBuku(int idUser, int idBuku);
        
        // Hitung denda keterlambatan
        long hitungDenda(const char* tglPinjam, const char* tglHarusKembali);

        // ============ MANAJEMEN DENDA ============
        
        // Cek total denda belum bayar user
        long getTotalDendaUser(int idUser);
        
        // Cek apakah user memiliki denda belum bayar
        bool punyaDendaBelumBayar(int idUser);
        
        // Cek apakah user diblokir karena denda
        bool terblokirKarenaDenda(int idUser);
        
        // Bayar denda untuk transaksi tertentu
        bool bayarDenda(int idTransaksi);
        
        // Bayar semua denda user
        bool bayarSemuaDendaUser(int idUser);
        
        // Tampilkan denda user
        void tampilkanDendaUser(int idUser);
        
        // Tampilkan semua denda belum bayar (admin)
        void tampilkanSemuaDendaBelumBayar();

        // ============ ANTRIAN / QUEUE ============
        
        // Masukkan user ke antrian reservasi
        void masukAntrian(int idUser, int idBuku);
        
        // Proses antrian saat buku tersedia
        void prosesAntrian(int idBuku);
        
        // Tampilkan antrian untuk buku tertentu
        void tampilkanAntrianBuku(int idBuku);
        
        // Tampilkan semua antrian
        void tampilkanSemuaAntrian();
        
        // Cek apakah user sudah dalam antrian untuk buku tertentu
        bool sudahDalamAntrian(int idUser, int idBuku);
        
        // Batalkan antrian
        bool batalkanAntrian(int idUser, int idBuku);

        // ============ VIEW TRANSAKSI ============
        
        // Tampilkan transaksi user tertentu
        void tampilkanTransaksiUser(int idUser);
        
        // Tampilkan transaksi aktif user (belum dikembalikan)
        void tampilkanPinjamanAktifUser(int idUser);
        
        // Tampilkan history peminjaman user
        void tampilkanHistoryUser(int idUser);
        
        // Tampilkan detail transaksi
        void tampilkanDetailTransaksi(int idTransaksi);

        // ============ UTILITY ============
        
        // Cari transaksi berdasarkan ID
        Node<Peminjaman>* cariTransaksi(int idTransaksi);
        
        // Generate ID transaksi baru
        int generateIdTransaksi();
        
        // Mendapatkan tanggal saat ini (format: DD-MM-YYYY)
        void getTanggalSekarang(char* buffer);
        
        // Menghitung tanggal jatuh tempo
        void getTanggalJatuhTempo(char* buffer, int hariTambahan);
        
        // Getter
        LinkedList<Peminjaman>& getListPinjam();
        Queue<AntrianBuku>& getAntrianBuku();

    private:
        // Helper: Cari buku berdasarkan ID
        Node<Buku>* cariBuku(int idBuku);
        
        // Helper: Cari user berdasarkan ID
        Node<User>* cariUser(int idUser);
        
        // Helper: Hitung selisih hari antara dua tanggal
        int hitungSelisihHari(const char* tgl1, const char* tgl2);
        
        // Helper: Print tabel transaksi
        void printTransaksiHeader();
        void printTransaksiRow(const Peminjaman& p);
        void printSeparator();
        
        // Helper: Dapatkan judul buku
        const char* getJudulBuku(int idBuku);
    };

}

#endif
