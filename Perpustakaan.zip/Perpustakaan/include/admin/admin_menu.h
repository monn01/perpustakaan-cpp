/*************************************************************
 * admin_menu.h
 * Menu Utama untuk Admin
 * 
 * Menampilkan dan mengelola navigasi menu admin
 *************************************************************/

#ifndef ADMIN_MENU_H
#define ADMIN_MENU_H

#include "manager_buku.h"
#include "manager_user.h"
#include "laporan.h"
#include "../user/transaksi.h"

namespace LibSystem {

    class AdminMenu {
    private:
        ManagerBuku& managerBuku;
        ManagerUser& managerUser;
        Laporan& laporan;
        TransaksiManager& transaksiManager;

    public:
        // Constructor
        AdminMenu(ManagerBuku& mb, ManagerUser& mu, Laporan& lap, TransaksiManager& tm);

        // Menu utama admin
        void tampilkanMenu();

    private:
        // Sub-menu
        void menuKelolaBuku();
        void menuKelolaUser();
        void menuLaporan();
        void menuKelolaDenda();
        void menuPengaturan();
        
        // Form input
        void formTambahBuku();
        void formEditBuku();
        void formHapusBuku();
        void formCariBuku();
        
        void formTambahUser();
        void formEditUser();
        void formResetPassword();
        
        void formBayarDenda();
    };

}

#endif
