/*************************************************************
 * manager_user.h
 * Manajemen Data User
 * 
 * Berisi fungsi-fungsi untuk:
 * - Lihat daftar user
 * - Aktifkan/Nonaktifkan user
 * - Reset password user
 * - Lihat riwayat aktivitas (Stack)
 *************************************************************/

#ifndef MANAGER_USER_H
#define MANAGER_USER_H

#include "../structures/linkedlist.h"
#include "../structures/stack.h"
#include "../common_types.h"

namespace LibSystem {

    class ManagerUser {
    private:
        LinkedList<User>& listUser;
        Stack<SessionLog>& activityLog;

    public:
        // Constructor
        ManagerUser(LinkedList<User>& list, Stack<SessionLog>& log);

        // ============ READ ============
        
        // Tampilkan semua user
        void tampilkanSemuaUser();
        
        // Tampilkan user aktif saja
        void tampilkanUserAktif();
        
        // Tampilkan detail user
        void tampilkanDetailUser(int id);
        
        // Cari user berdasarkan ID
        Node<User>* cariUserById(int id);
        
        // Cari user berdasarkan username
        Node<User>* cariUserByUsername(const char* username);

        // ============ UPDATE ============
        
        // Aktifkan user
        bool aktifkanUser(int id);
        
        // Nonaktifkan user
        bool nonaktifkanUser(int id);
        
        // Edit data user
        bool editUser(int id, const char* namaLengkap, const char* noTelp);
        
        // Ubah role user
        bool ubahRole(int id, const char* roleBaru);

        // ============ DELETE ============
        
        // Hapus user (soft delete dengan nonaktif)
        bool hapusUser(int id);

        // ============ ACTIVITY LOG (Stack) ============
        
        // Tambah log aktivitas
        void tambahLog(const char* aktivitas);
        
        // Tampilkan riwayat aktivitas
        void tampilkanRiwayatAktivitas();
        
        // Tampilkan N aktivitas terakhir
        void tampilkanAktivitasTerakhir(int n);
        
        // Bersihkan log
        void clearLog();

        // ============ UTILITY ============
        
        // Hitung total user
        int getTotalUser();
        
        // Hitung user aktif
        int getTotalUserAktif();
        
        // Hitung admin
        int getTotalAdmin();
        
        // Getter
        LinkedList<User>& getListUser();
        Stack<SessionLog>& getActivityLog();

    private:
        // Helper untuk print tabel
        void printTableHeader();
        void printUserRow(const User& user);
        void printSeparator();
    };

}

#endif
