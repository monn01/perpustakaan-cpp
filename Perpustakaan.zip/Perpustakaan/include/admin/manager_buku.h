/*************************************************************
 * manager_buku.h
 * Manajemen Data Buku
 * 
 * Berisi fungsi-fungsi untuk:
 * - Tambah buku baru
 * - Lihat daftar buku
 * - Edit data buku
 * - Hapus buku
 * - Cari buku (menggunakan BST)
 *************************************************************/

#ifndef MANAGER_BUKU_H
#define MANAGER_BUKU_H

#include "../structures/linkedlist.h"
#include "../structures/bst.h"
#include "../common_types.h"

namespace LibSystem {

    class ManagerBuku {
    private:
        LinkedList<Buku>& listBuku;
        BST<Buku>& indexBuku;  // Index untuk pencarian cepat by ID

    public:
        // Constructor
        ManagerBuku(LinkedList<Buku>& list, BST<Buku>& index);

        // ============ CREATE ============
        
        // Tambah buku baru dengan input lengkap
        bool tambahBuku(const char* judul, 
                       const char* penulis, 
                       const char* kategori,
                       int tahunTerbit, 
                       int stok);
        
        // Tambah buku dengan ID manual (untuk admin)
        bool tambahBukuWithId(int id,
                             const char* judul, 
                             const char* penulis, 
                             const char* kategori,
                             int tahunTerbit, 
                             int stok);

        // ============ READ ============
        
        // Tampilkan semua buku
        void tampilkanSemuaBuku();
        
        // Tampilkan buku yang tersedia saja
        void tampilkanBukuTersedia();
        
        // Tampilkan detail satu buku
        void tampilkanDetailBuku(int id);
        
        // Cari buku berdasarkan ID (menggunakan BST)
        Node<Buku>* cariBukuById(int id);
        
        // Cari buku berdasarkan judul (linear search)
        void cariBukuByJudul(const char* keyword);
        
        // Cari buku berdasarkan penulis
        void cariBukuByPenulis(const char* keyword);
        
        // Cari buku berdasarkan kategori
        void cariBukuByKategori(const char* kategori);

        // ============ UPDATE ============
        
        // Edit data buku
        bool editBuku(int id, 
                     const char* judulBaru, 
                     const char* penulisBaru,
                     const char* kategoriBaru,
                     int tahunBaru);
        
        // Update stok buku
        bool updateStok(int id, int stokBaru);
        
        // Kurangi stok (saat dipinjam)
        bool kurangiStok(int id);
        
        // Tambah stok (saat dikembalikan)
        bool tambahStok(int id);

        // ============ DELETE ============
        
        // Hapus buku berdasarkan ID
        bool hapusBuku(int id);

        // ============ UTILITY ============
        
        // Rebuild index BST (setelah ada perubahan)
        void rebuildIndex();
        
        // Hitung total buku
        int getTotalBuku();
        
        // Hitung total stok semua buku
        int getTotalStok();
        
        // Cek apakah buku bisa dihapus (tidak ada yang meminjam)
        bool bisaDihapus(int id, LinkedList<Peminjaman>& listPinjam);
        
        // Getter untuk listBuku (untuk keperluan lain)
        LinkedList<Buku>& getListBuku();

    private:
        // Helper untuk print header tabel
        void printTableHeader();
        
        // Helper untuk print satu baris buku
        void printBukuRow(const Buku& buku);
        
        // Helper untuk print separator
        void printSeparator();
    };

}

#endif
