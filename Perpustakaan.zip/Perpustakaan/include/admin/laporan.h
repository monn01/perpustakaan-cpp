/*************************************************************
 * laporan.h
 * Modul Laporan dan Statistik Perpustakaan
 * 
 * Berisi fungsi-fungsi untuk:
 * - Laporan transaksi peminjaman
 * - Statistik denda
 * - Buku terpopuler
 * - Ringkasan sistem
 *************************************************************/

#ifndef LAPORAN_H
#define LAPORAN_H

#include "../structures/linkedlist.h"
#include "../common_types.h"

namespace LibSystem {

    class Laporan {
    private:
        LinkedList<Peminjaman>& listPinjam;
        LinkedList<Buku>& listBuku;
        LinkedList<User>& listUser;

    public:
        // Constructor
        Laporan(LinkedList<Peminjaman>& lp, LinkedList<Buku>& lb, LinkedList<User>& lu);

        // ============ LAPORAN TRANSAKSI ============
        
        // Tampilkan semua transaksi
        void tampilkanSemuaTransaksi();
        
        // Tampilkan transaksi aktif (belum dikembalikan)
        void tampilkanTransaksiAktif();
        
        // Tampilkan transaksi selesai
        void tampilkanTransaksiSelesai();
        
        // Tampilkan transaksi by user
        void tampilkanTransaksiByUser(int idUser);

        // ============ LAPORAN DENDA ============
        
        // Tampilkan daftar denda
        void tampilkanDaftarDenda();
        
        // Hitung total denda yang masuk
        long hitungTotalDenda();
        
        // Hitung total denda yang belum dibayar
        long hitungDendaBelumBayar();

        // ============ STATISTIK BUKU ============
        
        // Tampilkan buku terpopuler (paling sering dipinjam)
        void tampilkanBukuTerpopuler(int top);
        
        // Tampilkan buku yang sedang dipinjam
        void tampilkanBukuDipinjam();
        
        // Statistik per kategori
        void tampilkanStatistikKategori();

        // ============ RINGKASAN SISTEM ============
        
        // Dashboard ringkasan
        void tampilkanDashboard();
        
        // Statistik lengkap
        void tampilkanStatistikLengkap();

    private:
        // Helper functions
        void printTransaksiHeader();
        void printTransaksiRow(const Peminjaman& p);
        void printSeparator();
        
        // Mendapatkan judul buku berdasarkan ID
        const char* getJudulBuku(int idBuku);
        
        // Mendapatkan username berdasarkan ID
        const char* getUsername(int idUser);
        
        // Menghitung jumlah peminjaman per buku
        int hitungPeminjamanBuku(int idBuku);
    };

}

#endif
