<?php
/**
 * ============================================================
 * LAPORAN & STATISTIK
 * Halaman laporan dan statistik perpustakaan
 * ============================================================
 */

$pageTitle = 'Laporan';
require_once '../includes/header_admin.php';

$db = db();

// Statistik Umum
$totalBuku = getTotalBuku();
$totalUser = getTotalUser();
$totalPeminjaman = $db->query("SELECT COUNT(*) as total FROM peminjaman")->fetch()['total'];
$totalDenda = $db->query("SELECT SUM(denda) as total FROM peminjaman WHERE denda > 0")->fetch()['total'] ?? 0;

// Peminjaman per bulan (12 bulan terakhir)
$stmt = $db->query("
    SELECT 
        DATE_FORMAT(tanggal_pinjam, '%Y-%m') as bulan,
        COUNT(*) as total
    FROM peminjaman
    WHERE tanggal_pinjam >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(tanggal_pinjam, '%Y-%m')
    ORDER BY bulan ASC
");
$peminjamanPerBulan = $stmt->fetchAll();

// Buku paling populer
$stmt = $db->query("
    SELECT b.judul, b.penulis, COUNT(p.id) as total_pinjam
    FROM buku b
    LEFT JOIN peminjaman p ON b.id = p.buku_id
    GROUP BY b.id
    ORDER BY total_pinjam DESC
    LIMIT 10
");
$bukuPopuler = $stmt->fetchAll();

// Kategori paling populer
$stmt = $db->query("
    SELECT k.nama_kategori, COUNT(p.id) as total_pinjam
    FROM kategori k
    LEFT JOIN buku b ON k.id = b.kategori_id
    LEFT JOIN peminjaman p ON b.id = p.buku_id
    GROUP BY k.id
    ORDER BY total_pinjam DESC
    LIMIT 5
");
$kategoriPopuler = $stmt->fetchAll();

// User teraktif
$stmt = $db->query("
    SELECT u.nama_lengkap, u.username, COUNT(p.id) as total_pinjam
    FROM users u
    LEFT JOIN peminjaman p ON u.id = p.user_id
    WHERE u.role = 'user'
    GROUP BY u.id
    ORDER BY total_pinjam DESC
    LIMIT 10
");
$userAktif = $stmt->fetchAll();

// Statistik hari ini
$stmt = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE DATE(tanggal_pinjam) = CURDATE()");
$pinjamHariIni = $stmt->fetch()['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE DATE(tanggal_kembali) = CURDATE()");
$kembaliHariIni = $stmt->fetch()['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM users WHERE DATE(created_at) = CURDATE()");
$userBaruHariIni = $stmt->fetch()['total'];

// Bulan names
$bulanNames = [
    '01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr',
    '05' => 'Mei', '06' => 'Jun', '07' => 'Jul', '08' => 'Agu',
    '09' => 'Sep', '10' => 'Okt', '11' => 'Nov', '12' => 'Des'
];
?>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bxs-book'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalBuku ?></h3>
            <p>Total Buku</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon purple">
            <i class='bx bxs-user-detail'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalUser ?></h3>
            <p>Total Anggota</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-transfer-alt'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalPeminjaman ?></h3>
            <p>Total Peminjaman</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class='bx bx-money'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah($totalDenda) ?></h3>
            <p>Total Denda</p>
        </div>
    </div>
</div>

<!-- Statistik Hari Ini -->
<div class="dashboard-card" style="margin-bottom: 1.5rem;">
    <div class="card-header">
        <h2><i class='bx bx-calendar-check'></i> Statistik Hari Ini (<?= formatTanggal(date('Y-m-d'), 'd F Y') ?>)</h2>
    </div>
    <div class="card-body">
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; text-align: center;">
            <div style="padding: 1.5rem; background: var(--primary-bg); border-radius: var(--radius-lg);">
                <h3 style="font-size: 2rem; color: var(--primary);"><?= $pinjamHariIni ?></h3>
                <p style="color: var(--gray-600);">Peminjaman Baru</p>
            </div>
            <div style="padding: 1.5rem; background: #D1FAE5; border-radius: var(--radius-lg);">
                <h3 style="font-size: 2rem; color: #059669;"><?= $kembaliHariIni ?></h3>
                <p style="color: var(--gray-600);">Pengembalian</p>
            </div>
            <div style="padding: 1.5rem; background: #EDE9FE; border-radius: var(--radius-lg);">
                <h3 style="font-size: 2rem; color: #7C3AED;"><?= $userBaruHariIni ?></h3>
                <p style="color: var(--gray-600);">Anggota Baru</p>
            </div>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <!-- Grafik Peminjaman -->
    <div class="dashboard-card">
        <div class="card-header">
            <h2><i class='bx bx-line-chart'></i> Tren Peminjaman (12 Bulan Terakhir)</h2>
        </div>
        <div class="card-body">
            <?php if (empty($peminjamanPerBulan)): ?>
                <div style="text-align: center; padding: 2rem; color: var(--gray-500);">
                    <i class='bx bx-bar-chart-alt-2' style="font-size: 3rem; color: var(--gray-300);"></i>
                    <p style="margin-top: 1rem;">Belum ada data peminjaman</p>
                </div>
            <?php else: ?>
            <div style="display: flex; align-items: flex-end; gap: 0.5rem; height: 200px; padding-top: 1rem;">
                <?php 
                $totals = array_column($peminjamanPerBulan, 'total');
                $maxVal = !empty($totals) ? max($totals) : 1;
                foreach ($peminjamanPerBulan as $data): 
                    $height = ($data['total'] / $maxVal) * 150;
                    $bulanParts = explode('-', $data['bulan']);
                    $bulanLabel = $bulanNames[$bulanParts[1]] ?? $bulanParts[1];
                ?>
                    <div style="flex: 1; text-align: center;">
                        <div style="height: <?= max($height, 10) ?>px; background: linear-gradient(180deg, var(--primary) 0%, var(--primary-light) 100%); border-radius: 4px 4px 0 0; margin-bottom: 0.5rem;" 
                             title="<?= $data['total'] ?> peminjaman"></div>
                        <small style="font-size: 0.7rem; color: var(--gray-500);"><?= $bulanLabel ?></small>
                        <small style="display: block; font-weight: 600; color: var(--gray-700);"><?= $data['total'] ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Kategori Populer -->
    <div class="dashboard-card">
        <div class="card-header">
            <h2><i class='bx bx-category'></i> Kategori Terpopuler</h2>
        </div>
        <div class="card-body">
            <?php if (empty($kategoriPopuler)): ?>
                <div style="text-align: center; padding: 2rem; color: var(--gray-500);">
                    <i class='bx bx-category' style="font-size: 3rem; color: var(--gray-300);"></i>
                    <p style="margin-top: 1rem;">Belum ada data kategori</p>
                </div>
            <?php else: ?>
            <?php 
            $totalsKat = array_column($kategoriPopuler, 'total_pinjam');
            $maxKat = !empty($totalsKat) ? max($totalsKat) : 1;
            foreach ($kategoriPopuler as $kat): 
                $percent = ($kat['total_pinjam'] / $maxKat) * 100;
            ?>
                <div style="margin-bottom: 1rem;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                        <span style="font-weight: 500;"><?= e($kat['nama_kategori']) ?></span>
                        <span style="color: var(--gray-500);"><?= $kat['total_pinjam'] ?> pinjam</span>
                    </div>
                    <div style="height: 8px; background: var(--gray-200); border-radius: 4px; overflow: hidden;">
                        <div style="height: 100%; width: <?= $percent ?>%; background: var(--primary); border-radius: 4px;"></div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Tabel Buku Populer & User Aktif -->
<div class="dashboard-grid" style="margin-top: 1.5rem;">
    <!-- Buku Populer -->
    <div class="dashboard-card">
        <div class="card-header">
            <h2><i class='bx bx-trending-up'></i> 10 Buku Terpopuler</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Judul</th>
                            <th>Penulis</th>
                            <th>Dipinjam</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bukuPopuler as $index => $buku): ?>
                            <tr>
                                <td>
                                    <span style="width: 24px; height: 24px; background: <?= $index < 3 ? 'var(--primary)' : 'var(--gray-200)' ?>; color: <?= $index < 3 ? 'white' : 'var(--gray-600)' ?>; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 600;">
                                        <?= $index + 1 ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?= e(substr($buku['judul'], 0, 30)) ?><?= strlen($buku['judul']) > 30 ? '...' : '' ?></strong>
                                </td>
                                <td style="color: var(--gray-500);"><?= e($buku['penulis']) ?></td>
                                <td>
                                    <span class="badge badge-primary"><?= $buku['total_pinjam'] ?>x</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- User Aktif -->
    <div class="dashboard-card">
        <div class="card-header">
            <h2><i class='bx bx-user-check'></i> 10 Anggota Teraktif</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Nama</th>
                            <th>Peminjaman</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($userAktif as $index => $user): ?>
                            <tr>
                                <td>
                                    <span style="width: 24px; height: 24px; background: <?= $index < 3 ? 'var(--success)' : 'var(--gray-200)' ?>; color: <?= $index < 3 ? 'white' : 'var(--gray-600)' ?>; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 600;">
                                        <?= $index + 1 ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?= e($user['nama_lengkap']) ?></strong>
                                    <small style="display: block; color: var(--gray-500);">@<?= e($user['username']) ?></small>
                                </td>
                                <td>
                                    <span class="badge badge-success"><?= $user['total_pinjam'] ?>x</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>