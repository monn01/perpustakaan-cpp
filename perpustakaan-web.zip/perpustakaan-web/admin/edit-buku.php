<?php
/**
 * ============================================================
 * EDIT BUKU
 * Form untuk mengedit data buku
 * ============================================================
 */

$pageTitle = 'Edit Buku';
require_once '../includes/header_admin.php';

$db = db();

// Ambil ID buku
$bukuId = intval($_GET['id'] ?? 0);

if (!$bukuId) {
    setFlash('error', 'Buku tidak ditemukan.');
    redirect(APP_URL . '/admin/kelola-buku.php');
}

// Ambil data buku
$stmt = $db->prepare("SELECT * FROM buku WHERE id = ?");
$stmt->execute([$bukuId]);
$buku = $stmt->fetch();

if (!$buku) {
    setFlash('error', 'Buku tidak ditemukan.');
    redirect(APP_URL . '/admin/kelola-buku.php');
}

// Ambil semua kategori
$stmtKat = $db->query("SELECT * FROM kategori ORDER BY nama_kategori");
$kategoriList = $stmtKat->fetchAll();

$error = '';

// Proses update buku
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Token tidak valid.';
    } else {
        $formData = [
            'isbn' => trim($_POST['isbn'] ?? ''),
            'judul' => trim($_POST['judul'] ?? ''),
            'penulis' => trim($_POST['penulis'] ?? ''),
            'penerbit' => trim($_POST['penerbit'] ?? ''),
            'tahun_terbit' => intval($_POST['tahun_terbit'] ?? 0),
            'kategori_id' => intval($_POST['kategori_id'] ?? 0),
            'deskripsi' => trim($_POST['deskripsi'] ?? ''),
            'stok' => intval($_POST['stok'] ?? 0),
            'lokasi_rak' => trim($_POST['lokasi_rak'] ?? '')
        ];
        
        // Validasi
        if (empty($formData['judul'])) {
            $error = 'Judul buku harus diisi.';
        } elseif (empty($formData['penulis'])) {
            $error = 'Penulis harus diisi.';
        } elseif ($formData['stok'] < 0) {
            $error = 'Stok tidak boleh negatif.';
        } else {
            // Cek ISBN unik jika diisi (kecuali milik sendiri)
            if (!empty($formData['isbn'])) {
                $stmt = $db->prepare("SELECT id FROM buku WHERE isbn = ? AND id != ?");
                $stmt->execute([$formData['isbn'], $bukuId]);
                if ($stmt->fetch()) {
                    $error = 'ISBN sudah digunakan.';
                }
            }
            
            if (empty($error)) {
                // Hitung stok_tersedia baru
                $sedangDipinjam = $buku['stok'] - $buku['stok_tersedia'];
                $stokTersediaBaru = max(0, $formData['stok'] - $sedangDipinjam);
                
                $stmt = $db->prepare("
                    UPDATE buku SET 
                        isbn = ?, judul = ?, penulis = ?, penerbit = ?, 
                        tahun_terbit = ?, kategori_id = ?, deskripsi = ?, 
                        stok = ?, stok_tersedia = ?, lokasi_rak = ?,
                        updated_at = NOW()
                    WHERE id = ?
                ");
                
                $stmt->execute([
                    $formData['isbn'] ?: null,
                    $formData['judul'],
                    $formData['penulis'],
                    $formData['penerbit'] ?: null,
                    $formData['tahun_terbit'] ?: null,
                    $formData['kategori_id'] ?: null,
                    $formData['deskripsi'] ?: null,
                    $formData['stok'],
                    $stokTersediaBaru,
                    $formData['lokasi_rak'] ?: null,
                    $bukuId
                ]);
                
                logActivity($_SESSION['user_id'], 'Edit Buku', "Mengedit buku: {$formData['judul']}");
                setFlash('success', 'Buku berhasil diperbarui.');
                redirect(APP_URL . '/admin/kelola-buku.php');
            }
        }
        
        // Update data untuk form
        $buku = array_merge($buku, $formData);
    }
}
?>

<!-- Breadcrumb -->
<div class="breadcrumb" style="margin-bottom: 1.5rem;">
    <a href="<?= APP_URL ?>/admin/dashboard.php">Dashboard</a>
    <span class="separator" style="margin: 0 0.5rem; color: var(--gray-400);">/</span>
    <a href="<?= APP_URL ?>/admin/kelola-buku.php">Kelola Buku</a>
    <span class="separator" style="margin: 0 0.5rem; color: var(--gray-400);">/</span>
    <span style="color: var(--gray-700);">Edit Buku</span>
</div>

<div class="dashboard-card">
    <div class="card-header">
        <h2><i class='bx bx-edit'></i> Edit Buku</h2>
    </div>
    <div class="card-body">
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class='bx bx-x-circle'></i> <?= e($error) ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <?= csrfField() ?>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                <!-- Kolom Kiri -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Judul Buku <span style="color: var(--danger);">*</span></label>
                        <input type="text" name="judul" class="form-control" 
                               value="<?= e($buku['judul']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Penulis <span style="color: var(--danger);">*</span></label>
                        <input type="text" name="penulis" class="form-control" 
                               value="<?= e($buku['penulis']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Penerbit</label>
                        <input type="text" name="penerbit" class="form-control" 
                               value="<?= e($buku['penerbit'] ?? '') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">ISBN</label>
                        <input type="text" name="isbn" class="form-control" 
                               value="<?= e($buku['isbn'] ?? '') ?>"
                               placeholder="978-xxx-xxxx-xx">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="4"
                                  placeholder="Sinopsis atau deskripsi buku..."><?= e($buku['deskripsi'] ?? '') ?></textarea>
                    </div>
                </div>
                
                <!-- Kolom Kanan -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Kategori</label>
                        <select name="kategori_id" class="form-control">
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($kategoriList as $kat): ?>
                                <option value="<?= $kat['id'] ?>" <?= $buku['kategori_id'] == $kat['id'] ? 'selected' : '' ?>>
                                    <?= e($kat['nama_kategori']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Tahun Terbit</label>
                        <input type="number" name="tahun_terbit" class="form-control" 
                               value="<?= e($buku['tahun_terbit'] ?? '') ?>"
                               min="1900" max="<?= date('Y') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Jumlah Stok <span style="color: var(--danger);">*</span></label>
                        <input type="number" name="stok" class="form-control" 
                               value="<?= e($buku['stok']) ?>"
                               min="0" required>
                        <small style="color: var(--gray-500);">
                            Stok tersedia saat ini: <strong><?= $buku['stok_tersedia'] ?></strong> 
                            (<?= $buku['stok'] - $buku['stok_tersedia'] ?> sedang dipinjam)
                        </small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Lokasi Rak</label>
                        <input type="text" name="lokasi_rak" class="form-control" 
                               value="<?= e($buku['lokasi_rak'] ?? '') ?>"
                               placeholder="Contoh: A-01">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Info Tambahan</label>
                        <div style="padding: 1rem; background: var(--gray-50); border-radius: var(--radius); font-size: 0.875rem; color: var(--gray-600);">
                            <p style="margin: 0 0 0.5rem;"><strong>ID Buku:</strong> <?= $buku['id'] ?></p>
                            <p style="margin: 0 0 0.5rem;"><strong>Ditambahkan:</strong> <?= formatTanggal($buku['created_at'], 'd M Y H:i') ?></p>
                            <p style="margin: 0;"><strong>Terakhir diubah:</strong> <?= formatTanggal($buku['updated_at'], 'd M Y H:i') ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--gray-200); display: flex; gap: 1rem;">
                <button type="submit" class="btn btn-primary">
                    <i class='bx bx-save'></i> Simpan Perubahan
                </button>
                <a href="<?= APP_URL ?>/admin/kelola-buku.php" class="btn btn-secondary">
                    <i class='bx bx-x'></i> Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>
