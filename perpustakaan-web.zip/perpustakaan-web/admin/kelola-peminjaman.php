<?php
/**
 * ============================================================
 * KELOLA PEMINJAMAN
 * Manajemen data peminjaman
 * ============================================================
 */

$pageTitle = 'Kelola Peminjaman';
require_once '../includes/header_admin.php';

$db = db();
$dendaPerHari = getSetting('denda_per_hari', 3000);

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCsrfToken($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $peminjamanId = intval($_POST['peminjaman_id'] ?? 0);
    
    if ($action === 'kembalikan' && $peminjamanId) {
        // Proses pengembalian
        $stmt = $db->prepare("SELECT * FROM peminjaman WHERE id = ? AND status = 'dipinjam'");
        $stmt->execute([$peminjamanId]);
        $peminjaman = $stmt->fetch();
        
        if ($peminjaman) {
            $tanggalKembali = date('Y-m-d');
            $denda = 0;
            
            // Hitung denda
            $hariTerlambat = (strtotime($tanggalKembali) - strtotime($peminjaman['tanggal_harus_kembali'])) / (60 * 60 * 24);
            if ($hariTerlambat > 0) {
                $denda = $hariTerlambat * $dendaPerHari;
            }
            
            $stmt = $db->prepare("UPDATE peminjaman SET status = 'dikembalikan', tanggal_kembali = ?, denda = ? WHERE id = ?");
            $stmt->execute([$tanggalKembali, $denda, $peminjamanId]);
            
            logActivity($_SESSION['user_id'], 'Pengembalian Admin', "Admin memproses pengembalian ID: {$peminjamanId}");
            
            if ($denda > 0) {
                setFlash('warning', 'Buku dikembalikan. Denda keterlambatan: ' . formatRupiah($denda));
            } else {
                setFlash('success', 'Buku berhasil dikembalikan.');
            }
        }
    } elseif ($action === 'perpanjang' && $peminjamanId) {
        // Perpanjang peminjaman 7 hari
        $stmt = $db->prepare("
            UPDATE peminjaman 
            SET tanggal_harus_kembali = DATE_ADD(tanggal_harus_kembali, INTERVAL 7 DAY)
            WHERE id = ? AND status = 'dipinjam'
        ");
        $stmt->execute([$peminjamanId]);
        
        logActivity($_SESSION['user_id'], 'Perpanjang Pinjam', "Admin memperpanjang peminjaman ID: {$peminjamanId}");
        setFlash('success', 'Peminjaman berhasil diperpanjang 7 hari.');
    }
    
    redirect(APP_URL . '/admin/kelola-peminjaman.php?' . http_build_query($_GET));
}

// Ambil parameter
$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build query
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(u.nama_lengkap LIKE ? OR u.username LIKE ? OR b.judul LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if ($status === 'aktif') {
    $where[] = "p.status = 'dipinjam'";
} elseif ($status === 'terlambat') {
    $where[] = "p.status = 'dipinjam' AND p.tanggal_harus_kembali < CURDATE()";
} elseif ($status === 'selesai') {
    $where[] = "p.status = 'dikembalikan'";
}

$whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Hitung total
$stmtCount = $db->prepare("
    SELECT COUNT(*) as total 
    FROM peminjaman p
    JOIN users u ON p.user_id = u.id
    JOIN buku b ON p.buku_id = b.id
    {$whereClause}
");
$stmtCount->execute($params);
$totalData = $stmtCount->fetch()['total'];
$totalPages = ceil($totalData / $perPage);

// Ambil data
$stmt = $db->prepare("
    SELECT p.*, u.nama_lengkap, u.username, b.judul, b.penulis,
           DATEDIFF(CURDATE(), p.tanggal_harus_kembali) as hari_terlambat
    FROM peminjaman p
    JOIN users u ON p.user_id = u.id
    JOIN buku b ON p.buku_id = b.id
    {$whereClause}
    ORDER BY 
        CASE p.status WHEN 'dipinjam' THEN 0 ELSE 1 END,
        p.tanggal_harus_kembali ASC
    LIMIT {$perPage} OFFSET {$offset}
");
$stmt->execute($params);
$peminjamanList = $stmt->fetchAll();

// Statistik
$stmtAktif = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE status = 'dipinjam'");
$totalAktif = $stmtAktif->fetch()['total'];

$stmtTerlambat = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE status = 'dipinjam' AND tanggal_harus_kembali < CURDATE()");
$totalTerlambat = $stmtTerlambat->fetch()['total'];

$stmtSelesai = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE status = 'dikembalikan'");
$totalSelesai = $stmtSelesai->fetch()['total'];
?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns: repeat(4, 1fr); margin-bottom: 1.5rem;">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bx-transfer-alt'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalData ?></h3>
            <p>Total Peminjaman</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class='bx bx-book-open'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalAktif ?></h3>
            <p>Sedang Dipinjam</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red">
            <i class='bx bx-time-five'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalTerlambat ?></h3>
            <p>Terlambat</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-check-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalSelesai ?></h3>
            <p>Dikembalikan</p>
        </div>
    </div>
</div>

<!-- Filter & Search -->
<div class="dashboard-card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET" action="" style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 250px;">
                <input type="text" name="search" class="form-control" 
                       placeholder="Cari nama user atau judul buku..."
                       value="<?= e($search) ?>">
            </div>
            <div style="min-width: 180px;">
                <select name="status" class="form-control">
                    <option value="">Semua Status</option>
                    <option value="aktif" <?= $status === 'aktif' ? 'selected' : '' ?>>Sedang Dipinjam</option>
                    <option value="terlambat" <?= $status === 'terlambat' ? 'selected' : '' ?>>Terlambat</option>
                    <option value="selesai" <?= $status === 'selesai' ? 'selected' : '' ?>>Dikembalikan</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class='bx bx-search'></i> Cari
            </button>
            <?php if (!empty($search) || !empty($status)): ?>
                <a href="<?= APP_URL ?>/admin/kelola-peminjaman.php" class="btn btn-secondary">
                    <i class='bx bx-x'></i> Reset
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Tabel Peminjaman -->
<div class="dashboard-card">
    <div class="card-body">
        <?php if (empty($peminjamanList)): ?>
            <div style="text-align: center; padding: 3rem;">
                <i class='bx bx-transfer-alt' style="font-size: 5rem; color: var(--gray-300);"></i>
                <h3 style="color: var(--gray-600); margin-top: 1rem;">Tidak ada data peminjaman</h3>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>Peminjam</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Jatuh Tempo</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                            <th>Denda</th>
                            <th width="120">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($peminjamanList as $index => $p): ?>
                            <tr>
                                <td><?= $offset + $index + 1 ?></td>
                                <td>
                                    <strong><?= e($p['nama_lengkap']) ?></strong>
                                    <small style="display: block; color: var(--gray-500);">@<?= e($p['username']) ?></small>
                                </td>
                                <td>
                                    <strong><?= e(substr($p['judul'], 0, 25)) ?><?= strlen($p['judul']) > 25 ? '...' : '' ?></strong>
                                    <small style="display: block; color: var(--gray-500);"><?= e($p['penulis']) ?></small>
                                </td>
                                <td><?= formatTanggal($p['tanggal_pinjam']) ?></td>
                                <td><?= formatTanggal($p['tanggal_harus_kembali']) ?></td>
                                <td><?= $p['tanggal_kembali'] ? formatTanggal($p['tanggal_kembali']) : '-' ?></td>
                                <td>
                                    <?php if ($p['status'] === 'dikembalikan'): ?>
                                        <span class="badge badge-success">Dikembalikan</span>
                                    <?php elseif ($p['hari_terlambat'] > 0): ?>
                                        <span class="badge badge-danger">Terlambat <?= $p['hari_terlambat'] ?> hari</span>
                                    <?php elseif ($p['hari_terlambat'] >= -2): ?>
                                        <span class="badge badge-warning">Segera JT</span>
                                    <?php else: ?>
                                        <span class="badge badge-primary">Dipinjam</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['denda'] > 0): ?>
                                        <span style="color: var(--danger); font-weight: 500;">
                                            <?= formatRupiah($p['denda']) ?>
                                        </span>
                                        <?php if ($p['denda_dibayar']): ?>
                                            <span class="badge badge-success">Lunas</span>
                                        <?php endif; ?>
                                    <?php elseif ($p['status'] === 'dipinjam' && $p['hari_terlambat'] > 0): ?>
                                        <span style="color: var(--warning);">
                                            ~<?= formatRupiah($p['hari_terlambat'] * $dendaPerHari) ?>
                                        </span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['status'] === 'dipinjam'): ?>
                                        <div class="action-buttons">
                                            <!-- Kembalikan -->
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Proses pengembalian buku ini?')">
                                                <?= csrfField() ?>
                                                <input type="hidden" name="action" value="kembalikan">
                                                <input type="hidden" name="peminjaman_id" value="<?= $p['id'] ?>">
                                                <button type="submit" class="btn-icon btn-view" title="Kembalikan">
                                                    <i class='bx bx-check'></i>
                                                </button>
                                            </form>
                                            
                                            <!-- Perpanjang -->
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Perpanjang peminjaman 7 hari?')">
                                                <?= csrfField() ?>
                                                <input type="hidden" name="action" value="perpanjang">
                                                <input type="hidden" name="peminjaman_id" value="<?= $p['id'] ?>">
                                                <button type="submit" class="btn-icon btn-edit" title="Perpanjang">
                                                    <i class='bx bx-calendar-plus'></i>
                                                </button>
                                            </form>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: var(--gray-400);">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php 
                    $queryParams = $_GET;
                    if ($page > 1): 
                        $queryParams['page'] = $page - 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-left'></i></a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): 
                        $queryParams['page'] = $i;
                    ?>
                        <?php if ($i === $page): ?>
                            <span class="active"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?<?= http_build_query($queryParams) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): 
                        $queryParams['page'] = $page + 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-right'></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>
