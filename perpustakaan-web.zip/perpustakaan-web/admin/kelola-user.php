<?php
/**
 * ============================================================
 * KELOLA USER
 * Manajemen data user/anggota
 * ============================================================
 */

$pageTitle = 'Kelola User';
require_once '../includes/header_admin.php';

$db = db();

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCsrfToken($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $userId = intval($_POST['user_id'] ?? 0);
    
    if ($action === 'toggle_status' && $userId) {
        // Toggle status aktif/nonaktif
        $stmt = $db->prepare("UPDATE users SET status = IF(status = 'aktif', 'nonaktif', 'aktif') WHERE id = ? AND role = 'user'");
        $stmt->execute([$userId]);
        
        logActivity($_SESSION['user_id'], 'Update User', "Mengubah status user ID: {$userId}");
        setFlash('success', 'Status user berhasil diubah.');
        
    } elseif ($action === 'delete' && $userId) {
        // Cek apakah user punya peminjaman aktif
        $stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ? AND status = 'dipinjam'");
        $stmt->execute([$userId]);
        $peminjamanAktif = $stmt->fetch()['total'];
        
        if ($peminjamanAktif > 0) {
            setFlash('error', 'User tidak dapat dihapus karena masih memiliki peminjaman aktif.');
        } else {
            $stmt = $db->prepare("DELETE FROM users WHERE id = ? AND role = 'user'");
            $stmt->execute([$userId]);
            
            logActivity($_SESSION['user_id'], 'Hapus User', "Menghapus user ID: {$userId}");
            setFlash('success', 'User berhasil dihapus.');
        }
    } elseif ($action === 'reset_password' && $userId) {
        // Reset password ke default
        $defaultPassword = password_hash('password123', PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ? AND role = 'user'");
        $stmt->execute([$defaultPassword, $userId]);
        
        logActivity($_SESSION['user_id'], 'Reset Password', "Reset password user ID: {$userId}");
        setFlash('success', 'Password berhasil direset ke: password123');
    }
    
    redirect(APP_URL . '/admin/kelola-user.php');
}

// Ambil parameter
$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build query
$where = ["role = 'user'"];
$params = [];

if (!empty($search)) {
    $where[] = "(username LIKE ? OR nama_lengkap LIKE ? OR email LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($status)) {
    $where[] = "status = ?";
    $params[] = $status;
}

$whereClause = 'WHERE ' . implode(' AND ', $where);

// Hitung total
$stmtCount = $db->prepare("SELECT COUNT(*) as total FROM users {$whereClause}");
$stmtCount->execute($params);
$totalData = $stmtCount->fetch()['total'];
$totalPages = ceil($totalData / $perPage);

// Ambil data user
$stmt = $db->prepare("
    SELECT u.*,
           (SELECT COUNT(*) FROM peminjaman WHERE user_id = u.id AND status = 'dipinjam') as pinjaman_aktif,
           (SELECT SUM(denda) FROM peminjaman WHERE user_id = u.id AND denda > 0 AND denda_dibayar = 0) as total_denda
    FROM users u
    {$whereClause}
    ORDER BY u.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$stmt->execute($params);
$userList = $stmt->fetchAll();

// Statistik
$stmtAktif = $db->query("SELECT COUNT(*) as total FROM users WHERE role = 'user' AND status = 'aktif'");
$totalAktif = $stmtAktif->fetch()['total'];

$stmtNonaktif = $db->query("SELECT COUNT(*) as total FROM users WHERE role = 'user' AND status = 'nonaktif'");
$totalNonaktif = $stmtNonaktif->fetch()['total'];
?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns: repeat(3, 1fr); margin-bottom: 1.5rem;">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bxs-user-detail'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalData ?></h3>
            <p>Total Anggota</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-check-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalAktif ?></h3>
            <p>Aktif</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red">
            <i class='bx bx-x-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalNonaktif ?></h3>
            <p>Nonaktif</p>
        </div>
    </div>
</div>

<!-- Filter & Search -->
<div class="dashboard-card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET" action="" style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 250px;">
                <input type="text" name="search" class="form-control" 
                       placeholder="Cari username, nama, atau email..."
                       value="<?= e($search) ?>">
            </div>
            <div style="min-width: 150px;">
                <select name="status" class="form-control">
                    <option value="">Semua Status</option>
                    <option value="aktif" <?= $status === 'aktif' ? 'selected' : '' ?>>Aktif</option>
                    <option value="nonaktif" <?= $status === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class='bx bx-search'></i> Cari
            </button>
            <?php if (!empty($search) || !empty($status)): ?>
                <a href="<?= APP_URL ?>/admin/kelola-user.php" class="btn btn-secondary">
                    <i class='bx bx-x'></i> Reset
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Tabel User -->
<div class="dashboard-card">
    <div class="card-body">
        <?php if (empty($userList)): ?>
            <div style="text-align: center; padding: 3rem;">
                <i class='bx bx-user' style="font-size: 5rem; color: var(--gray-300);"></i>
                <h3 style="color: var(--gray-600); margin-top: 1rem;">Tidak ada data user</h3>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>User</th>
                            <th>Kontak</th>
                            <th>Pinjaman</th>
                            <th>Denda</th>
                            <th>Status</th>
                            <th>Terdaftar</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($userList as $index => $user): ?>
                            <tr>
                                <td><?= $offset + $index + 1 ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <div style="width: 40px; height: 40px; background: var(--primary-bg); color: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600;">
                                            <?= strtoupper(substr($user['nama_lengkap'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <strong><?= e($user['nama_lengkap']) ?></strong>
                                            <small style="display: block; color: var(--gray-500);">@<?= e($user['username']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <small style="display: block;"><?= e($user['email'] ?? '-') ?></small>
                                    <small style="color: var(--gray-500);"><?= e($user['no_telp'] ?? '-') ?></small>
                                </td>
                                <td>
                                    <?php if ($user['pinjaman_aktif'] > 0): ?>
                                        <span class="badge badge-primary"><?= $user['pinjaman_aktif'] ?> buku</span>
                                    <?php else: ?>
                                        <span style="color: var(--gray-400);">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($user['total_denda'] > 0): ?>
                                        <span style="color: var(--danger); font-weight: 500;"><?= formatRupiah($user['total_denda']) ?></span>
                                    <?php else: ?>
                                        <span style="color: var(--gray-400);">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($user['status'] === 'aktif'): ?>
                                        <span class="badge badge-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= formatTanggal($user['created_at'], 'd M Y') ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <!-- Toggle Status -->
                                        <form method="POST" style="display: inline;">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                            <button type="submit" class="btn-icon <?= $user['status'] === 'aktif' ? 'btn-delete' : 'btn-view' ?>" 
                                                    title="<?= $user['status'] === 'aktif' ? 'Nonaktifkan' : 'Aktifkan' ?>">
                                                <i class='bx <?= $user['status'] === 'aktif' ? 'bx-block' : 'bx-check' ?>'></i>
                                            </button>
                                        </form>
                                        
                                        <!-- Reset Password -->
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Reset password user ini ke default (password123)?')">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="reset_password">
                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                            <button type="submit" class="btn-icon btn-edit" title="Reset Password">
                                                <i class='bx bx-key'></i>
                                            </button>
                                        </form>
                                        
                                        <!-- Delete -->
                                        <form method="POST" style="display: inline;" onsubmit="return confirmDelete('Hapus user ini?')">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                            <button type="submit" class="btn-icon btn-delete" title="Hapus"
                                                    <?= $user['pinjaman_aktif'] > 0 ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : '' ?>>
                                                <i class='bx bx-trash'></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php 
                    $queryParams = $_GET;
                    if ($page > 1): 
                        $queryParams['page'] = $page - 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-left'></i></a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): 
                        $queryParams['page'] = $i;
                    ?>
                        <?php if ($i === $page): ?>
                            <span class="active"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?<?= http_build_query($queryParams) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): 
                        $queryParams['page'] = $page + 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-right'></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>
