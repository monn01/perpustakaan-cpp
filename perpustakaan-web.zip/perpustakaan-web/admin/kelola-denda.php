<?php
/**
 * ============================================================
 * KELOLA DENDA
 * Manajemen denda keterlambatan
 * ============================================================
 */

$pageTitle = 'Kelola Denda';
require_once '../includes/header_admin.php';

$db = db();

// Proses bayar denda
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCsrfToken($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $peminjamanId = intval($_POST['peminjaman_id'] ?? 0);
    
    if ($action === 'bayar' && $peminjamanId) {
        $stmt = $db->prepare("
            UPDATE peminjaman 
            SET denda_dibayar = 1, tanggal_bayar_denda = CURDATE()
            WHERE id = ? AND denda > 0
        ");
        $stmt->execute([$peminjamanId]);
        
        logActivity($_SESSION['user_id'], 'Bayar Denda', "Admin memproses pembayaran denda ID: {$peminjamanId}");
        setFlash('success', 'Pembayaran denda berhasil diproses.');
    } elseif ($action === 'hapus_denda' && $peminjamanId) {
        $stmt = $db->prepare("UPDATE peminjaman SET denda = 0, denda_dibayar = 0 WHERE id = ?");
        $stmt->execute([$peminjamanId]);
        
        logActivity($_SESSION['user_id'], 'Hapus Denda', "Admin menghapus denda ID: {$peminjamanId}");
        setFlash('success', 'Denda berhasil dihapus.');
    }
    
    redirect(APP_URL . '/admin/kelola-denda.php');
}

// Ambil parameter
$status = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build query
$where = ["p.denda > 0"];
$params = [];

if ($status === 'belum') {
    $where[] = "p.denda_dibayar = 0";
} elseif ($status === 'lunas') {
    $where[] = "p.denda_dibayar = 1";
}

$whereClause = 'WHERE ' . implode(' AND ', $where);

// Hitung total
$stmtCount = $db->prepare("SELECT COUNT(*) as total FROM peminjaman p {$whereClause}");
$stmtCount->execute($params);
$totalData = $stmtCount->fetch()['total'];
$totalPages = ceil($totalData / $perPage);

// Ambil data
$stmt = $db->prepare("
    SELECT p.*, u.nama_lengkap, u.username, b.judul
    FROM peminjaman p
    JOIN users u ON p.user_id = u.id
    JOIN buku b ON p.buku_id = b.id
    {$whereClause}
    ORDER BY p.denda_dibayar ASC, p.updated_at DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$stmt->execute($params);
$dendaList = $stmt->fetchAll();

// Statistik
$stmtTotal = $db->query("SELECT SUM(denda) as total FROM peminjaman WHERE denda > 0");
$totalDenda = $stmtTotal->fetch()['total'] ?? 0;

$stmtBelum = $db->query("SELECT SUM(denda) as total, COUNT(*) as jumlah FROM peminjaman WHERE denda > 0 AND denda_dibayar = 0");
$dataBelum = $stmtBelum->fetch();
$totalBelumBayar = $dataBelum['total'] ?? 0;
$jumlahBelumBayar = $dataBelum['jumlah'] ?? 0;

$stmtLunas = $db->query("SELECT SUM(denda) as total, COUNT(*) as jumlah FROM peminjaman WHERE denda > 0 AND denda_dibayar = 1");
$dataLunas = $stmtLunas->fetch();
$totalLunas = $dataLunas['total'] ?? 0;
$jumlahLunas = $dataLunas['jumlah'] ?? 0;
?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns: repeat(4, 1fr); margin-bottom: 1.5rem;">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bx-money'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah($totalDenda) ?></h3>
            <p>Total Semua Denda</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red">
            <i class='bx bx-x-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah($totalBelumBayar) ?></h3>
            <p><?= $jumlahBelumBayar ?> Belum Bayar</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-check-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah($totalLunas) ?></h3>
            <p><?= $jumlahLunas ?> Sudah Lunas</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class='bx bx-info-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah(getSetting('denda_per_hari', 3000)) ?></h3>
            <p>Denda per Hari</p>
        </div>
    </div>
</div>

<!-- Filter -->
<div class="dashboard-card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 0.75rem 1rem;">
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <a href="?status=" class="btn <?= empty($status) ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
                Semua (<?= $totalData ?>)
            </a>
            <a href="?status=belum" class="btn <?= $status === 'belum' ? 'btn-danger' : 'btn-secondary' ?> btn-sm">
                <i class='bx bx-x-circle'></i> Belum Bayar (<?= $jumlahBelumBayar ?>)
            </a>
            <a href="?status=lunas" class="btn <?= $status === 'lunas' ? 'btn-success' : 'btn-secondary' ?> btn-sm">
                <i class='bx bx-check-circle'></i> Lunas (<?= $jumlahLunas ?>)
            </a>
        </div>
    </div>
</div>

<!-- Tabel Denda -->
<div class="dashboard-card">
    <div class="card-header">
        <h2><i class='bx bx-money'></i> Daftar Denda</h2>
    </div>
    <div class="card-body">
        <?php if (empty($dendaList)): ?>
            <div style="text-align: center; padding: 3rem;">
                <i class='bx bx-happy-alt' style="font-size: 5rem; color: var(--gray-300);"></i>
                <h3 style="color: var(--gray-600); margin-top: 1rem;">Tidak ada data denda</h3>
                <p style="color: var(--gray-500);">Semua anggota mengembalikan buku tepat waktu!</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>Anggota</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Tgl Kembali</th>
                            <th>Denda</th>
                            <th>Status</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dendaList as $index => $d): ?>
                            <tr>
                                <td><?= $offset + $index + 1 ?></td>
                                <td>
                                    <strong><?= e($d['nama_lengkap']) ?></strong>
                                    <small style="display: block; color: var(--gray-500);">@<?= e($d['username']) ?></small>
                                </td>
                                <td><?= e(substr($d['judul'], 0, 30)) ?><?= strlen($d['judul']) > 30 ? '...' : '' ?></td>
                                <td><?= formatTanggal($d['tanggal_pinjam']) ?></td>
                                <td><?= $d['tanggal_kembali'] ? formatTanggal($d['tanggal_kembali']) : '-' ?></td>
                                <td>
                                    <strong style="color: var(--danger);"><?= formatRupiah($d['denda']) ?></strong>
                                </td>
                                <td>
                                    <?php if ($d['denda_dibayar']): ?>
                                        <span class="badge badge-success">
                                            <i class='bx bx-check'></i> Lunas
                                        </span>
                                        <small style="display: block; color: var(--gray-500);">
                                            <?= formatTanggal($d['tanggal_bayar_denda']) ?>
                                        </small>
                                    <?php else: ?>
                                        <span class="badge badge-danger">
                                            <i class='bx bx-x'></i> Belum Bayar
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!$d['denda_dibayar']): ?>
                                        <div class="action-buttons">
                                            <!-- Bayar -->
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Konfirmasi pembayaran denda <?= formatRupiah($d['denda']) ?>?')">
                                                <?= csrfField() ?>
                                                <input type="hidden" name="action" value="bayar">
                                                <input type="hidden" name="peminjaman_id" value="<?= $d['id'] ?>">
                                                <button type="submit" class="btn-icon btn-view" title="Tandai Lunas">
                                                    <i class='bx bx-check'></i>
                                                </button>
                                            </form>
                                            
                                            <!-- Hapus Denda -->
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Hapus denda ini? (Tindakan tidak dapat dibatalkan)')">
                                                <?= csrfField() ?>
                                                <input type="hidden" name="action" value="hapus_denda">
                                                <input type="hidden" name="peminjaman_id" value="<?= $d['id'] ?>">
                                                <button type="submit" class="btn-icon btn-delete" title="Hapus Denda">
                                                    <i class='bx bx-trash'></i>
                                                </button>
                                            </form>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: var(--gray-400);">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php 
                    $queryParams = $_GET;
                    if ($page > 1): 
                        $queryParams['page'] = $page - 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-left'></i></a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): 
                        $queryParams['page'] = $i;
                    ?>
                        <?php if ($i === $page): ?>
                            <span class="active"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?<?= http_build_query($queryParams) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): 
                        $queryParams['page'] = $page + 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-right'></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>
