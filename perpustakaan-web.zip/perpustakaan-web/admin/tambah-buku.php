<?php
/**
 * ============================================================
 * TAMBAH BUKU
 * Form untuk menambah buku baru
 * ============================================================
 */

$pageTitle = 'Tambah Buku';
require_once '../includes/header_admin.php';

$db = db();

// Ambil semua kategori
$stmtKat = $db->query("SELECT * FROM kategori ORDER BY nama_kategori");
$kategoriList = $stmtKat->fetchAll();

$error = '';
$formData = [];

// Proses tambah buku
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Token tidak valid.';
    } else {
        $formData = [
            'isbn' => trim($_POST['isbn'] ?? ''),
            'judul' => trim($_POST['judul'] ?? ''),
            'penulis' => trim($_POST['penulis'] ?? ''),
            'penerbit' => trim($_POST['penerbit'] ?? ''),
            'tahun_terbit' => intval($_POST['tahun_terbit'] ?? 0),
            'kategori_id' => intval($_POST['kategori_id'] ?? 0),
            'deskripsi' => trim($_POST['deskripsi'] ?? ''),
            'stok' => intval($_POST['stok'] ?? 0),
            'lokasi_rak' => trim($_POST['lokasi_rak'] ?? '')
        ];
        
        // Validasi
        if (empty($formData['judul'])) {
            $error = 'Judul buku harus diisi.';
        } elseif (empty($formData['penulis'])) {
            $error = 'Penulis harus diisi.';
        } elseif ($formData['stok'] < 0) {
            $error = 'Stok tidak boleh negatif.';
        } else {
            // Cek ISBN unik jika diisi
            if (!empty($formData['isbn'])) {
                $stmt = $db->prepare("SELECT id FROM buku WHERE isbn = ?");
                $stmt->execute([$formData['isbn']]);
                if ($stmt->fetch()) {
                    $error = 'ISBN sudah digunakan.';
                }
            }
            
            if (empty($error)) {
                $stmt = $db->prepare("
                    INSERT INTO buku (isbn, judul, penulis, penerbit, tahun_terbit, kategori_id, deskripsi, stok, stok_tersedia, lokasi_rak)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $formData['isbn'] ?: null,
                    $formData['judul'],
                    $formData['penulis'],
                    $formData['penerbit'] ?: null,
                    $formData['tahun_terbit'] ?: null,
                    $formData['kategori_id'] ?: null,
                    $formData['deskripsi'] ?: null,
                    $formData['stok'],
                    $formData['stok'], // stok_tersedia = stok awal
                    $formData['lokasi_rak'] ?: null
                ]);
                
                logActivity($_SESSION['user_id'], 'Tambah Buku', "Menambah buku: {$formData['judul']}");
                setFlash('success', 'Buku berhasil ditambahkan.');
                redirect(APP_URL . '/admin/kelola-buku.php');
            }
        }
    }
}
?>

<!-- Breadcrumb -->
<div class="breadcrumb" style="margin-bottom: 1.5rem;">
    <a href="<?= APP_URL ?>/admin/dashboard.php">Dashboard</a>
    <span class="separator" style="margin: 0 0.5rem; color: var(--gray-400);">/</span>
    <a href="<?= APP_URL ?>/admin/kelola-buku.php">Kelola Buku</a>
    <span class="separator" style="margin: 0 0.5rem; color: var(--gray-400);">/</span>
    <span style="color: var(--gray-700);">Tambah Buku</span>
</div>

<div class="dashboard-card">
    <div class="card-header">
        <h2><i class='bx bx-plus-circle'></i> Tambah Buku Baru</h2>
    </div>
    <div class="card-body">
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class='bx bx-x-circle'></i> <?= e($error) ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <?= csrfField() ?>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                <!-- Kolom Kiri -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Judul Buku <span style="color: var(--danger);">*</span></label>
                        <input type="text" name="judul" class="form-control" 
                               value="<?= e($formData['judul'] ?? '') ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Penulis <span style="color: var(--danger);">*</span></label>
                        <input type="text" name="penulis" class="form-control" 
                               value="<?= e($formData['penulis'] ?? '') ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Penerbit</label>
                        <input type="text" name="penerbit" class="form-control" 
                               value="<?= e($formData['penerbit'] ?? '') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">ISBN</label>
                        <input type="text" name="isbn" class="form-control" 
                               value="<?= e($formData['isbn'] ?? '') ?>"
                               placeholder="978-xxx-xxxx-xx">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="4"
                                  placeholder="Sinopsis atau deskripsi buku..."><?= e($formData['deskripsi'] ?? '') ?></textarea>
                    </div>
                </div>
                
                <!-- Kolom Kanan -->
                <div>
                    <div class="form-group">
                        <label class="form-label">Kategori</label>
                        <select name="kategori_id" class="form-control">
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($kategoriList as $kat): ?>
                                <option value="<?= $kat['id'] ?>" <?= ($formData['kategori_id'] ?? '') == $kat['id'] ? 'selected' : '' ?>>
                                    <?= e($kat['nama_kategori']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Tahun Terbit</label>
                        <input type="number" name="tahun_terbit" class="form-control" 
                               value="<?= e($formData['tahun_terbit'] ?? '') ?>"
                               min="1900" max="<?= date('Y') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Jumlah Stok <span style="color: var(--danger);">*</span></label>
                        <input type="number" name="stok" class="form-control" 
                               value="<?= e($formData['stok'] ?? '1') ?>"
                               min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Lokasi Rak</label>
                        <input type="text" name="lokasi_rak" class="form-control" 
                               value="<?= e($formData['lokasi_rak'] ?? '') ?>"
                               placeholder="Contoh: A-01">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Cover Buku</label>
                        <div style="padding: 2rem; border: 2px dashed var(--gray-300); border-radius: var(--radius); text-align: center; color: var(--gray-500);">
                            <i class='bx bx-image' style="font-size: 2rem;"></i>
                            <p style="margin: 0.5rem 0 0;">Fitur upload akan tersedia</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--gray-200); display: flex; gap: 1rem;">
                <button type="submit" class="btn btn-primary">
                    <i class='bx bx-save'></i> Simpan Buku
                </button>
                <a href="<?= APP_URL ?>/admin/kelola-buku.php" class="btn btn-secondary">
                    <i class='bx bx-x'></i> Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>
