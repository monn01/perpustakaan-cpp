<?php
/**
 * ============================================================
 * ADMIN DASHBOARD
 * Halaman utama admin dengan statistik dan overview
 * ============================================================
 */

$pageTitle = 'Dashboard Admin';
require_once '../includes/header_admin.php';

$db = db();

// Statistik utama
$totalBuku = getTotalBuku();
$totalUser = getTotalUser();
$totalPeminjamanAktif = getTotalPeminjamanAktif();
$totalDendaBelumBayar = getTotalDendaBelumBayar();

// Total peminjaman bulan ini
$stmt = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE MONTH(tanggal_pinjam) = MONTH(CURDATE()) AND YEAR(tanggal_pinjam) = YEAR(CURDATE())");
$peminjamanBulanIni = $stmt->fetch()['total'];

// Peminjaman terlambat
$stmt = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE status = 'dipinjam' AND tanggal_harus_kembali < CURDATE()");
$terlambat = $stmt->fetch()['total'];

// Peminjaman terbaru
$stmt = $db->query("
    SELECT p.*, u.nama_lengkap, u.username, b.judul,
           DATEDIFF(p.tanggal_harus_kembali, CURDATE()) as sisa_hari
    FROM peminjaman p
    JOIN users u ON p.user_id = u.id
    JOIN buku b ON p.buku_id = b.id
    ORDER BY p.created_at DESC
    LIMIT 5
");
$peminjamanTerbaru = $stmt->fetchAll();

// User terbaru
$stmt = $db->query("
    SELECT * FROM users 
    WHERE role = 'user' 
    ORDER BY created_at DESC 
    LIMIT 5
");
$userTerbaru = $stmt->fetchAll();

// Buku terpopuler
$stmt = $db->query("
    SELECT b.*, k.nama_kategori, COUNT(p.id) as total_pinjam
    FROM buku b
    LEFT JOIN kategori k ON b.kategori_id = k.id
    LEFT JOIN peminjaman p ON b.id = p.buku_id
    GROUP BY b.id
    ORDER BY total_pinjam DESC
    LIMIT 5
");
$bukuPopuler = $stmt->fetchAll();

// Aktivitas terbaru
$aktivitasTerbaru = getRecentActivities(8);

// Statistik per kategori
$stmt = $db->query("
    SELECT k.nama_kategori, COUNT(b.id) as total_buku
    FROM kategori k
    LEFT JOIN buku b ON k.id = b.kategori_id
    GROUP BY k.id
    ORDER BY total_buku DESC
    LIMIT 5
");
$kategoriStats = $stmt->fetchAll();
?>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bxs-book'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalBuku ?></h3>
            <p>Total Buku</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon purple">
            <i class='bx bxs-user-detail'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalUser ?></h3>
            <p>Total Anggota</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-transfer-alt'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalPeminjamanAktif ?></h3>
            <p>Peminjaman Aktif</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class='bx bx-calendar'></i>
        </div>
        <div class="stat-info">
            <h3><?= $peminjamanBulanIni ?></h3>
            <p>Pinjam Bulan Ini</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon <?= $terlambat > 0 ? 'red' : 'green' ?>">
            <i class='bx bx-time-five'></i>
        </div>
        <div class="stat-info">
            <h3><?= $terlambat ?></h3>
            <p>Terlambat</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon <?= $totalDendaBelumBayar > 0 ? 'red' : 'green' ?>">
            <i class='bx bx-money'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah($totalDendaBelumBayar) ?></h3>
            <p>Denda Belum Bayar</p>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <!-- Peminjaman Terbaru -->
    <div class="dashboard-card">
        <div class="card-header">
            <h2><i class='bx bx-transfer-alt'></i> Peminjaman Terbaru</h2>
            <a href="<?= APP_URL ?>/admin/kelola-peminjaman.php" class="btn btn-sm btn-secondary">Lihat Semua</a>
        </div>
        <div class="card-body">
            <?php if (empty($peminjamanTerbaru)): ?>
                <p style="text-align: center; color: var(--gray-500); padding: 2rem;">
                    Belum ada data peminjaman
                </p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Buku</th>
                                <th>Tgl Pinjam</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($peminjamanTerbaru as $p): ?>
                                <tr>
                                    <td>
                                        <strong><?= e($p['nama_lengkap']) ?></strong>
                                        <small style="display: block; color: var(--gray-500);">@<?= e($p['username']) ?></small>
                                    </td>
                                    <td><?= e(substr($p['judul'], 0, 30)) ?><?= strlen($p['judul']) > 30 ? '...' : '' ?></td>
                                    <td><?= formatTanggal($p['tanggal_pinjam']) ?></td>
                                    <td>
                                        <?php if ($p['status'] === 'dikembalikan'): ?>
                                            <span class="badge badge-success">Dikembalikan</span>
                                        <?php elseif ($p['sisa_hari'] < 0): ?>
                                            <span class="badge badge-danger">Terlambat</span>
                                        <?php elseif ($p['sisa_hari'] <= 2): ?>
                                            <span class="badge badge-warning">Segera JT</span>
                                        <?php else: ?>
                                            <span class="badge badge-primary">Dipinjam</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Sidebar Info -->
    <div>
        <!-- Quick Actions -->
        <div class="dashboard-card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <h2><i class='bx bx-zap'></i> Aksi Cepat</h2>
            </div>
            <div class="card-body">
                <a href="<?= APP_URL ?>/admin/tambah-buku.php" class="btn btn-primary" style="width: 100%; margin-bottom: 0.75rem;">
                    <i class='bx bx-plus'></i> Tambah Buku Baru
                </a>
                <a href="<?= APP_URL ?>/admin/kelola-user.php" class="btn btn-secondary" style="width: 100%; margin-bottom: 0.75rem;">
                    <i class='bx bx-user-plus'></i> Kelola User
                </a>
                <a href="<?= APP_URL ?>/admin/laporan.php" class="btn btn-secondary" style="width: 100%;">
                    <i class='bx bx-file'></i> Lihat Laporan
                </a>
            </div>
        </div>
        
        <!-- Buku Terpopuler -->
        <div class="dashboard-card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <h2><i class='bx bx-trending-up'></i> Buku Terpopuler</h2>
            </div>
            <div class="card-body">
                <?php foreach ($bukuPopuler as $index => $buku): ?>
                    <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 0; <?= $index < count($bukuPopuler) - 1 ? 'border-bottom: 1px solid var(--gray-100);' : '' ?>">
                        <span style="width: 24px; height: 24px; background: var(--primary-bg); color: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 600;">
                            <?= $index + 1 ?>
                        </span>
                        <div style="flex: 1; min-width: 0;">
                            <p style="font-weight: 500; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                <?= e($buku['judul']) ?>
                            </p>
                            <small style="color: var(--gray-500);"><?= $buku['total_pinjam'] ?> kali dipinjam</small>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- User Terbaru -->
        <div class="dashboard-card">
            <div class="card-header">
                <h2><i class='bx bx-user-plus'></i> Anggota Baru</h2>
            </div>
            <div class="card-body">
                <?php foreach ($userTerbaru as $user): ?>
                    <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 0; border-bottom: 1px solid var(--gray-100);">
                        <div style="width: 35px; height: 35px; background: var(--primary-bg); color: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600;">
                            <?= strtoupper(substr($user['nama_lengkap'], 0, 1)) ?>
                        </div>
                        <div style="flex: 1;">
                            <p style="font-weight: 500; margin: 0; font-size: 0.9rem;"><?= e($user['nama_lengkap']) ?></p>
                            <small style="color: var(--gray-500);"><?= formatTanggal($user['created_at'], 'd M Y') ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Aktivitas Terbaru -->
<div class="dashboard-card" style="margin-top: 1.5rem;">
    <div class="card-header">
        <h2><i class='bx bx-history'></i> Aktivitas Terbaru</h2>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Aktivitas</th>
                        <th>Detail</th>
                        <th>Waktu</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($aktivitasTerbaru as $a): ?>
                        <tr>
                            <td>
                                <strong><?= e($a['nama_lengkap'] ?? 'System') ?></strong>
                            </td>
                            <td>
                                <span class="badge badge-primary"><?= e($a['aktivitas']) ?></span>
                            </td>
                            <td><?= e($a['detail'] ?? '-') ?></td>
                            <td><?= formatTanggal($a['created_at'], 'd M Y H:i') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>
