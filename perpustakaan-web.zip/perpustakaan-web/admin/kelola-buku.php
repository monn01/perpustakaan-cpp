<?php
/**
 * ============================================================
 * KELOLA BUKU
 * Manajemen data buku (CRUD)
 * ============================================================
 */

$pageTitle = 'Kelola Buku';
require_once '../includes/header_admin.php';

$db = db();

// Proses hapus buku
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $bukuId = intval($_POST['buku_id'] ?? 0);
        
        // Cek apakah buku sedang dipinjam
        $stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE buku_id = ? AND status = 'dipinjam'");
        $stmt->execute([$bukuId]);
        $sedangDipinjam = $stmt->fetch()['total'];
        
        if ($sedangDipinjam > 0) {
            setFlash('error', 'Buku tidak dapat dihapus karena sedang dipinjam.');
        } else {
            $stmt = $db->prepare("DELETE FROM buku WHERE id = ?");
            $stmt->execute([$bukuId]);
            
            logActivity($_SESSION['user_id'], 'Hapus Buku', "Menghapus buku ID: {$bukuId}");
            setFlash('success', 'Buku berhasil dihapus.');
        }
    }
    redirect(APP_URL . '/admin/kelola-buku.php');
}

// Ambil parameter
$search = trim($_GET['search'] ?? '');
$kategoriId = $_GET['kategori'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Ambil semua kategori
$stmtKat = $db->query("SELECT * FROM kategori ORDER BY nama_kategori");
$kategoriList = $stmtKat->fetchAll();

// Build query
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(b.judul LIKE ? OR b.penulis LIKE ? OR b.isbn LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($kategoriId)) {
    $where[] = "b.kategori_id = ?";
    $params[] = $kategoriId;
}

$whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Hitung total
$stmtCount = $db->prepare("SELECT COUNT(*) as total FROM buku b {$whereClause}");
$stmtCount->execute($params);
$totalData = $stmtCount->fetch()['total'];
$totalPages = ceil($totalData / $perPage);

// Ambil data buku
$stmt = $db->prepare("
    SELECT b.*, k.nama_kategori,
           (SELECT COUNT(*) FROM peminjaman WHERE buku_id = b.id AND status = 'dipinjam') as sedang_dipinjam
    FROM buku b
    LEFT JOIN kategori k ON b.kategori_id = k.id
    {$whereClause}
    ORDER BY b.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$stmt->execute($params);
$bukuList = $stmt->fetchAll();
?>

<!-- Header Actions -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <p style="color: var(--gray-600); margin: 0;">
            Total: <strong><?= $totalData ?></strong> buku
        </p>
    </div>
    <a href="<?= APP_URL ?>/admin/tambah-buku.php" class="btn btn-primary">
        <i class='bx bx-plus'></i> Tambah Buku Baru
    </a>
</div>

<!-- Filter & Search -->
<div class="dashboard-card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET" action="" style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 250px;">
                <input type="text" name="search" class="form-control" 
                       placeholder="Cari judul, penulis, atau ISBN..."
                       value="<?= e($search) ?>">
            </div>
            <div style="min-width: 180px;">
                <select name="kategori" class="form-control">
                    <option value="">Semua Kategori</option>
                    <?php foreach ($kategoriList as $kat): ?>
                        <option value="<?= $kat['id'] ?>" <?= $kategoriId == $kat['id'] ? 'selected' : '' ?>>
                            <?= e($kat['nama_kategori']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class='bx bx-search'></i> Cari
            </button>
            <?php if (!empty($search) || !empty($kategoriId)): ?>
                <a href="<?= APP_URL ?>/admin/kelola-buku.php" class="btn btn-secondary">
                    <i class='bx bx-x'></i> Reset
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Tabel Buku -->
<div class="dashboard-card">
    <div class="card-body">
        <?php if (empty($bukuList)): ?>
            <div style="text-align: center; padding: 3rem;">
                <i class='bx bx-book' style="font-size: 5rem; color: var(--gray-300);"></i>
                <h3 style="color: var(--gray-600); margin-top: 1rem;">Tidak ada data buku</h3>
                <p style="color: var(--gray-500);">Belum ada buku yang ditambahkan atau tidak ada hasil pencarian</p>
                <a href="<?= APP_URL ?>/admin/tambah-buku.php" class="btn btn-primary" style="margin-top: 1rem;">
                    <i class='bx bx-plus'></i> Tambah Buku Baru
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>Buku</th>
                            <th>Kategori</th>
                            <th>ISBN</th>
                            <th>Tahun</th>
                            <th>Stok</th>
                            <th>Tersedia</th>
                            <th width="120">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bukuList as $index => $buku): ?>
                            <tr>
                                <td><?= $offset + $index + 1 ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=50&h=70&fit=crop" 
                                             alt="<?= e($buku['judul']) ?>"
                                             style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px;">
                                        <div>
                                            <strong style="display: block;"><?= e($buku['judul']) ?></strong>
                                            <small style="color: var(--gray-500);"><?= e($buku['penulis']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-primary"><?= e($buku['nama_kategori'] ?? 'Umum') ?></span>
                                </td>
                                <td><?= e($buku['isbn'] ?? '-') ?></td>
                                <td><?= $buku['tahun_terbit'] ?? '-' ?></td>
                                <td><?= $buku['stok'] ?></td>
                                <td>
                                    <?php if ($buku['stok_tersedia'] > 0): ?>
                                        <span class="badge badge-success"><?= $buku['stok_tersedia'] ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">0</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?= APP_URL ?>/admin/edit-buku.php?id=<?= $buku['id'] ?>" 
                                           class="btn-icon btn-edit" title="Edit">
                                            <i class='bx bx-edit'></i>
                                        </a>
                                        <form method="POST" action="" style="display: inline;" 
                                              onsubmit="return confirmDelete('Hapus buku ini?')">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="buku_id" value="<?= $buku['id'] ?>">
                                            <button type="submit" class="btn-icon btn-delete" title="Hapus"
                                                    <?= $buku['sedang_dipinjam'] > 0 ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : '' ?>>
                                                <i class='bx bx-trash'></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php 
                    $queryParams = $_GET;
                    
                    if ($page > 1): 
                        $queryParams['page'] = $page - 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-left'></i></a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): 
                        $queryParams['page'] = $i;
                    ?>
                        <?php if ($i === $page): ?>
                            <span class="active"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?<?= http_build_query($queryParams) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): 
                        $queryParams['page'] = $page + 1;
                    ?>
                        <a href="?<?= http_build_query($queryParams) ?>"><i class='bx bx-chevron-right'></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer_admin.php'; ?>
