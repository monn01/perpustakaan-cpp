<?php
/**
 * ============================================================
 * LOGOUT.PHP
 * Proses logout user
 * ============================================================
 */

require_once '../includes/functions.php';

// Proses logout
logoutUser();

// Set flash message
setFlash('success', 'Anda telah berhasil logout. Sampai jumpa!');

// Redirect ke halaman login
redirect(APP_URL . '/auth/login.php');
?>
