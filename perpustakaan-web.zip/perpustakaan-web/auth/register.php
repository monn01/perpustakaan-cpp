<?php
/**
 * ============================================================
 * REGISTER.PHP
 * Halaman registrasi user baru
 * ============================================================
 */

$pageTitle = 'Daftar';
require_once '../includes/functions.php';

// Redirect jika sudah login
requireGuest();

// Proses registrasi
$error = '';
$success = '';
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi CSRF
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Token tidak valid. Silakan refresh halaman.';
    } else {
        // Ambil data form
        $formData = [
            'username' => trim($_POST['username'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'confirm_password' => $_POST['confirm_password'] ?? '',
            'nama_lengkap' => trim($_POST['nama_lengkap'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'no_telp' => trim($_POST['no_telp'] ?? ''),
            'alamat' => trim($_POST['alamat'] ?? '')
        ];
        
        // Validasi
        if (empty($formData['username'])) {
            $error = 'Username harus diisi.';
        } elseif (!isValidUsername($formData['username'])) {
            $error = 'Username hanya boleh huruf, angka, dan underscore (4-20 karakter).';
        } elseif (empty($formData['password'])) {
            $error = 'Password harus diisi.';
        } elseif (strlen($formData['password']) < 6) {
            $error = 'Password minimal 6 karakter.';
        } elseif ($formData['password'] !== $formData['confirm_password']) {
            $error = 'Konfirmasi password tidak cocok.';
        } elseif (empty($formData['nama_lengkap'])) {
            $error = 'Nama lengkap harus diisi.';
        } elseif (!empty($formData['email']) && !isValidEmail($formData['email'])) {
            $error = 'Format email tidak valid.';
        } else {
            // Proses registrasi
            $result = registerUser($formData);
            
            if ($result['success']) {
                setFlash('success', $result['message']);
                redirect(APP_URL . '/auth/login.php');
                exit;
            } else {
                $error = $result['message'];
            }
        }
    }
}
?>

<?php require_once '../includes/header.php'; ?>

<div class="auth-wrapper">
    <a href="<?= APP_URL ?>" class="back-home">
        <i class='bx bx-arrow-back'></i> Kembali ke Beranda
    </a>
    
    <div class="auth-container">
        <!-- Left Side - Illustration -->
        <div class="auth-image">
            <svg class="illustration" viewBox="0 0 300 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                <!-- Person with Card -->
                <circle cx="150" cy="70" r="35" fill="#FFD6A5"/>
                <rect x="115" y="105" width="70" height="95" rx="15" fill="#FFF"/>
                <!-- ID Card -->
                <rect x="90" y="140" width="120" height="80" rx="8" fill="rgba(255,255,255,0.9)"/>
                <rect x="100" y="150" width="35" height="35" rx="5" fill="#0EA5E9"/>
                <rect x="145" y="155" width="55" height="6" fill="#374151"/>
                <rect x="145" y="168" width="45" height="4" fill="#9CA3AF"/>
                <rect x="100" y="195" width="100" height="4" fill="#E5E7EB"/>
                <rect x="100" y="205" width="80" height="4" fill="#E5E7EB"/>
                <!-- Checkmark -->
                <circle cx="240" cy="100" r="25" fill="#10B981"/>
                <path d="M228 100L236 108L252 92" stroke="#FFF" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                <!-- Decorations -->
                <circle cx="60" cy="60" r="3" fill="#FFF" opacity="0.6"/>
                <circle cx="250" cy="180" r="3" fill="#FFF" opacity="0.6"/>
                <rect x="50" y="160" width="25" height="35" rx="3" fill="#FFF" opacity="0.5"/>
            </svg>
            
            <h2>Bergabung Sekarang!</h2>
            <p>Daftarkan diri Anda dan nikmati akses ke ribuan koleksi buku kami. Gratis dan mudah!</p>
            
            <div style="margin-top: 2rem;">
                <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                    <i class='bx bx-check-circle' style="font-size: 1.25rem;"></i>
                    <span style="font-size: 0.9rem;">Akses katalog lengkap</span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                    <i class='bx bx-check-circle' style="font-size: 1.25rem;"></i>
                    <span style="font-size: 0.9rem;">Pinjam hingga 3 buku</span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i class='bx bx-check-circle' style="font-size: 1.25rem;"></i>
                    <span style="font-size: 0.9rem;">Reservasi buku favorit</span>
                </div>
            </div>
        </div>
        
        <!-- Right Side - Register Form -->
        <div class="auth-form-container" style="overflow-y: auto; max-height: 90vh; padding-top: 2rem;">
            <h1>Daftar Akun</h1>
            <p class="subtitle">Isi formulir di bawah untuk membuat akun baru</p>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class='bx bx-x-circle'></i> <?= e($error) ?>
                </div>
            <?php endif; ?>
            
            <form class="auth-form" method="POST" action="" id="registerForm">
                <?= csrfField() ?>
                
                <!-- USERNAME - FIELD PERTAMA DAN WAJIB -->
                <div class="form-group">
                    <label class="form-label">Username <span style="color: var(--danger);">*</span></label>
                    <div class="input-icon">
                        <i class='bx bx-user'></i>
                        <input type="text" name="username" id="username" class="form-control" 
                               placeholder="Contoh: johndoe" 
                               value="<?= e($formData['username'] ?? '') ?>" 
                               required autofocus>
                    </div>
                    <small style="color: var(--gray-500); font-size: 0.8rem;">
                        4-20 karakter, hanya huruf, angka, dan underscore
                    </small>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nama Lengkap <span style="color: var(--danger);">*</span></label>
                    <div class="input-icon">
                        <i class='bx bx-id-card'></i>
                        <input type="text" name="nama_lengkap" class="form-control" 
                               placeholder="Contoh: John Doe" 
                               value="<?= e($formData['nama_lengkap'] ?? '') ?>" 
                               required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <div class="input-icon">
                        <i class='bx bx-envelope'></i>
                        <input type="email" name="email" class="form-control" 
                               placeholder="Contoh: johndoe@email.com" 
                               value="<?= e($formData['email'] ?? '') ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">No. Telepon</label>
                    <div class="input-icon">
                        <i class='bx bx-phone'></i>
                        <input type="tel" name="no_telp" class="form-control" 
                               placeholder="Contoh: 081234567890" 
                               value="<?= e($formData['no_telp'] ?? '') ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Alamat</label>
                    <div class="input-icon">
                        <i class='bx bx-map' style="top: 1rem; transform: none;"></i>
                        <textarea name="alamat" class="form-control" 
                                  placeholder="Alamat lengkap (opsional)" 
                                  style="padding-left: 2.75rem; min-height: 70px; resize: vertical;"><?= e($formData['alamat'] ?? '') ?></textarea>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password <span style="color: var(--danger);">*</span></label>
                    <div class="input-icon">
                        <i class='bx bx-lock-alt'></i>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Minimal 6 karakter" required>
                        <button type="button" class="password-toggle">
                            <i class='bx bx-hide'></i>
                        </button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Konfirmasi Password <span style="color: var(--danger);">*</span></label>
                    <div class="input-icon">
                        <i class='bx bx-lock'></i>
                        <input type="password" name="confirm_password" class="form-control" 
                               placeholder="Ulangi password" required>
                        <button type="button" class="password-toggle">
                            <i class='bx bx-hide'></i>
                        </button>
                    </div>
                </div>
                
                <div style="margin-bottom: 1.5rem;">
                    <label style="display: flex; align-items: flex-start; gap: 0.5rem; cursor: pointer; font-size: 0.875rem; color: var(--gray-600);">
                        <input type="checkbox" name="agree" required style="margin-top: 3px;">
                        <span>Saya menyetujui <a href="#" style="color: var(--primary);">Syarat & Ketentuan</a> dan <a href="#" style="color: var(--primary);">Kebijakan Privasi</a></span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class='bx bx-user-plus'></i> Daftar Sekarang
                </button>
                
                <p class="auth-link">
                    Sudah punya akun? <a href="login.php">Masuk di sini</a>
                </p>
            </form>
        </div>
    </div>
</div>

<script>
// Scroll form container ke atas saat halaman dimuat
document.addEventListener('DOMContentLoaded', function() {
    const formContainer = document.querySelector('.auth-form-container');
    if (formContainer) {
        formContainer.scrollTop = 0;
    }
    
    // Focus ke field username
    const usernameField = document.getElementById('username');
    if (usernameField) {
        usernameField.focus();
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>