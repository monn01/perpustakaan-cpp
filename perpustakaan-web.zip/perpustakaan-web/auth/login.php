<?php
/**
 * ============================================================
 * LOGIN.PHP
 * Halaman login untuk user dan admin
 * ============================================================
 */
$pageTitle = 'Login';

// WAJIB: fungsi & session
require_once '../includes/functions.php';

// Redirect jika sudah login
requireGuest();

// Proses login
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Token tidak valid. Silakan refresh halaman.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($password)) {
            $error = 'Username dan password harus diisi.';
        } else {
            if (loginUser($username, $password)) {
                setFlash('success', 'Selamat datang kembali, ' . $_SESSION['nama_lengkap'] . '!');

                if (isAdmin()) {
                    redirect(APP_URL . '/admin/dashboard.php');
                } else {
                    redirect(APP_URL . '/user/dashboard.php');
                }
            } else {
                $error = 'Username atau password salah.';
            }
        }
    }
}
?>


<!-- BARU DI SINI HEADER HTML -->
<?php require_once '../includes/header.php'; ?>


<div class="auth-wrapper">
    <a href="<?= APP_URL ?>" class="back-home">
        <i class='bx bx-arrow-back'></i> Kembali ke Beranda
    </a>
    
    <div class="auth-container">
        <!-- Left Side - Illustration -->
        <div class="auth-image">
            <svg class="illustration" viewBox="0 0 300 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                <!-- Person Reading -->
                <circle cx="150" cy="80" r="35" fill="#FFD6A5"/>
                <rect x="115" y="115" width="70" height="90" rx="15" fill="#FFF"/>
                <rect x="100" y="130" width="100" height="70" rx="5" fill="rgba(255,255,255,0.3)"/>
                <!-- Book -->
                <rect x="105" y="140" width="90" height="50" rx="3" fill="#FFF"/>
                <rect x="115" y="150" width="30" height="4" fill="#33b3eeff"/>
                <rect x="115" y="160" width="70" height="3" fill="#E5E7EB"/>
                <rect x="115" y="168" width="60" height="3" fill="#E5E7EB"/>
                <rect x="115" y="176" width="50" height="3" fill="#E5E7EB"/>
                <!-- Floating Books -->
                <rect x="40" y="60" width="40" height="55" rx="3" fill="#FFF" opacity="0.8"/>
                <rect x="45" y="65" width="30" height="5" fill="#F97316"/>
                <rect x="220" y="100" width="35" height="50" rx="3" fill="#FFF" opacity="0.8"/>
                <rect x="225" y="105" width="25" height="5" fill="#10B981"/>
                <!-- Stars -->
                <circle cx="70" cy="40" r="3" fill="#FFF" opacity="0.6"/>
                <circle cx="240" cy="60" r="3" fill="#FFF" opacity="0.6"/>
                <circle cx="260" cy="180" r="2" fill="#FFF" opacity="0.6"/>
            </svg>
            
            <h2>Selamat Datang Kembali!</h2>
            <p>Masuk ke akun Anda untuk mengakses ribuan buku dan melanjutkan perjalanan membaca Anda.</p>
            
            <div style="margin-top: 2rem; padding: 1rem; background: rgba(255,255,255,0.1); border-radius: 10px;">
                <p style="font-size: 0.85rem; opacity: 0.9; margin: 0;">
                    <i class='bx bx-info-circle'></i> Demo Account:<br>
                    <strong>Admin:</strong> admin / admin123<br>
                    <strong>User:</strong> budi / admin123
                </p>
            </div>
        </div>
        
        <!-- Right Side - Login Form -->
        <div class="auth-form-container">
            <h1>Login</h1>
            <p class="subtitle">Masukkan username dan password Anda</p>
            
            <?php displayFlash(); ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class='bx bx-x-circle'></i> <?= e($error) ?>
                </div>
            <?php endif; ?>
            
            <form class="auth-form" method="POST" action="">
                <?= csrfField() ?>
                
                <div class="form-group">
                    <label class="form-label">Username</label>
                    <div class="input-icon">
                        <i class='bx bx-user'></i>
                        <input type="text" name="username" class="form-control" 
                               placeholder="Masukkan username" 
                               value="<?= e($_POST['username'] ?? '') ?>" 
                               required autofocus>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <div class="input-icon">
                        <i class='bx bx-lock-alt'></i>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Masukkan password" required>
                        <button type="button" class="password-toggle">
                            <i class='bx bx-hide'></i>
                        </button>
                    </div>
                </div>
                
                <div class="remember-me">
                    <label>
                        <input type="checkbox" name="remember"> Ingat saya
                    </label>
                    <a href="#">Lupa password?</a>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class='bx bx-log-in'></i> Masuk
                </button>
                
                <p class="auth-link">
                    Belum punya akun? <a href="register.php">Daftar sekarang</a>
                </p>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
