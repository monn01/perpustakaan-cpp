-- ============================================================
-- DATABASE: PERPUSTAKAAN DIGITAL
-- Sistem Manajemen Perpustakaan Berbasis Web
-- ============================================================

-- Buat database
CREATE DATABASE IF NOT EXISTS perpustakaan_db;
USE perpustakaan_db;

-- ============================================================
-- TABEL: users
-- Menyimpan data pengguna (admin & member)
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    no_telp VARCHAR(20),
    alamat TEXT,
    foto_profil VARCHAR(255) DEFAULT 'default.png',
    role ENUM('admin', 'user') DEFAULT 'user',
    status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABEL: kategori
-- Menyimpan kategori buku
-- ============================================================
CREATE TABLE IF NOT EXISTS kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(50) NOT NULL UNIQUE,
    deskripsi TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABEL: buku
-- Menyimpan data buku perpustakaan
-- ============================================================
CREATE TABLE IF NOT EXISTS buku (
    id INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) UNIQUE,
    judul VARCHAR(200) NOT NULL,
    penulis VARCHAR(100) NOT NULL,
    penerbit VARCHAR(100),
    tahun_terbit YEAR,
    kategori_id INT,
    deskripsi TEXT,
    cover_buku VARCHAR(255) DEFAULT 'default-book.png',
    stok INT DEFAULT 0,
    stok_tersedia INT DEFAULT 0,
    lokasi_rak VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- TABEL: peminjaman
-- Menyimpan data transaksi peminjaman buku
-- ============================================================
CREATE TABLE IF NOT EXISTS peminjaman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    buku_id INT NOT NULL,
    tanggal_pinjam DATE NOT NULL,
    tanggal_harus_kembali DATE NOT NULL,
    tanggal_kembali DATE,
    status ENUM('dipinjam', 'dikembalikan', 'terlambat') DEFAULT 'dipinjam',
    denda DECIMAL(10,2) DEFAULT 0,
    denda_dibayar BOOLEAN DEFAULT FALSE,
    tanggal_bayar_denda DATE,
    catatan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (buku_id) REFERENCES buku(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABEL: antrian
-- Menyimpan antrian reservasi buku (implementasi Queue)
-- ============================================================
CREATE TABLE IF NOT EXISTS antrian (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    buku_id INT NOT NULL,
    tanggal_daftar TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('menunggu', 'tersedia', 'dibatalkan', 'selesai') DEFAULT 'menunggu',
    notifikasi_dikirim BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (buku_id) REFERENCES buku(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABEL: activity_log
-- Menyimpan log aktivitas (implementasi Stack - LIFO)
-- ============================================================
CREATE TABLE IF NOT EXISTS activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    aktivitas VARCHAR(255) NOT NULL,
    detail TEXT,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- TABEL: pengaturan
-- Menyimpan konfigurasi sistem
-- ============================================================
CREATE TABLE IF NOT EXISTS pengaturan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_key VARCHAR(50) NOT NULL UNIQUE,
    nilai VARCHAR(255) NOT NULL,
    deskripsi TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- INDEX untuk optimasi pencarian (seperti BST di C++)
-- ============================================================
CREATE INDEX idx_buku_judul ON buku(judul);
CREATE INDEX idx_buku_penulis ON buku(penulis);
CREATE INDEX idx_buku_kategori ON buku(kategori_id);
CREATE INDEX idx_peminjaman_user ON peminjaman(user_id);
CREATE INDEX idx_peminjaman_status ON peminjaman(status);
CREATE INDEX idx_antrian_buku ON antrian(buku_id);
CREATE INDEX idx_activity_user ON activity_log(user_id);

-- ============================================================
-- DATA AWAL: Pengaturan default
-- ============================================================
INSERT INTO pengaturan (nama_key, nilai, deskripsi) VALUES
('nama_perpustakaan', 'Perpustakaan Digital', 'Nama perpustakaan'),
('alamat', 'Jl. Pendidikan No. 123, Indonesia', 'Alamat perpustakaan'),
('telepon', '021-12345678', 'Nomor telepon'),
('email', 'info@perpustakaan.com', 'Email perpustakaan'),
('denda_per_hari', '3000', 'Denda keterlambatan per hari (Rupiah)'),
('durasi_pinjam', '7', 'Durasi peminjaman (hari)'),
('max_pinjam', '3', 'Maksimal buku dipinjam per user'),
('batas_denda_blokir', '15000', 'Batas denda untuk blokir peminjaman');

-- ============================================================
-- DATA AWAL: Admin default
-- Password: admin123 (hashed dengan password_hash)
-- ============================================================
INSERT INTO users (username, password, nama_lengkap, email, role, status) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@perpustakaan.com', 'admin', 'aktif');

-- ============================================================
-- DATA AWAL: Kategori buku
-- ============================================================
INSERT INTO kategori (nama_kategori, deskripsi) VALUES
('Pemrograman', 'Buku-buku tentang bahasa pemrograman dan teknologi'),
('Novel', 'Karya fiksi dan sastra'),
('Sains', 'Buku ilmu pengetahuan alam'),
('Matematika', 'Buku matematika dan statistika'),
('Sejarah', 'Buku sejarah dan kebudayaan'),
('Self-Help', 'Buku pengembangan diri'),
('Bisnis', 'Buku bisnis dan ekonomi'),
('Agama', 'Buku keagamaan'),
('Bahasa', 'Buku bahasa dan linguistik'),
('Umum', 'Buku umum lainnya');

-- ============================================================
-- DATA AWAL: Contoh buku
-- ============================================================
INSERT INTO buku (isbn, judul, penulis, penerbit, tahun_terbit, kategori_id, deskripsi, stok, stok_tersedia, lokasi_rak) VALUES
('978-602-1234-01', 'Pemrograman C++ untuk Pemula', 'Rinaldi Munir', 'Informatika', 2020, 1, 'Buku panduan belajar C++ dari dasar hingga mahir', 5, 5, 'A-01'),
('978-602-1234-02', 'Struktur Data dan Algoritma', 'Thomas H. Cormen', 'MIT Press', 2019, 1, 'Referensi lengkap struktur data dan algoritma', 3, 3, 'A-02'),
('978-602-1234-03', 'Laskar Pelangi', 'Andrea Hirata', 'Bentang Pustaka', 2005, 2, 'Novel inspiratif tentang pendidikan di Belitung', 4, 4, 'B-01'),
('978-602-1234-04', 'Bumi Manusia', 'Pramoedya Ananta Toer', 'Hasta Mitra', 1980, 2, 'Novel sejarah tentang perjuangan di era kolonial', 2, 2, 'B-02'),
('978-602-1234-05', 'Filosofi Teras', 'Henry Manampiring', 'Kompas', 2018, 6, 'Buku filsafat Stoa untuk kehidupan modern', 3, 3, 'C-01'),
('978-602-1234-06', 'Atomic Habits', 'James Clear', 'Gramedia', 2018, 6, 'Cara membangun kebiasaan baik dan menghilangkan yang buruk', 4, 4, 'C-02'),
('978-602-1234-07', 'Sejarah Indonesia Modern', 'M.C. Ricklefs', 'Serambi', 2008, 5, 'Sejarah Indonesia dari abad ke-19 hingga sekarang', 2, 2, 'D-01'),
('978-602-1234-08', 'Fisika Dasar', 'Halliday & Resnick', 'Erlangga', 2015, 3, 'Buku fisika dasar untuk mahasiswa', 3, 3, 'E-01'),
('978-602-1234-09', 'Kalkulus Jilid 1', 'Purcell & Varberg', 'Erlangga', 2010, 4, 'Buku kalkulus diferensial dan integral', 5, 5, 'E-02'),
('978-602-1234-10', 'Database System Concepts', 'Silberschatz', 'McGraw-Hill', 2019, 1, 'Konsep sistem basis data relasional', 3, 3, 'A-03');

-- ============================================================
-- DATA AWAL: User contoh
-- Password: user123
-- ============================================================
INSERT INTO users (username, password, nama_lengkap, email, no_telp, role, status) VALUES
('budi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Budi Santoso', 'budi@email.com', '081111111111', 'user', 'aktif'),
('ani', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ani Wijaya', 'ani@email.com', '082222222222', 'user', 'aktif');

-- ============================================================
-- VIEW: Statistik peminjaman per buku (untuk fitur "Buku Terpopuler")
-- ============================================================
CREATE OR REPLACE VIEW v_buku_populer AS
SELECT 
    b.id,
    b.judul,
    b.penulis,
    b.cover_buku,
    COUNT(p.id) as total_dipinjam
FROM buku b
LEFT JOIN peminjaman p ON b.id = p.buku_id
GROUP BY b.id
ORDER BY total_dipinjam DESC;

-- ============================================================
-- VIEW: Daftar peminjaman aktif
-- ============================================================
CREATE OR REPLACE VIEW v_peminjaman_aktif AS
SELECT 
    p.id,
    u.nama_lengkap,
    u.username,
    b.judul,
    p.tanggal_pinjam,
    p.tanggal_harus_kembali,
    DATEDIFF(CURDATE(), p.tanggal_harus_kembali) as hari_terlambat
FROM peminjaman p
JOIN users u ON p.user_id = u.id
JOIN buku b ON p.buku_id = b.id
WHERE p.status = 'dipinjam';

-- ============================================================
-- TRIGGER: Update stok_tersedia saat peminjaman
-- ============================================================
DELIMITER //

CREATE TRIGGER tr_after_pinjam
AFTER INSERT ON peminjaman
FOR EACH ROW
BEGIN
    UPDATE buku SET stok_tersedia = stok_tersedia - 1 WHERE id = NEW.buku_id;
END//

CREATE TRIGGER tr_after_kembali
AFTER UPDATE ON peminjaman
FOR EACH ROW
BEGIN
    IF NEW.status = 'dikembalikan' AND OLD.status = 'dipinjam' THEN
        UPDATE buku SET stok_tersedia = stok_tersedia + 1 WHERE id = NEW.buku_id;
    END IF;
END//

DELIMITER ;

-- ============================================================
-- Selesai! Database siap digunakan
-- ============================================================
