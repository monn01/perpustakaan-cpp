<?php
/**
 * ============================================================
 * APP CONFIG
 * Konfigurasi global aplikasi Perpustakaan Digital
 * ============================================================
 */

// Base URL aplikasi
// SESUAIKAN kalau nama folder beda
define('APP_URL', 'http://localhost/perpustakaan-web');

// Environment (optional)
define('APP_ENV', 'local'); // local | production

// Timezone
date_default_timezone_set('Asia/Jakarta');
