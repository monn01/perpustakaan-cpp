<?php
/**
 * ============================================================
 * Database Configuration
 * Perpustakaan Digital
 * ============================================================
 */

// Start session jika belum
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error reporting untuk development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Mode development atau production
define('DEV_MODE', true);

// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'perpustakaan_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Konfigurasi Aplikasi
define('APP_NAME', 'Perpustakaan Digital');
define('APP_VERSION', '1.0.0');
// APP_URL sudah didefinisikan di config/app.php

// Konfigurasi Upload
define('UPLOAD_PATH', __DIR__ . '/../assets/images/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// Konfigurasi Session
define('SESSION_LIFETIME', 3600); // 1 jam

/**
 * Class Database
 * Menggunakan PDO untuk koneksi database
 */
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            
        } catch (PDOException $e) {
            if (DEV_MODE) {
                die("Koneksi database gagal: " . $e->getMessage());
            } else {
                die("Terjadi kesalahan sistem. Silakan coba lagi nanti.");
            }
        }
    }
    
    /**
     * Singleton pattern - mendapatkan instance database
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Mendapatkan koneksi PDO
     */
    public function getConnection() {
        return $this->connection;
    }
    
    /**
     * Shortcut untuk prepare statement
     */
    public function prepare($sql) {
        return $this->connection->prepare($sql);
    }
    
    /**
     * Shortcut untuk query langsung
     */
    public function query($sql) {
        return $this->connection->query($sql);
    }
    
    /**
     * Mendapatkan last insert ID
     */
    public function lastInsertId() {
        return $this->connection->lastInsertId();
    }
    
    /**
     * Begin transaction
     */
    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }
    
    /**
     * Commit transaction
     */
    public function commit() {
        return $this->connection->commit();
    }
    
    /**
     * Rollback transaction
     */
    public function rollback() {
        return $this->connection->rollback();
    }
    
    // Mencegah cloning
    private function __clone() {}
    
    // Mencegah unserialization
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

/**
 * Helper function untuk mendapatkan koneksi database
 */
function db() {
    return Database::getInstance();
}

/**
 * Helper function untuk mendapatkan PDO connection
 */
function pdo() {
    return Database::getInstance()->getConnection();
}
?>