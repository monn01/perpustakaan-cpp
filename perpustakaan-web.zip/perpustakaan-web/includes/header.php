<?php
/**
 * ============================================================
 * HEADER.PHP
 * Template header untuk semua halaman
 * Modern Design v2.0 - Dark Navy + Vibrant Blue
 * ============================================================
 */

require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Perpustakaan Digital - Sistem Manajemen Perpustakaan Modern">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' - ' : '' ?>Perpustakaan Digital</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <!-- Custom CSS with cache buster -->
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css?v=<?= time() ?>">
    
    <style>
        /* ==================== AUTH PAGES - MODERN DARK DESIGN ==================== */
        .auth-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            /* DARK NAVY GRADIENT - VERY CONTRAST */
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 50%, #1D4ED8 100%);
            padding: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        /* Animated background blobs */
        .auth-wrapper::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(37, 99, 235, 0.3) 0%, transparent 50%);
            animation: blob1 15s ease-in-out infinite;
        }
        
        .auth-wrapper::after {
            content: '';
            position: absolute;
            bottom: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(249, 115, 22, 0.2) 0%, transparent 50%);
            animation: blob2 20s ease-in-out infinite;
        }
        
        @keyframes blob1 {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(30%, 20%) scale(1.2); }
        }
        
        @keyframes blob2 {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20%, -30%) scale(1.1); }
        }
        
        .auth-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            max-width: 1050px;
            width: 100%;
            background: #FFFFFF;
            border-radius: 2rem;
            overflow: hidden;
            box-shadow: 0 25px 80px -20px rgba(0, 0, 0, 0.5);
            position: relative;
            z-index: 10;
        }
        
        .auth-image {
            /* VIBRANT GRADIENT */
            background: linear-gradient(135deg, #1D4ED8 0%, #2563EB 50%, #3B82F6 100%);
            padding: 3rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: #FFFFFF;
            position: relative;
            overflow: hidden;
        }
        
        .auth-image::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, rgba(249, 115, 22, 0.3) 0%, transparent 40%),
                radial-gradient(circle at 80% 20%, rgba(6, 182, 212, 0.3) 0%, transparent 40%);
            pointer-events: none;
        }
        
        .auth-image h2 {
            color: #FFFFFF;
            font-size: 2.25rem;
            margin-bottom: 1rem;
            font-weight: 700;
            position: relative;
        }
        
        .auth-image p {
            opacity: 0.9;
            margin-bottom: 2rem;
            font-size: 1.0625rem;
            line-height: 1.7;
            position: relative;
        }
        
        .auth-image .illustration {
            max-width: 300px;
            margin-bottom: 2rem;
            filter: drop-shadow(0 20px 40px rgba(0,0,0,0.2));
            position: relative;
        }
        
        .auth-form-container {
            padding: 3rem;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            overflow-y: auto;
            background: #FFFFFF;
        }
        
        .auth-form-container h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            color: #0F172A;
            font-weight: 700;
        }
        
        .auth-form-container .subtitle {
            color: #64748B;
            margin-bottom: 2rem;
            font-size: 1rem;
        }
        
        .auth-form .form-group {
            margin-bottom: 1.25rem;
        }
        
        .auth-form .form-label {
            font-weight: 600;
            color: #334155;
            font-size: 0.9375rem;
            margin-bottom: 0.5rem;
            display: block;
        }
        
        .auth-form .form-control {
            padding: 0.9375rem 1rem;
            border: 2px solid #E2E8F0;
            border-radius: 0.75rem;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #F8FAFC;
        }
        
        .auth-form .form-control:focus {
            outline: none;
            border-color: #2563EB;
            background: #FFFFFF;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
        }
        
        .auth-form .input-icon {
            position: relative;
        }
        
        .auth-form .input-icon > i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #94A3B8;
            font-size: 1.25rem;
            transition: all 0.3s ease;
        }
        
        .auth-form .input-icon input:focus + i,
        .auth-form .input-icon input:focus ~ i {
            color: #2563EB;
        }
        
        .auth-form .input-icon input {
            padding-left: 3rem;
        }
        
        .auth-form .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #94A3B8;
            cursor: pointer;
            padding: 0.25rem;
            transition: all 0.3s ease;
        }
        
        .auth-form .password-toggle:hover {
            color: #2563EB;
        }
        
        .auth-form .btn {
            width: 100%;
            padding: 1rem;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 0.75rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .auth-form .btn-primary {
            background: linear-gradient(135deg, #2563EB 0%, #1D4ED8 100%);
            color: #FFFFFF;
            box-shadow: 0 10px 30px -10px rgba(37, 99, 235, 0.5);
        }
        
        .auth-form .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px -10px rgba(37, 99, 235, 0.6);
        }
        
        .auth-form .divider {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin: 1.5rem 0;
            color: #94A3B8;
            font-size: 0.875rem;
        }
        
        .auth-form .divider::before,
        .auth-form .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #E2E8F0;
        }
        
        .auth-form .auth-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #64748B;
        }
        
        .auth-form .auth-link a {
            color: #2563EB;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .auth-form .auth-link a:hover {
            color: #1D4ED8;
            text-decoration: underline;
        }
        
        .auth-form .remember-me {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
            font-size: 0.9375rem;
        }
        
        .auth-form .remember-me label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
            color: #475569;
        }
        
        .auth-form .remember-me input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #2563EB;
        }
        
        .auth-form .remember-me a {
            color: #2563EB;
            font-weight: 500;
        }
        
        .back-home {
            position: absolute;
            top: 2rem;
            left: 2rem;
            color: #FFFFFF;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 600;
            z-index: 20;
            padding: 0.75rem 1.25rem;
            background: rgba(255,255,255,0.1);
            border-radius: 0.75rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
            transition: all 0.3s ease;
        }
        
        .back-home:hover {
            background: rgba(255,255,255,0.2);
            color: #FFFFFF;
            transform: translateX(-5px);
        }
        
        /* Demo Account Box */
        .demo-box {
            margin-top: 2rem;
            padding: 1.25rem;
            background: rgba(255,255,255,0.1);
            border-radius: 1rem;
            border: 1px solid rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            position: relative;
        }
        
        .demo-box p {
            font-size: 0.875rem;
            opacity: 0.95;
            margin: 0;
            line-height: 1.6;
        }
        
        /* Alert in Auth */
        .auth-form .alert {
            padding: 1rem 1.25rem;
            border-radius: 0.75rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
            font-size: 0.9375rem;
        }
        
        .auth-form .alert-danger {
            background: #FEE2E2;
            color: #991B1B;
            border: 1px solid #FECACA;
        }
        
        .auth-form .alert-success {
            background: #D1FAE5;
            color: #065F46;
            border: 1px solid #A7F3D0;
        }
        
        /* Checklist items */
        .auth-image .checklist {
            text-align: left;
            position: relative;
        }
        
        .auth-image .checklist-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 0.875rem;
            font-size: 0.9375rem;
        }
        
        .auth-image .checklist-item i {
            font-size: 1.25rem;
            color: #34D399;
        }
        
        /* Responsive */
        @media (max-width: 900px) {
            .auth-container {
                grid-template-columns: 1fr;
                max-width: 480px;
            }
            
            .auth-image {
                display: none;
            }
            
            .auth-form-container {
                padding: 2.5rem;
            }
            
            .back-home {
                color: #FFFFFF;
                background: rgba(37, 99, 235, 0.9);
                border-color: transparent;
            }
        }
        
        @media (max-width: 480px) {
            .auth-wrapper {
                padding: 1rem;
            }
            
            .auth-form-container {
                padding: 1.5rem;
            }
            
            .auth-form-container h1 {
                font-size: 1.625rem;
            }
            
            .back-home {
                top: 1rem;
                left: 1rem;
                padding: 0.625rem 1rem;
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>