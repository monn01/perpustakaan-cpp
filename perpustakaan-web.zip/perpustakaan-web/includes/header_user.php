<?php
/**
 * ============================================================
 * HEADER_USER.PHP
 * Template header untuk halaman user (dengan sidebar)
 * ============================================================
 */

require_once __DIR__ . '/functions.php';

// Pastikan user sudah login
requireLogin();

// Ambil data user
$currentUser = getUserById($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' - ' : '' ?>Perpustakaan Digital</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
    
    <style>
        /* ==================== DASHBOARD LAYOUT ==================== */
        .dashboard-wrapper {
            display: flex;
            min-height: 100vh;
            background: var(--gray-50);
        }
        
        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            z-index: 100;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--gray-200);
        }
        
        .sidebar-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
        }
        
        .sidebar-brand i {
            font-size: 2rem;
            color: var(--primary);
        }
        
        .sidebar-brand h1 {
            font-size: 1.25rem;
            color: var(--gray-800);
            font-weight: 700;
        }
        
        .sidebar-menu {
            flex: 1;
            padding: 1rem 0;
            overflow-y: auto;
        }
        
        .menu-label {
            padding: 0.75rem 1.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-400);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .menu-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1.5rem;
            color: var(--gray-600);
            text-decoration: none;
            transition: var(--transition);
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover {
            background: var(--primary-bg);
            color: var(--primary);
        }
        
        .menu-item.active {
            background: var(--primary-bg);
            color: var(--primary);
            border-left-color: var(--primary);
            font-weight: 500;
        }
        
        .menu-item i {
            font-size: 1.25rem;
        }
        
        .menu-item .badge {
            margin-left: auto;
            background: var(--danger);
            color: var(--white);
            font-size: 0.7rem;
            padding: 0.15rem 0.5rem;
            border-radius: var(--radius-full);
        }
        
        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--gray-200);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-full);
            background: var(--primary-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-weight: 600;
        }
        
        .user-details {
            flex: 1;
            min-width: 0;
        }
        
        .user-name {
            font-weight: 500;
            color: var(--gray-800);
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .user-role {
            font-size: 0.75rem;
            color: var(--gray-500);
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            display: flex;
            flex-direction: column;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: var(--white);
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--gray-200);
            position: sticky;
            top: 0;
            z-index: 50;
        }
        
        .navbar-left {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .sidebar-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--gray-600);
            cursor: pointer;
        }
        
        .page-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--gray-800);
        }
        
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .navbar-search {
            position: relative;
        }
        
        .navbar-search input {
            width: 250px;
            padding: 0.5rem 1rem 0.5rem 2.5rem;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-full);
            font-size: 0.875rem;
            transition: var(--transition);
        }
        
        .navbar-search input:focus {
            outline: none;
            border-color: var(--primary);
            width: 300px;
        }
        
        .navbar-search i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-400);
        }
        
        .navbar-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-full);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-600);
            cursor: pointer;
            transition: var(--transition);
            position: relative;
        }
        
        .navbar-icon:hover {
            background: var(--gray-100);
            color: var(--primary);
        }
        
        .navbar-icon .notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: var(--danger);
            border-radius: 50%;
        }
        
        .user-dropdown {
            position: relative;
        }
        
        .dropdown-toggle {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
            padding: 0.25rem;
            border-radius: var(--radius);
            transition: var(--transition);
        }
        
        .dropdown-toggle:hover {
            background: var(--gray-100);
        }
        
        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 0.5rem;
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            min-width: 200px;
            padding: 0.5rem 0;
            display: none;
            z-index: 100;
        }
        
        .dropdown-menu.show {
            display: block;
        }
        
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: var(--gray-600);
            text-decoration: none;
            transition: var(--transition);
        }
        
        .dropdown-item:hover {
            background: var(--gray-50);
            color: var(--primary);
        }
        
        .dropdown-item.danger {
            color: var(--danger);
        }
        
        .dropdown-divider {
            height: 1px;
            background: var(--gray-200);
            margin: 0.5rem 0;
        }
        
        /* Content Area */
        .content-area {
            flex: 1;
            padding: 1.5rem;
        }
        
        /* Breadcrumb */
        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
            color: var(--gray-500);
            margin-bottom: 1rem;
        }
        
        .breadcrumb a {
            color: var(--gray-500);
        }
        
        .breadcrumb a:hover {
            color: var(--primary);
        }
        
        .breadcrumb .separator {
            color: var(--gray-400);
        }
        
        .breadcrumb .current {
            color: var(--gray-700);
            font-weight: 500;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-card {
            background: var(--white);
            padding: 1.5rem;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: var(--radius);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .stat-icon.blue {
            background: var(--primary-bg);
            color: var(--primary);
        }
        
        .stat-icon.green {
            background: #D1FAE5;
            color: #059669;
        }
        
        .stat-icon.yellow {
            background: #FEF3C7;
            color: #D97706;
        }
        
        .stat-icon.red {
            background: #FEE2E2;
            color: #DC2626;
        }
        
        .stat-info h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-800);
        }
        
        .stat-info p {
            font-size: 0.875rem;
            color: var(--gray-500);
        }
        
        /* Dashboard Cards */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
        }
        
        .dashboard-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
        }
        
        .card-header {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .card-header h2 {
            font-size: 1rem;
            font-weight: 600;
            color: var(--gray-800);
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        /* Mobile Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .sidebar-toggle {
                display: block;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .navbar-search {
                display: none;
            }
        }
        
        @media (max-width: 576px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .page-title {
                font-size: 1rem;
            }
        }
        
        /* Overlay for mobile */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 99;
        }
        
        .sidebar-overlay.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="dashboard-wrapper">
        <!-- Sidebar Overlay (Mobile) -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>
        
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <a href="<?= APP_URL ?>" class="sidebar-brand">
                    <i class='bx bxs-book-reader'></i>
                    <h1>Perpustakaan</h1>
                </a>
            </div>
            
            <nav class="sidebar-menu">
                <div class="menu-label">Menu Utama</div>
                <a href="<?= APP_URL ?>/user/dashboard.php" class="menu-item <?= ($pageTitle ?? '') === 'Dashboard' ? 'active' : '' ?>">
                    <i class='bx bxs-dashboard'></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?= APP_URL ?>/user/katalog.php" class="menu-item <?= ($pageTitle ?? '') === 'Katalog Buku' ? 'active' : '' ?>">
                    <i class='bx bxs-book'></i>
                    <span>Katalog Buku</span>
                </a>
                
                <div class="menu-label">Peminjaman</div>
                <a href="<?= APP_URL ?>/user/riwayat.php" class="menu-item <?= ($pageTitle ?? '') === 'Riwayat Peminjaman' ? 'active' : '' ?>">
                    <i class='bx bx-history'></i>
                    <span>Riwayat Peminjaman</span>
                </a>
                <a href="<?= APP_URL ?>/user/antrian.php" class="menu-item <?= ($pageTitle ?? '') === 'Antrian Saya' ? 'active' : '' ?>">
                    <i class='bx bx-list-ul'></i>
                    <span>Antrian Saya</span>
                </a>
                
                <div class="menu-label">Akun</div>
                <a href="<?= APP_URL ?>/user/profil.php" class="menu-item <?= ($pageTitle ?? '') === 'Profil Saya' ? 'active' : '' ?>">
                    <i class='bx bxs-user-circle'></i>
                    <span>Profil Saya</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar">
                        <?= strtoupper(substr($_SESSION['nama_lengkap'], 0, 1)) ?>
                    </div>
                    <div class="user-details">
                        <div class="user-name"><?= e($_SESSION['nama_lengkap']) ?></div>
                        <div class="user-role">Member</div>
                    </div>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Navbar -->
            <header class="top-navbar">
                <div class="navbar-left">
                    <button class="sidebar-toggle" id="sidebarToggle">
                        <i class='bx bx-menu'></i>
                    </button>
                    <h1 class="page-title"><?= e($pageTitle ?? 'Dashboard') ?></h1>
                </div>
                
                <div class="navbar-right">
                    <div class="navbar-search">
                        <i class='bx bx-search'></i>
                        <input type="text" placeholder="Cari buku..." id="globalSearch">
                    </div>
                    
                    <div class="navbar-icon">
                        <i class='bx bx-bell'></i>
                        <!-- <span class="notification-dot"></span> -->
                    </div>
                    
                    <div class="user-dropdown">
                        <div class="dropdown-toggle" id="userDropdown">
                            <div class="user-avatar">
                                <?= strtoupper(substr($_SESSION['nama_lengkap'], 0, 1)) ?>
                            </div>
                            <i class='bx bx-chevron-down'></i>
                        </div>
                        
                        <div class="dropdown-menu" id="dropdownMenu">
                            <a href="<?= APP_URL ?>/user/profil.php" class="dropdown-item">
                                <i class='bx bx-user'></i>
                                <span>Profil Saya</span>
                            </a>
                            <a href="<?= APP_URL ?>/user/riwayat.php" class="dropdown-item">
                                <i class='bx bx-history'></i>
                                <span>Riwayat</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="<?= APP_URL ?>/auth/logout.php" class="dropdown-item danger">
                                <i class='bx bx-log-out'></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- Content Area -->
            <div class="content-area">
                <?php displayFlash(); ?>
