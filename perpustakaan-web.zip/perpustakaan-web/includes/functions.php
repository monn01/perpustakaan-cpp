<?php
/**
 * ============================================================
 * FUNCTIONS.PHP
 * Helper functions untuk Perpustakaan Digital
 * ============================================================
 */

// Start session jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include config files
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

/**
 * ============================================================
 * AUTHENTICATION FUNCTIONS
 * ============================================================
 */

/**
 * Cek apakah user sudah login
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Cek apakah user adalah admin
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Cek apakah user adalah member biasa
 */
function isUser() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'user';
}

/**
 * Redirect jika belum login
 */
function requireLogin() {
    if (!isLoggedIn()) {
        setFlash('error', 'Silakan login terlebih dahulu.');
        redirect(APP_URL . '/auth/login.php');
        exit;
    }
}

/**
 * Redirect jika bukan admin
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        setFlash('error', 'Anda tidak memiliki akses ke halaman ini.');
        redirect(APP_URL . '/user/dashboard.php');
        exit;
    }
}

/**
 * Redirect jika sudah login
 */
function requireGuest() {
    if (isLoggedIn()) {
        if (isAdmin()) {
            redirect(APP_URL . '/admin/dashboard.php');
        } else {
            redirect(APP_URL . '/user/dashboard.php');
        }
        exit;
    }
}

/**
 * Login user
 */
function loginUser($username, $password) {
    $db = db();
    
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND status = 'aktif'");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['foto_profil'] = $user['foto_profil'];
        $_SESSION['login_time'] = time();
        
        // Log aktivitas
        logActivity($user['id'], 'Login', 'User melakukan login ke sistem');
        
        return true;
    }
    
    return false;
}

/**
 * Logout user
 */
function logoutUser() {
    if (isLoggedIn()) {
        logActivity($_SESSION['user_id'], 'Logout', 'User melakukan logout dari sistem');
    }
    
    // Hapus semua session
    $_SESSION = array();
    
    // Hapus session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Destroy session
    session_destroy();
}

/**
 * Register user baru (VERSI PERBAIKAN)
 */
function registerUser($data) {
    $db = db();
    
    // 1. Cek Username
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$data['username']]);
    if ($stmt->fetch()) {
        return ['success' => false, 'message' => 'Username sudah digunakan.'];
    }
    
    // 2. Bersihkan Data Kosong (Ubah "" jadi NULL)
    $email   = !empty($data['email']) ? $data['email'] : null;
    $no_telp = !empty($data['no_telp']) ? $data['no_telp'] : null;
    $alamat  = !empty($data['alamat']) ? $data['alamat'] : null;

    // 3. Cek Email (Hanya kalau diisi)
    if ($email) {
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => 'Email sudah digunakan.'];
        }
    }
    
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // 4. Insert Data
    // Pastikan tabel users punya kolom: username, password, nama_lengkap, email, no_telp, alamat, role, status
    $sql = "INSERT INTO users (username, password, nama_lengkap, email, no_telp, alamat, role, status) 
            VALUES (?, ?, ?, ?, ?, ?, 'user', 'aktif')";
            
    $stmt = $db->prepare($sql);
    
    try {
        $stmt->execute([
            $data['username'],
            $hashedPassword,
            $data['nama_lengkap'],
            $email,
            $no_telp,
            $alamat
        ]);
        
        $userId = $db->lastInsertId();
        
        // Coba log activity, kalau gagal tabelnya ngga ada, biarin aja (jangan bikin error fatal)
        try {
            logActivity($userId, 'Register', 'User baru mendaftar');
        } catch (Exception $logEx) {
            // Log error diabaikan
        }
        
        return ['success' => true, 'message' => 'Registrasi berhasil!'];
        
    } catch (PDOException $e) {
        // Return error message instead of die()
        return ['success' => false, 'message' => 'Terjadi kesalahan database: ' . $e->getMessage()];
    }
}

/**
 * ============================================================
 * FLASH MESSAGE FUNCTIONS
 * ============================================================
 */

/**
 * Set flash message
 */
function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Get dan hapus flash message
 */
function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Display flash message sebagai HTML
 */
function displayFlash() {
    $flash = getFlash();
    if ($flash) {
        $type = $flash['type'];
        $message = htmlspecialchars($flash['message']);
        $icon = $type === 'success' ? 'bx-check-circle' : ($type === 'error' ? 'bx-x-circle' : 'bx-info-circle');
        $alertType = $type === 'error' ? 'danger' : $type;
        
        echo "<div class='alert alert-{$alertType}'>";
        echo "<i class='bx {$icon}'></i> {$message}";
        echo "</div>";
    }
}

/**
 * ============================================================
 * UTILITY FUNCTIONS
 * ============================================================
 */

/**
 * Redirect ke URL tertentu
 */
function redirect($url) {
    if (!headers_sent()) {
        header("Location: $url");
        exit;
    } else {
        echo "<script>window.location.href='$url';</script>";
        exit;
    }
}

/**
 * Escape output untuk mencegah XSS
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Format tanggal ke bahasa Indonesia
 */
function formatTanggal($date, $format = 'd M Y') {
    $bulan = [
        1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
        'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
    ];
    
    $bulanFull = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    
    $timestamp = strtotime($date);
    $result = date($format, $timestamp);
    
    // Ganti nama bulan ke Indonesia
    $monthNum = date('n', $timestamp);
    $result = str_replace(date('M', $timestamp), $bulan[$monthNum], $result);
    $result = str_replace(date('F', $timestamp), $bulanFull[$monthNum], $result);
    
    return $result;
}

/**
 * Format angka ke Rupiah
 */
function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

/**
 * Generate random string
 */
function generateRandomString($length = 10) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Validasi email
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validasi username (hanya alphanumeric dan underscore)
 */
function isValidUsername($username) {
    return preg_match('/^[a-zA-Z0-9_]{4,20}$/', $username);
}

/**
 * ============================================================
 * ACTIVITY LOG FUNCTIONS
 * ============================================================
 */

/**
 * Catat aktivitas user
 */
function logActivity($userId, $aktivitas, $detail = null) {
    $db = db();
    
    $stmt = $db->prepare("
        INSERT INTO activity_log (user_id, aktivitas, detail, ip_address)
        VALUES (?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $userId,
        $aktivitas,
        $detail,
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);
}

/**
 * Ambil activity log terbaru (seperti Stack - LIFO)
 */
function getRecentActivities($limit = 10, $userId = null) {
    $db = db();
    
    $sql = "SELECT al.*, u.username, u.nama_lengkap 
            FROM activity_log al 
            LEFT JOIN users u ON al.user_id = u.id ";
    
    if ($userId) {
        $sql .= "WHERE al.user_id = ? ";
    }
    
    $sql .= "ORDER BY al.created_at DESC LIMIT ?";
    
    $stmt = $db->prepare($sql);
    
    if ($userId) {
        $stmt->execute([$userId, $limit]);
    } else {
        $stmt->execute([$limit]);
    }
    
    return $stmt->fetchAll();
}

/**
 * ============================================================
 * PENGATURAN FUNCTIONS
 * ============================================================
 */

/**
 * Ambil nilai pengaturan
 */
function getSetting($key, $default = null) {
    $db = db();
    
    $stmt = $db->prepare("SELECT nilai FROM pengaturan WHERE nama_key = ?");
    $stmt->execute([$key]);
    $result = $stmt->fetch();
    
    return $result ? $result['nilai'] : $default;
}

/**
 * Update nilai pengaturan
 */
function updateSetting($key, $value) {
    $db = db();
    
    $stmt = $db->prepare("UPDATE pengaturan SET nilai = ? WHERE nama_key = ?");
    return $stmt->execute([$value, $key]);
}

/**
 * Ambil semua pengaturan
 */
function getAllSettings() {
    $db = db();
    
    $stmt = $db->query("SELECT nama_key, nilai FROM pengaturan");
    $settings = [];
    
    while ($row = $stmt->fetch()) {
        $settings[$row['nama_key']] = $row['nilai'];
    }
    
    return $settings;
}

/**
 * ============================================================
 * USER FUNCTIONS
 * ============================================================
 */

/**
 * Ambil data user berdasarkan ID
 */
function getUserById($id) {
    $db = db();
    
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    
    return $stmt->fetch();
}

/**
 * Update profil user
 */
function updateUserProfile($userId, $data) {
    $db = db();
    
    $stmt = $db->prepare("
        UPDATE users SET 
            nama_lengkap = ?,
            email = ?,
            no_telp = ?,
            alamat = ?,
            updated_at = NOW()
        WHERE id = ?
    ");
    
    return $stmt->execute([
        $data['nama_lengkap'],
        $data['email'],
        $data['no_telp'],
        $data['alamat'],
        $userId
    ]);
}

/**
 * Ganti password user
 */
function changePassword($userId, $oldPassword, $newPassword) {
    $db = db();
    
    // Cek password lama
    $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if (!$user || !password_verify($oldPassword, $user['password'])) {
        return ['success' => false, 'message' => 'Password lama tidak sesuai.'];
    }
    
    // Update password baru
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->execute([$hashedPassword, $userId]);
    
    logActivity($userId, 'Ganti Password', 'User mengganti password');
    
    return ['success' => true, 'message' => 'Password berhasil diubah.'];
}

/**
 * ============================================================
 * STATISTIK FUNCTIONS
 * ============================================================
 */

/**
 * Hitung total buku
 */
function getTotalBuku() {
    $db = db();
    $stmt = $db->query("SELECT COUNT(*) as total FROM buku");
    return $stmt->fetch()['total'];
}

/**
 * Hitung total user
 */
function getTotalUser() {
    $db = db();
    $stmt = $db->query("SELECT COUNT(*) as total FROM users WHERE role = 'user'");
    return $stmt->fetch()['total'];
}

/**
 * Hitung total peminjaman aktif
 */
function getTotalPeminjamanAktif() {
    $db = db();
    $stmt = $db->query("SELECT COUNT(*) as total FROM peminjaman WHERE status = 'dipinjam'");
    return $stmt->fetch()['total'];
}

/**
 * Hitung total denda belum bayar
 */
function getTotalDendaBelumBayar() {
    $db = db();
    $stmt = $db->query("SELECT SUM(denda) as total FROM peminjaman WHERE denda > 0 AND denda_dibayar = 0");
    $result = $stmt->fetch();
    return $result['total'] ?? 0;
}

/**
 * ============================================================
 * CSRF PROTECTION
 * ============================================================
 */

/**
 * Generate CSRF token
 */
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validasi CSRF token
 */
function validateCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Output hidden input CSRF token
 */
function csrfField() {
    $token = generateCsrfToken();
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}
?>