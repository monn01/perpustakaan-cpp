<?php
/**
 * ============================================================
 * USER DASHBOARD
 * Halaman utama setelah login untuk user
 * ============================================================
 */

$pageTitle = 'Dashboard';
require_once '../includes/header_user.php';

// Ambil statistik user
$db = db();
$userId = $_SESSION['user_id'];

// Hitung buku yang sedang dipinjam
$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ? AND status = 'dipinjam'");
$stmt->execute([$userId]);
$bukuDipinjam = $stmt->fetch()['total'];

// Hitung total peminjaman
$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ?");
$stmt->execute([$userId]);
$totalPeminjaman = $stmt->fetch()['total'];

// Hitung total denda belum bayar
$stmt = $db->prepare("SELECT SUM(denda) as total FROM peminjaman WHERE user_id = ? AND denda > 0 AND denda_dibayar = 0");
$stmt->execute([$userId]);
$totalDenda = $stmt->fetch()['total'] ?? 0;

// Hitung antrian aktif
$stmt = $db->prepare("SELECT COUNT(*) as total FROM antrian WHERE user_id = ? AND status = 'menunggu'");
$stmt->execute([$userId]);
$totalAntrian = $stmt->fetch()['total'];

// Ambil peminjaman aktif
$stmt = $db->prepare("
    SELECT p.*, b.judul, b.penulis, b.cover_buku,
           DATEDIFF(p.tanggal_harus_kembali, CURDATE()) as sisa_hari
    FROM peminjaman p
    JOIN buku b ON p.buku_id = b.id
    WHERE p.user_id = ? AND p.status = 'dipinjam'
    ORDER BY p.tanggal_harus_kembali ASC
    LIMIT 5
");
$stmt->execute([$userId]);
$peminjamanAktif = $stmt->fetchAll();

// Ambil buku populer
$stmt = $db->query("
    SELECT b.*, k.nama_kategori,
           (SELECT COUNT(*) FROM peminjaman WHERE buku_id = b.id) as total_dipinjam
    FROM buku b
    LEFT JOIN kategori k ON b.kategori_id = k.id
    WHERE b.stok_tersedia > 0
    ORDER BY total_dipinjam DESC
    LIMIT 6
");
$bukuPopuler = $stmt->fetchAll();

// Ambil pengaturan
$maxPinjam = getSetting('max_pinjam', 3);
$dendaPerHari = getSetting('denda_per_hari', 3000);
?>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bx-book-open'></i>
        </div>
        <div class="stat-info">
            <h3><?= $bukuDipinjam ?>/<?= $maxPinjam ?></h3>
            <p>Buku Dipinjam</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-check-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalPeminjaman ?></h3>
            <p>Total Peminjaman</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class='bx bx-list-ul'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalAntrian ?></h3>
            <p>Dalam Antrian</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon <?= $totalDenda > 0 ? 'red' : 'green' ?>">
            <i class='bx bx-money'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah($totalDenda) ?></h3>
            <p>Total Denda</p>
        </div>
    </div>
</div>

<!-- Dashboard Content -->
<div class="dashboard-grid">
    <!-- Peminjaman Aktif -->
    <div class="dashboard-card">
        <div class="card-header">
            <h2><i class='bx bx-book-reader'></i> Buku yang Sedang Dipinjam</h2>
            <a href="<?= APP_URL ?>/user/riwayat.php" class="btn btn-sm btn-secondary">Lihat Semua</a>
        </div>
        <div class="card-body">
            <?php if (empty($peminjamanAktif)): ?>
                <div class="empty-state" style="text-align: center; padding: 2rem;">
                    <i class='bx bx-book' style="font-size: 4rem; color: var(--gray-300);"></i>
                    <p style="color: var(--gray-500); margin-top: 1rem;">Anda belum meminjam buku apapun.</p>
                    <a href="<?= APP_URL ?>/user/katalog.php" class="btn btn-primary btn-sm" style="margin-top: 1rem;">
                        <i class='bx bx-search'></i> Cari Buku
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Buku</th>
                                <th>Tgl Pinjam</th>
                                <th>Jatuh Tempo</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($peminjamanAktif as $p): ?>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                                            <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=50&h=70&fit=crop" 
                                                 alt="<?= e($p['judul']) ?>"
                                                 style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px;">
                                            <div>
                                                <strong style="display: block; font-size: 0.9rem;"><?= e($p['judul']) ?></strong>
                                                <small style="color: var(--gray-500);"><?= e($p['penulis']) ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?= formatTanggal($p['tanggal_pinjam']) ?></td>
                                    <td><?= formatTanggal($p['tanggal_harus_kembali']) ?></td>
                                    <td>
                                        <?php if ($p['sisa_hari'] < 0): ?>
                                            <span class="badge badge-danger">
                                                Terlambat <?= abs($p['sisa_hari']) ?> hari
                                            </span>
                                        <?php elseif ($p['sisa_hari'] <= 2): ?>
                                            <span class="badge badge-warning">
                                                <?= $p['sisa_hari'] ?> hari lagi
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-success">
                                                <?= $p['sisa_hari'] ?> hari lagi
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Info Panel -->
    <div>
        <!-- Pengingat -->
        <?php if ($totalDenda > 0): ?>
            <div class="dashboard-card" style="margin-bottom: 1.5rem; border-left: 4px solid var(--danger);">
                <div class="card-body">
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <div style="width: 50px; height: 50px; background: #FEE2E2; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <i class='bx bx-error' style="font-size: 1.5rem; color: var(--danger);"></i>
                        </div>
                        <div>
                            <h4 style="color: var(--danger); margin-bottom: 0.25rem;">Anda Memiliki Denda!</h4>
                            <p style="color: var(--gray-600); font-size: 0.9rem; margin: 0;">
                                Total: <strong><?= formatRupiah($totalDenda) ?></strong>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Quick Actions -->
        <div class="dashboard-card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <h2><i class='bx bx-zap'></i> Aksi Cepat</h2>
            </div>
            <div class="card-body">
                <a href="<?= APP_URL ?>/user/katalog.php" class="btn btn-primary" style="width: 100%; margin-bottom: 0.75rem;">
                    <i class='bx bx-search'></i> Cari Buku
                </a>
                <a href="<?= APP_URL ?>/user/riwayat.php" class="btn btn-secondary" style="width: 100%; margin-bottom: 0.75rem;">
                    <i class='bx bx-history'></i> Riwayat Saya
                </a>
                <a href="<?= APP_URL ?>/user/profil.php" class="btn btn-secondary" style="width: 100%;">
                    <i class='bx bx-user'></i> Edit Profil
                </a>
            </div>
        </div>
        
        <!-- Info Perpustakaan -->
        <div class="dashboard-card">
            <div class="card-header">
                <h2><i class='bx bx-info-circle'></i> Informasi</h2>
            </div>
            <div class="card-body">
                <div style="font-size: 0.9rem; color: var(--gray-600);">
                    <p style="margin-bottom: 0.75rem;">
                        <i class='bx bx-book' style="color: var(--primary);"></i>
                        Maksimal pinjam: <strong><?= $maxPinjam ?> buku</strong>
                    </p>
                    <p style="margin-bottom: 0.75rem;">
                        <i class='bx bx-calendar' style="color: var(--primary);"></i>
                        Durasi pinjam: <strong><?= getSetting('durasi_pinjam', 7) ?> hari</strong>
                    </p>
                    <p style="margin-bottom: 0;">
                        <i class='bx bx-money' style="color: var(--primary);"></i>
                        Denda keterlambatan: <strong><?= formatRupiah($dendaPerHari) ?>/hari</strong>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Buku Populer -->
<div class="dashboard-card" style="margin-top: 1.5rem;">
    <div class="card-header">
        <h2><i class='bx bx-trending-up'></i> Buku Populer</h2>
        <a href="<?= APP_URL ?>/user/katalog.php" class="btn btn-sm btn-secondary">Lihat Semua</a>
    </div>
    <div class="card-body">
        <div class="books-grid" style="grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));">
            <?php foreach ($bukuPopuler as $buku): ?>
                <a href="<?= APP_URL ?>/user/detail-buku.php?id=<?= $buku['id'] ?>" class="book-card" style="text-decoration: none;">
                    <div class="book-cover" style="height: 200px;">
                        <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=200&h=280&fit=crop" 
                             alt="<?= e($buku['judul']) ?>">
                        <?php if ($buku['stok_tersedia'] > 0): ?>
                            <span class="book-badge">Tersedia</span>
                        <?php else: ?>
                            <span class="book-badge unavailable">Habis</span>
                        <?php endif; ?>
                    </div>
                    <div class="book-info">
                        <h3 style="font-size: 0.9rem;"><?= e($buku['judul']) ?></h3>
                        <p class="author"><?= e($buku['penulis']) ?></p>
                        <span class="category"><?= e($buku['nama_kategori'] ?? 'Umum') ?></span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer_user.php'; ?>
