<?php
/**
 * ============================================================
 * ANTRIAN BUKU
 * Halaman antrian/reservasi buku user (Queue)
 * ============================================================
 */

$pageTitle = 'Antrian Saya';
require_once '../includes/header_user.php';

$db = db();
$userId = $_SESSION['user_id'];

// Proses aksi (daftar/batal antrian)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'daftar') {
            // Daftar antrian baru
            $bukuId = intval($_POST['buku_id'] ?? 0);
            
            // Cek apakah sudah dalam antrian
            $stmt = $db->prepare("SELECT * FROM antrian WHERE user_id = ? AND buku_id = ? AND status = 'menunggu'");
            $stmt->execute([$userId, $bukuId]);
            
            if ($stmt->fetch()) {
                setFlash('warning', 'Anda sudah dalam antrian untuk buku ini.');
            } else {
                // Cek apakah sudah pinjam buku ini
                $stmt = $db->prepare("SELECT * FROM peminjaman WHERE user_id = ? AND buku_id = ? AND status = 'dipinjam'");
                $stmt->execute([$userId, $bukuId]);
                
                if ($stmt->fetch()) {
                    setFlash('warning', 'Anda sedang meminjam buku ini.');
                } else {
                    // Tambah ke antrian
                    $stmt = $db->prepare("INSERT INTO antrian (user_id, buku_id, status) VALUES (?, ?, 'menunggu')");
                    $stmt->execute([$userId, $bukuId]);
                    
                    logActivity($userId, 'Antrian', "Masuk antrian buku ID: {$bukuId}");
                    setFlash('success', 'Berhasil masuk antrian. Anda akan diberitahu saat buku tersedia.');
                }
            }
            
        } elseif ($action === 'batal') {
            // Batalkan antrian
            $antrianId = intval($_POST['antrian_id'] ?? 0);
            
            $stmt = $db->prepare("UPDATE antrian SET status = 'dibatalkan' WHERE id = ? AND user_id = ? AND status = 'menunggu'");
            $stmt->execute([$antrianId, $userId]);
            
            if ($stmt->rowCount() > 0) {
                logActivity($userId, 'Antrian', "Membatalkan antrian ID: {$antrianId}");
                setFlash('success', 'Antrian berhasil dibatalkan.');
            } else {
                setFlash('error', 'Antrian tidak ditemukan.');
            }
        }
    }
    redirect(APP_URL . '/user/antrian.php');
}

// Ambil daftar antrian user
$stmt = $db->prepare("
    SELECT a.*, b.judul, b.penulis, b.stok_tersedia, b.cover_buku,
           (SELECT COUNT(*) FROM antrian 
            WHERE buku_id = a.buku_id 
            AND status = 'menunggu' 
            AND tanggal_daftar <= a.tanggal_daftar) as posisi_antrian,
           (SELECT COUNT(*) FROM antrian 
            WHERE buku_id = a.buku_id 
            AND status = 'menunggu') as total_antrian
    FROM antrian a
    JOIN buku b ON a.buku_id = b.id
    WHERE a.user_id = ?
    ORDER BY 
        CASE a.status 
            WHEN 'menunggu' THEN 1 
            WHEN 'tersedia' THEN 2 
            ELSE 3 
        END,
        a.tanggal_daftar DESC
");
$stmt->execute([$userId]);
$antrianList = $stmt->fetchAll();

// Hitung statistik
$totalMenunggu = 0;
$totalTersedia = 0;
foreach ($antrianList as $a) {
    if ($a['status'] === 'menunggu') $totalMenunggu++;
    if ($a['status'] === 'tersedia') $totalTersedia++;
}
?>

<!-- Stats Cards -->
<div class="stats-grid" style="grid-template-columns: repeat(3, 1fr);">
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class='bx bx-time'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalMenunggu ?></h3>
            <p>Menunggu</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-check-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalTersedia ?></h3>
            <p>Buku Tersedia</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bx-list-ul'></i>
        </div>
        <div class="stat-info">
            <h3><?= count($antrianList) ?></h3>
            <p>Total Antrian</p>
        </div>
    </div>
</div>

<!-- Info Box -->
<div class="alert alert-info" style="margin-bottom: 1.5rem;">
    <i class='bx bx-info-circle'></i>
    <strong>Cara Kerja Antrian:</strong> Saat buku yang Anda tunggu tersedia, status akan berubah menjadi "Tersedia". 
    Segera pinjam buku tersebut sebelum diambil orang lain.
</div>

<!-- Daftar Antrian -->
<div class="dashboard-card">
    <div class="card-header">
        <h2><i class='bx bx-list-ul'></i> Daftar Antrian Saya</h2>
    </div>
    <div class="card-body">
        <?php if (empty($antrianList)): ?>
            <div style="text-align: center; padding: 3rem;">
                <i class='bx bx-list-plus' style="font-size: 5rem; color: var(--gray-300);"></i>
                <h3 style="color: var(--gray-600); margin-top: 1rem;">Belum ada antrian</h3>
                <p style="color: var(--gray-500);">Anda belum mendaftar antrian untuk buku apapun</p>
                <a href="<?= APP_URL ?>/user/katalog.php" class="btn btn-primary" style="margin-top: 1rem;">
                    <i class='bx bx-search'></i> Cari Buku
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Buku</th>
                            <th>Tgl Daftar</th>
                            <th>Posisi</th>
                            <th>Stok</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($antrianList as $a): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=50&h=70&fit=crop" 
                                             alt="<?= e($a['judul']) ?>"
                                             style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px;">
                                        <div>
                                            <a href="<?= APP_URL ?>/user/detail-buku.php?id=<?= $a['buku_id'] ?>" 
                                               style="font-weight: 500; color: var(--gray-800);">
                                                <?= e($a['judul']) ?>
                                            </a>
                                            <small style="display: block; color: var(--gray-500);"><?= e($a['penulis']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= formatTanggal($a['tanggal_daftar'], 'd M Y H:i') ?></td>
                                <td>
                                    <?php if ($a['status'] === 'menunggu'): ?>
                                        <span style="font-weight: 600; color: var(--primary);">
                                            #<?= $a['posisi_antrian'] ?> dari <?= $a['total_antrian'] ?>
                                        </span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($a['stok_tersedia'] > 0): ?>
                                        <span class="badge badge-success"><?= $a['stok_tersedia'] ?> tersedia</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Habis</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($a['status'] === 'menunggu'): ?>
                                        <span class="badge badge-warning">
                                            <i class='bx bx-time'></i> Menunggu
                                        </span>
                                    <?php elseif ($a['status'] === 'tersedia'): ?>
                                        <span class="badge badge-success">
                                            <i class='bx bx-check'></i> Tersedia
                                        </span>
                                    <?php elseif ($a['status'] === 'dibatalkan'): ?>
                                        <span class="badge badge-secondary">
                                            <i class='bx bx-x'></i> Dibatalkan
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-primary">
                                            <i class='bx bx-check-double'></i> Selesai
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($a['status'] === 'menunggu'): ?>
                                        <form method="POST" action="" style="display: inline;">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="batal">
                                            <input type="hidden" name="antrian_id" value="<?= $a['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" 
                                                    onclick="return confirm('Batalkan antrian ini?')">
                                                <i class='bx bx-x'></i> Batalkan
                                            </button>
                                        </form>
                                    <?php elseif ($a['status'] === 'tersedia' || $a['stok_tersedia'] > 0): ?>
                                        <a href="<?= APP_URL ?>/user/detail-buku.php?id=<?= $a['buku_id'] ?>" 
                                           class="btn btn-success btn-sm">
                                            <i class='bx bx-book-add'></i> Pinjam Sekarang
                                        </a>
                                    <?php else: ?>
                                        <span style="color: var(--gray-400);">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer_user.php'; ?>
