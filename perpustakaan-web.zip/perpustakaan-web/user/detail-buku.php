<?php
/**
 * ============================================================
 * DETAIL BUKU
 * Halaman detail buku dengan fitur pinjam/reservasi
 * ============================================================
 */

$pageTitle = 'Detail Buku';
require_once '../includes/header_user.php';

$db = db();
$userId = $_SESSION['user_id'];

// Ambil ID buku
$bukuId = intval($_GET['id'] ?? 0);

if (!$bukuId) {
    setFlash('error', 'Buku tidak ditemukan.');
    redirect(APP_URL . '/user/katalog.php');
}

// Ambil data buku
$stmt = $db->prepare("
    SELECT b.*, k.nama_kategori
    FROM buku b
    LEFT JOIN kategori k ON b.kategori_id = k.id
    WHERE b.id = ?
");
$stmt->execute([$bukuId]);
$buku = $stmt->fetch();

if (!$buku) {
    setFlash('error', 'Buku tidak ditemukan.');
    redirect(APP_URL . '/user/katalog.php');
}

// Cek apakah user sudah pinjam buku ini
$stmt = $db->prepare("SELECT * FROM peminjaman WHERE user_id = ? AND buku_id = ? AND status = 'dipinjam'");
$stmt->execute([$userId, $bukuId]);
$sudahPinjam = $stmt->fetch();

// Cek apakah user sudah dalam antrian
$stmt = $db->prepare("SELECT * FROM antrian WHERE user_id = ? AND buku_id = ? AND status = 'menunggu'");
$stmt->execute([$userId, $bukuId]);
$sudahAntri = $stmt->fetch();

// Hitung jumlah pinjaman aktif user
$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ? AND status = 'dipinjam'");
$stmt->execute([$userId]);
$jumlahPinjam = $stmt->fetch()['total'];

// Cek total denda user
$stmt = $db->prepare("SELECT SUM(denda) as total FROM peminjaman WHERE user_id = ? AND denda > 0 AND denda_dibayar = 0");
$stmt->execute([$userId]);
$totalDenda = $stmt->fetch()['total'] ?? 0;

// Ambil pengaturan
$maxPinjam = getSetting('max_pinjam', 3);
$batasDendaBlokir = getSetting('batas_denda_blokir', 15000);
$durasiPinjam = getSetting('durasi_pinjam', 7);

// Cek apakah user diblokir karena denda
$diblokir = $totalDenda >= $batasDendaBlokir;

// Hitung posisi antrian
$stmt = $db->prepare("SELECT COUNT(*) as total FROM antrian WHERE buku_id = ? AND status = 'menunggu'");
$stmt->execute([$bukuId]);
$totalAntrian = $stmt->fetch()['total'];

// Ambil buku serupa (kategori sama)
$stmt = $db->prepare("
    SELECT b.*, k.nama_kategori 
    FROM buku b
    LEFT JOIN kategori k ON b.kategori_id = k.id
    WHERE b.kategori_id = ? AND b.id != ? AND b.stok_tersedia > 0
    ORDER BY RAND()
    LIMIT 4
");
$stmt->execute([$buku['kategori_id'], $bukuId]);
$bukuSerupa = $stmt->fetchAll();
?>

<!-- Breadcrumb -->
<div class="breadcrumb">
    <a href="<?= APP_URL ?>/user/dashboard.php">Dashboard</a>
    <span class="separator">/</span>
    <a href="<?= APP_URL ?>/user/katalog.php">Katalog</a>
    <span class="separator">/</span>
    <span class="current"><?= e($buku['judul']) ?></span>
</div>

<!-- Detail Buku -->
<div class="dashboard-card">
    <div class="card-body">
        <div style="display: grid; grid-template-columns: 250px 1fr; gap: 2rem;">
            <!-- Cover Buku -->
            <div>
                <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=560&fit=crop" 
                     alt="<?= e($buku['judul']) ?>"
                     style="width: 100%; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg);">
                
                <!-- Status Badge -->
                <div style="margin-top: 1rem; text-align: center;">
                    <?php if ($buku['stok_tersedia'] > 0): ?>
                        <span class="badge badge-success" style="font-size: 0.9rem; padding: 0.5rem 1rem;">
                            <i class='bx bx-check-circle'></i> Tersedia (<?= $buku['stok_tersedia'] ?> eksemplar)
                        </span>
                    <?php else: ?>
                        <span class="badge badge-danger" style="font-size: 0.9rem; padding: 0.5rem 1rem;">
                            <i class='bx bx-x-circle'></i> Stok Habis
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Info Buku -->
            <div>
                <h1 style="font-size: 1.75rem; margin-bottom: 0.5rem;"><?= e($buku['judul']) ?></h1>
                <p style="font-size: 1.1rem; color: var(--gray-600); margin-bottom: 1.5rem;">
                    oleh <strong><?= e($buku['penulis']) ?></strong>
                </p>
                
                <!-- Detail Info -->
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 1.5rem;">
                    <div>
                        <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 0.25rem;">Kategori</p>
                        <p style="font-weight: 500;"><?= e($buku['nama_kategori'] ?? 'Umum') ?></p>
                    </div>
                    <div>
                        <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 0.25rem;">Tahun Terbit</p>
                        <p style="font-weight: 500;"><?= $buku['tahun_terbit'] ?? '-' ?></p>
                    </div>
                    <div>
                        <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 0.25rem;">Penerbit</p>
                        <p style="font-weight: 500;"><?= e($buku['penerbit'] ?? '-') ?></p>
                    </div>
                    <div>
                        <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 0.25rem;">ISBN</p>
                        <p style="font-weight: 500;"><?= e($buku['isbn'] ?? '-') ?></p>
                    </div>
                    <div>
                        <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 0.25rem;">Lokasi Rak</p>
                        <p style="font-weight: 500;"><?= e($buku['lokasi_rak'] ?? '-') ?></p>
                    </div>
                    <div>
                        <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 0.25rem;">Total Stok</p>
                        <p style="font-weight: 500;"><?= $buku['stok'] ?> eksemplar</p>
                    </div>
                </div>
                
                <!-- Deskripsi -->
                <?php if (!empty($buku['deskripsi'])): ?>
                    <div style="margin-bottom: 1.5rem;">
                        <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Deskripsi</h3>
                        <p style="color: var(--gray-600); line-height: 1.8;"><?= nl2br(e($buku['deskripsi'])) ?></p>
                    </div>
                <?php endif; ?>
                
                <!-- Action Buttons -->
                <div style="padding-top: 1.5rem; border-top: 1px solid var(--gray-200);">
                    <?php if ($sudahPinjam): ?>
                        <!-- Sudah meminjam buku ini -->
                        <div class="alert alert-info" style="margin-bottom: 1rem;">
                            <i class='bx bx-info-circle'></i>
                            Anda sedang meminjam buku ini. Jatuh tempo: <strong><?= formatTanggal($sudahPinjam['tanggal_harus_kembali']) ?></strong>
                        </div>
                        <a href="<?= APP_URL ?>/user/riwayat.php" class="btn btn-primary">
                            <i class='bx bx-history'></i> Lihat Peminjaman Saya
                        </a>
                        
                    <?php elseif ($diblokir): ?>
                        <!-- Diblokir karena denda -->
                        <div class="alert alert-danger" style="margin-bottom: 1rem;">
                            <i class='bx bx-x-circle'></i>
                            Anda tidak dapat meminjam karena memiliki denda sebesar <strong><?= formatRupiah($totalDenda) ?></strong>. 
                            Silakan bayar denda terlebih dahulu.
                        </div>
                        
                    <?php elseif ($jumlahPinjam >= $maxPinjam): ?>
                        <!-- Sudah mencapai batas pinjam -->
                        <div class="alert alert-warning" style="margin-bottom: 1rem;">
                            <i class='bx bx-error'></i>
                            Anda sudah mencapai batas maksimal peminjaman (<?= $maxPinjam ?> buku).
                        </div>
                        
                    <?php elseif ($buku['stok_tersedia'] > 0): ?>
                        <!-- Bisa pinjam -->
                        <form action="<?= APP_URL ?>/user/pinjam.php" method="POST" style="display: inline;">
                            <?= csrfField() ?>
                            <input type="hidden" name="buku_id" value="<?= $buku['id'] ?>">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class='bx bx-book-add'></i> Pinjam Buku Ini
                            </button>
                        </form>
                        <p style="margin-top: 0.75rem; color: var(--gray-500); font-size: 0.875rem;">
                            <i class='bx bx-info-circle'></i> Durasi peminjaman: <?= $durasiPinjam ?> hari
                        </p>
                        
                    <?php elseif ($sudahAntri): ?>
                        <!-- Sudah dalam antrian -->
                        <div class="alert alert-info" style="margin-bottom: 1rem;">
                            <i class='bx bx-time'></i>
                            Anda sudah dalam antrian untuk buku ini. Posisi: #<?= $sudahAntri['id'] ?>
                        </div>
                        <form action="<?= APP_URL ?>/user/antrian.php" method="POST" style="display: inline;">
                            <?= csrfField() ?>
                            <input type="hidden" name="action" value="batal">
                            <input type="hidden" name="antrian_id" value="<?= $sudahAntri['id'] ?>">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Batalkan antrian?')">
                                <i class='bx bx-x'></i> Batalkan Antrian
                            </button>
                        </form>
                        
                    <?php else: ?>
                        <!-- Stok habis, bisa masuk antrian -->
                        <div class="alert alert-warning" style="margin-bottom: 1rem;">
                            <i class='bx bx-info-circle'></i>
                            Stok buku ini sedang habis. <?php if ($totalAntrian > 0): ?>Saat ini ada <strong><?= $totalAntrian ?></strong> orang dalam antrian.<?php endif; ?>
                        </div>
                        <form action="<?= APP_URL ?>/user/antrian.php" method="POST" style="display: inline;">
                            <?= csrfField() ?>
                            <input type="hidden" name="action" value="daftar">
                            <input type="hidden" name="buku_id" value="<?= $buku['id'] ?>">
                            <button type="submit" class="btn btn-secondary btn-lg">
                                <i class='bx bx-list-plus'></i> Masuk Antrian
                            </button>
                        </form>
                        <p style="margin-top: 0.75rem; color: var(--gray-500); font-size: 0.875rem;">
                            <i class='bx bx-bell'></i> Anda akan diberitahu saat buku tersedia
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Buku Serupa -->
<?php if (!empty($bukuSerupa)): ?>
    <div class="dashboard-card" style="margin-top: 1.5rem;">
        <div class="card-header">
            <h2><i class='bx bx-book'></i> Buku Serupa</h2>
            <a href="<?= APP_URL ?>/user/katalog.php?kategori=<?= $buku['kategori_id'] ?>" class="btn btn-sm btn-secondary">
                Lihat Semua
            </a>
        </div>
        <div class="card-body">
            <div class="books-grid" style="grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));">
                <?php foreach ($bukuSerupa as $bs): ?>
                    <a href="<?= APP_URL ?>/user/detail-buku.php?id=<?= $bs['id'] ?>" class="book-card" style="text-decoration: none;">
                        <div class="book-cover" style="height: 200px;">
                            <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=200&h=280&fit=crop" 
                                 alt="<?= e($bs['judul']) ?>">
                            <span class="book-badge">Tersedia</span>
                        </div>
                        <div class="book-info">
                            <h3 style="font-size: 0.9rem;"><?= e($bs['judul']) ?></h3>
                            <p class="author"><?= e($bs['penulis']) ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<style>
    @media (max-width: 768px) {
        .dashboard-card .card-body > div {
            grid-template-columns: 1fr !important;
        }
        
        .dashboard-card .card-body > div > div:first-child {
            max-width: 200px;
            margin: 0 auto;
        }
    }
</style>

<?php require_once '../includes/footer_user.php'; ?>
