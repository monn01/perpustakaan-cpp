<?php
/**
 * ============================================================
 * PROSES PEMINJAMAN
 * Handler untuk memproses peminjaman buku
 * ============================================================
 */

require_once '../includes/functions.php';

// Pastikan sudah login
requireLogin();

// Hanya terima POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(APP_URL . '/user/katalog.php');
}

// Validasi CSRF
if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
    setFlash('error', 'Token tidak valid. Silakan coba lagi.');
    redirect(APP_URL . '/user/katalog.php');
}

$db = db();
$userId = $_SESSION['user_id'];
$bukuId = intval($_POST['buku_id'] ?? 0);

// Validasi buku
if (!$bukuId) {
    setFlash('error', 'Buku tidak valid.');
    redirect(APP_URL . '/user/katalog.php');
}

// Ambil data buku
$stmt = $db->prepare("SELECT * FROM buku WHERE id = ?");
$stmt->execute([$bukuId]);
$buku = $stmt->fetch();

if (!$buku) {
    setFlash('error', 'Buku tidak ditemukan.');
    redirect(APP_URL . '/user/katalog.php');
}

// Ambil pengaturan
$maxPinjam = getSetting('max_pinjam', 3);
$batasDendaBlokir = getSetting('batas_denda_blokir', 15000);
$durasiPinjam = getSetting('durasi_pinjam', 7);

// Cek stok
if ($buku['stok_tersedia'] <= 0) {
    setFlash('error', 'Maaf, stok buku ini sedang habis.');
    redirect(APP_URL . '/user/detail-buku.php?id=' . $bukuId);
}

// Cek apakah user sudah pinjam buku yang sama
$stmt = $db->prepare("SELECT * FROM peminjaman WHERE user_id = ? AND buku_id = ? AND status = 'dipinjam'");
$stmt->execute([$userId, $bukuId]);
if ($stmt->fetch()) {
    setFlash('error', 'Anda sudah meminjam buku ini.');
    redirect(APP_URL . '/user/detail-buku.php?id=' . $bukuId);
}

// Cek jumlah pinjaman aktif
$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ? AND status = 'dipinjam'");
$stmt->execute([$userId]);
$jumlahPinjam = $stmt->fetch()['total'];

if ($jumlahPinjam >= $maxPinjam) {
    setFlash('error', 'Anda sudah mencapai batas maksimal peminjaman (' . $maxPinjam . ' buku).');
    redirect(APP_URL . '/user/detail-buku.php?id=' . $bukuId);
}

// Cek total denda
$stmt = $db->prepare("SELECT SUM(denda) as total FROM peminjaman WHERE user_id = ? AND denda > 0 AND denda_dibayar = 0");
$stmt->execute([$userId]);
$totalDenda = $stmt->fetch()['total'] ?? 0;

if ($totalDenda >= $batasDendaBlokir) {
    setFlash('error', 'Anda tidak dapat meminjam karena memiliki denda yang belum dibayar sebesar ' . formatRupiah($totalDenda));
    redirect(APP_URL . '/user/detail-buku.php?id=' . $bukuId);
}

// Semua validasi passed, proses peminjaman
try {
    $db->beginTransaction();
    
    $tanggalPinjam = date('Y-m-d');
    $tanggalHarusKembali = date('Y-m-d', strtotime("+{$durasiPinjam} days"));
    
    // Insert peminjaman
    $stmt = $db->prepare("
        INSERT INTO peminjaman (user_id, buku_id, tanggal_pinjam, tanggal_harus_kembali, status)
        VALUES (?, ?, ?, ?, 'dipinjam')
    ");
    $stmt->execute([$userId, $bukuId, $tanggalPinjam, $tanggalHarusKembali]);
    
    // Note: stok_tersedia akan diupdate otomatis oleh TRIGGER tr_after_pinjam
    
    // Log aktivitas
    logActivity($userId, 'Peminjaman', "Meminjam buku: {$buku['judul']}");
    
    $db->commit();
    
    setFlash('success', 'Buku berhasil dipinjam! Jatuh tempo: ' . formatTanggal($tanggalHarusKembali, 'd F Y'));
    redirect(APP_URL . '/user/riwayat.php');
    
} catch (Exception $e) {
    $db->rollback();
    setFlash('error', 'Terjadi kesalahan. Silakan coba lagi.');
    redirect(APP_URL . '/user/detail-buku.php?id=' . $bukuId);
}
?>
