<?php
/**
 * ============================================================
 * KATALOG BUKU
 * Halaman katalog buku dengan pencarian dan filter
 * ============================================================
 */

$pageTitle = 'Katalog Buku';
require_once '../includes/header_user.php';

$db = db();

// Ambil parameter pencarian
$search = trim($_GET['search'] ?? '');
$kategoriId = $_GET['kategori'] ?? '';
$sortBy = $_GET['sort'] ?? 'judul';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

// Ambil semua kategori untuk filter
$stmtKat = $db->query("SELECT * FROM kategori ORDER BY nama_kategori");
$kategoriList = $stmtKat->fetchAll();

// Build query
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(b.judul LIKE ? OR b.penulis LIKE ? OR b.isbn LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($kategoriId)) {
    $where[] = "b.kategori_id = ?";
    $params[] = $kategoriId;
}

$whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Order by
$orderBy = "b.judul ASC";
switch ($sortBy) {
    case 'terbaru':
        $orderBy = "b.created_at DESC";
        break;
    case 'populer':
        $orderBy = "total_dipinjam DESC";
        break;
    case 'tahun':
        $orderBy = "b.tahun_terbit DESC";
        break;
}

// Hitung total
$countSql = "SELECT COUNT(*) as total FROM buku b {$whereClause}";
$stmtCount = $db->prepare($countSql);
$stmtCount->execute($params);
$totalBuku = $stmtCount->fetch()['total'];
$totalPages = ceil($totalBuku / $perPage);

// Ambil data buku
$sql = "
    SELECT b.*, k.nama_kategori,
           (SELECT COUNT(*) FROM peminjaman WHERE buku_id = b.id) as total_dipinjam
    FROM buku b
    LEFT JOIN kategori k ON b.kategori_id = k.id
    {$whereClause}
    ORDER BY {$orderBy}
    LIMIT {$perPage} OFFSET {$offset}
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$bukuList = $stmt->fetchAll();
?>

<!-- Search & Filter Section -->
<div class="dashboard-card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET" action="" class="d-flex gap-2" style="flex-wrap: wrap;">
            <!-- Search -->
            <div style="flex: 1; min-width: 250px;">
                <div class="input-icon" style="position: relative;">
                    <i class='bx bx-search' style="position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: var(--gray-400);"></i>
                    <input type="text" name="search" class="form-control" 
                           placeholder="Cari judul, penulis, atau ISBN..."
                           value="<?= e($search) ?>"
                           style="padding-left: 2.75rem;">
                </div>
            </div>
            
            <!-- Kategori Filter -->
            <div style="min-width: 180px;">
                <select name="kategori" class="form-control">
                    <option value="">Semua Kategori</option>
                    <?php foreach ($kategoriList as $kat): ?>
                        <option value="<?= $kat['id'] ?>" <?= $kategoriId == $kat['id'] ? 'selected' : '' ?>>
                            <?= e($kat['nama_kategori']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Sort By -->
            <div style="min-width: 150px;">
                <select name="sort" class="form-control">
                    <option value="judul" <?= $sortBy === 'judul' ? 'selected' : '' ?>>Judul A-Z</option>
                    <option value="terbaru" <?= $sortBy === 'terbaru' ? 'selected' : '' ?>>Terbaru</option>
                    <option value="populer" <?= $sortBy === 'populer' ? 'selected' : '' ?>>Terpopuler</option>
                    <option value="tahun" <?= $sortBy === 'tahun' ? 'selected' : '' ?>>Tahun Terbit</option>
                </select>
            </div>
            
            <!-- Submit -->
            <button type="submit" class="btn btn-primary">
                <i class='bx bx-filter-alt'></i> Filter
            </button>
            
            <?php if (!empty($search) || !empty($kategoriId)): ?>
                <a href="<?= APP_URL ?>/user/katalog.php" class="btn btn-secondary">
                    <i class='bx bx-x'></i> Reset
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Results Info -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
    <p style="color: var(--gray-600); margin: 0;">
        <?php if (!empty($search)): ?>
            Hasil pencarian untuk "<strong><?= e($search) ?></strong>" - 
        <?php endif; ?>
        Menampilkan <strong><?= count($bukuList) ?></strong> dari <strong><?= $totalBuku ?></strong> buku
    </p>
</div>

<!-- Books Grid -->
<?php if (empty($bukuList)): ?>
    <div class="dashboard-card">
        <div class="card-body" style="text-align: center; padding: 3rem;">
            <i class='bx bx-search-alt' style="font-size: 5rem; color: var(--gray-300);"></i>
            <h3 style="color: var(--gray-600); margin-top: 1rem;">Buku tidak ditemukan</h3>
            <p style="color: var(--gray-500);">Coba ubah kata kunci pencarian atau filter Anda</p>
            <a href="<?= APP_URL ?>/user/katalog.php" class="btn btn-primary" style="margin-top: 1rem;">
                <i class='bx bx-refresh'></i> Lihat Semua Buku
            </a>
        </div>
    </div>
<?php else: ?>
    <div class="books-grid">
        <?php foreach ($bukuList as $buku): ?>
            <a href="<?= APP_URL ?>/user/detail-buku.php?id=<?= $buku['id'] ?>" class="book-card" style="text-decoration: none;">
                <div class="book-cover">
                    <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=300&h=400&fit=crop" 
                         alt="<?= e($buku['judul']) ?>">
                    <?php if ($buku['stok_tersedia'] > 0): ?>
                        <span class="book-badge">Tersedia (<?= $buku['stok_tersedia'] ?>)</span>
                    <?php else: ?>
                        <span class="book-badge unavailable">Habis</span>
                    <?php endif; ?>
                </div>
                <div class="book-info">
                    <h3><?= e($buku['judul']) ?></h3>
                    <p class="author"><?= e($buku['penulis']) ?></p>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span class="category"><?= e($buku['nama_kategori'] ?? 'Umum') ?></span>
                        <small style="color: var(--gray-400);"><?= $buku['tahun_terbit'] ?></small>
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
    
    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
        <div class="pagination" style="margin-top: 2rem;">
            <?php 
            $queryParams = $_GET;
            
            // Previous
            if ($page > 1): 
                $queryParams['page'] = $page - 1;
            ?>
                <a href="?<?= http_build_query($queryParams) ?>">
                    <i class='bx bx-chevron-left'></i>
                </a>
            <?php endif; ?>
            
            <?php
            // Page numbers
            $start = max(1, $page - 2);
            $end = min($totalPages, $page + 2);
            
            if ($start > 1): ?>
                <a href="?<?= http_build_query(array_merge($queryParams, ['page' => 1])) ?>">1</a>
                <?php if ($start > 2): ?>
                    <span>...</span>
                <?php endif; ?>
            <?php endif; ?>
            
            <?php for ($i = $start; $i <= $end; $i++): 
                $queryParams['page'] = $i;
            ?>
                <?php if ($i === $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?<?= http_build_query($queryParams) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($end < $totalPages): ?>
                <?php if ($end < $totalPages - 1): ?>
                    <span>...</span>
                <?php endif; ?>
                <a href="?<?= http_build_query(array_merge($queryParams, ['page' => $totalPages])) ?>"><?= $totalPages ?></a>
            <?php endif; ?>
            
            <?php 
            // Next
            if ($page < $totalPages): 
                $queryParams['page'] = $page + 1;
            ?>
                <a href="?<?= http_build_query($queryParams) ?>">
                    <i class='bx bx-chevron-right'></i>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php require_once '../includes/footer_user.php'; ?>
