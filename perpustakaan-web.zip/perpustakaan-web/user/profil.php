<?php
/**
 * ============================================================
 * PROFIL USER
 * Halaman edit profil dan ganti password
 * ============================================================
 */

$pageTitle = 'Profil Saya';
require_once '../includes/header_user.php';

$db = db();
$userId = $_SESSION['user_id'];

// Ambil data user lengkap
$user = getUserById($userId);

$errorProfil = '';
$errorPassword = '';
$successProfil = '';
$successPassword = '';

// Proses update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token tidak valid.');
        redirect(APP_URL . '/user/profil.php');
    }
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profil') {
        $data = [
            'nama_lengkap' => trim($_POST['nama_lengkap'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'no_telp' => trim($_POST['no_telp'] ?? ''),
            'alamat' => trim($_POST['alamat'] ?? '')
        ];
        
        // Validasi
        if (empty($data['nama_lengkap'])) {
            $errorProfil = 'Nama lengkap harus diisi.';
        } elseif (!empty($data['email']) && !isValidEmail($data['email'])) {
            $errorProfil = 'Format email tidak valid.';
        } else {
            // Cek email unik (kecuali milik sendiri)
            if (!empty($data['email'])) {
                $stmt = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $stmt->execute([$data['email'], $userId]);
                if ($stmt->fetch()) {
                    $errorProfil = 'Email sudah digunakan oleh user lain.';
                }
            }
            
            if (empty($errorProfil)) {
                if (updateUserProfile($userId, $data)) {
                    // Update session
                    $_SESSION['nama_lengkap'] = $data['nama_lengkap'];
                    
                    logActivity($userId, 'Update Profil', 'Mengupdate data profil');
                    $successProfil = 'Profil berhasil diperbarui.';
                    
                    // Refresh data user
                    $user = getUserById($userId);
                } else {
                    $errorProfil = 'Gagal memperbarui profil.';
                }
            }
        }
        
    } elseif ($action === 'change_password') {
        $oldPassword = $_POST['old_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        // Validasi
        if (empty($oldPassword)) {
            $errorPassword = 'Password lama harus diisi.';
        } elseif (empty($newPassword)) {
            $errorPassword = 'Password baru harus diisi.';
        } elseif (strlen($newPassword) < 6) {
            $errorPassword = 'Password baru minimal 6 karakter.';
        } elseif ($newPassword !== $confirmPassword) {
            $errorPassword = 'Konfirmasi password tidak cocok.';
        } else {
            $result = changePassword($userId, $oldPassword, $newPassword);
            
            if ($result['success']) {
                $successPassword = $result['message'];
            } else {
                $errorPassword = $result['message'];
            }
        }
    }
}

// Ambil statistik user
$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ?");
$stmt->execute([$userId]);
$totalPeminjaman = $stmt->fetch()['total'];

$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ? AND status = 'dipinjam'");
$stmt->execute([$userId]);
$peminjamanAktif = $stmt->fetch()['total'];

$stmt = $db->prepare("SELECT SUM(denda) as total FROM peminjaman WHERE user_id = ? AND denda > 0 AND denda_dibayar = 0");
$stmt->execute([$userId]);
$totalDenda = $stmt->fetch()['total'] ?? 0;

// Ambil aktivitas terakhir
$aktivitas = getRecentActivities(5, $userId);
?>

<div class="dashboard-grid">
    <!-- Left Column - Profile Info & Edit -->
    <div>
        <!-- Profile Card -->
        <div class="dashboard-card" style="margin-bottom: 1.5rem;">
            <div class="card-body" style="text-align: center; padding: 2rem;">
                <div style="width: 100px; height: 100px; background: var(--primary-bg); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; font-size: 2.5rem; color: var(--primary); font-weight: 600;">
                    <?= strtoupper(substr($user['nama_lengkap'], 0, 1)) ?>
                </div>
                <h2 style="margin-bottom: 0.25rem;"><?= e($user['nama_lengkap']) ?></h2>
                <p style="color: var(--gray-500); margin-bottom: 1rem;">@<?= e($user['username']) ?></p>
                
                <div style="display: flex; justify-content: center; gap: 2rem; padding: 1rem 0; border-top: 1px solid var(--gray-200); border-bottom: 1px solid var(--gray-200);">
                    <div style="text-align: center;">
                        <h3 style="color: var(--primary);"><?= $totalPeminjaman ?></h3>
                        <small style="color: var(--gray-500);">Total Pinjam</small>
                    </div>
                    <div style="text-align: center;">
                        <h3 style="color: var(--success);"><?= $peminjamanAktif ?></h3>
                        <small style="color: var(--gray-500);">Aktif</small>
                    </div>
                    <div style="text-align: center;">
                        <h3 style="color: <?= $totalDenda > 0 ? 'var(--danger)' : 'var(--success)' ?>;">
                            <?= formatRupiah($totalDenda) ?>
                        </h3>
                        <small style="color: var(--gray-500);">Denda</small>
                    </div>
                </div>
                
                <p style="color: var(--gray-500); font-size: 0.875rem; margin-top: 1rem;">
                    <i class='bx bx-calendar'></i> Bergabung sejak <?= formatTanggal($user['created_at'], 'd F Y') ?>
                </p>
            </div>
        </div>
        
        <!-- Edit Profile Form -->
        <div class="dashboard-card">
            <div class="card-header">
                <h2><i class='bx bx-user'></i> Edit Profil</h2>
            </div>
            <div class="card-body">
                <?php if ($errorProfil): ?>
                    <div class="alert alert-danger">
                        <i class='bx bx-x-circle'></i> <?= e($errorProfil) ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($successProfil): ?>
                    <div class="alert alert-success">
                        <i class='bx bx-check-circle'></i> <?= e($successProfil) ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="update_profil">
                    
                    <div class="form-group">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" value="<?= e($user['username']) ?>" disabled 
                               style="background: var(--gray-100);">
                        <small style="color: var(--gray-500);">Username tidak dapat diubah</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Nama Lengkap <span style="color: var(--danger);">*</span></label>
                        <input type="text" name="nama_lengkap" class="form-control" 
                               value="<?= e($user['nama_lengkap']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?= e($user['email'] ?? '') ?>" 
                               placeholder="contoh@email.com">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">No. Telepon</label>
                        <input type="tel" name="no_telp" class="form-control" 
                               value="<?= e($user['no_telp'] ?? '') ?>" 
                               placeholder="081234567890">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Alamat</label>
                        <textarea name="alamat" class="form-control" rows="3" 
                                  placeholder="Alamat lengkap"><?= e($user['alamat'] ?? '') ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class='bx bx-save'></i> Simpan Perubahan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Right Column - Password & Activity -->
    <div>
        <!-- Change Password -->
        <div class="dashboard-card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <h2><i class='bx bx-lock'></i> Ganti Password</h2>
            </div>
            <div class="card-body">
                <?php if ($errorPassword): ?>
                    <div class="alert alert-danger">
                        <i class='bx bx-x-circle'></i> <?= e($errorPassword) ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($successPassword): ?>
                    <div class="alert alert-success">
                        <i class='bx bx-check-circle'></i> <?= e($successPassword) ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="form-group">
                        <label class="form-label">Password Lama</label>
                        <input type="password" name="old_password" class="form-control" 
                               placeholder="Masukkan password lama" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password Baru</label>
                        <input type="password" name="new_password" class="form-control" 
                               placeholder="Minimal 6 karakter" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_password" class="form-control" 
                               placeholder="Ulangi password baru" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class='bx bx-key'></i> Ganti Password
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Recent Activity -->
        <div class="dashboard-card">
            <div class="card-header">
                <h2><i class='bx bx-history'></i> Aktivitas Terakhir</h2>
            </div>
            <div class="card-body">
                <?php if (empty($aktivitas)): ?>
                    <p style="color: var(--gray-500); text-align: center; padding: 1rem;">
                        Belum ada aktivitas
                    </p>
                <?php else: ?>
                    <div style="display: flex; flex-direction: column; gap: 1rem;">
                        <?php foreach ($aktivitas as $a): ?>
                            <div style="display: flex; gap: 1rem; padding-bottom: 1rem; border-bottom: 1px solid var(--gray-100);">
                                <div style="width: 40px; height: 40px; background: var(--primary-bg); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                    <?php
                                    $icon = 'bx-info-circle';
                                    if (strpos($a['aktivitas'], 'Login') !== false) $icon = 'bx-log-in';
                                    elseif (strpos($a['aktivitas'], 'Logout') !== false) $icon = 'bx-log-out';
                                    elseif (strpos($a['aktivitas'], 'Peminjaman') !== false) $icon = 'bx-book-add';
                                    elseif (strpos($a['aktivitas'], 'Pengembalian') !== false) $icon = 'bx-book';
                                    elseif (strpos($a['aktivitas'], 'Profil') !== false) $icon = 'bx-user';
                                    elseif (strpos($a['aktivitas'], 'Password') !== false) $icon = 'bx-key';
                                    elseif (strpos($a['aktivitas'], 'Antrian') !== false) $icon = 'bx-list-plus';
                                    ?>
                                    <i class='bx <?= $icon ?>' style="color: var(--primary);"></i>
                                </div>
                                <div style="flex: 1; min-width: 0;">
                                    <p style="font-weight: 500; margin-bottom: 0.25rem;"><?= e($a['aktivitas']) ?></p>
                                    <?php if (!empty($a['detail'])): ?>
                                        <p style="font-size: 0.85rem; color: var(--gray-500); margin-bottom: 0.25rem;">
                                            <?= e($a['detail']) ?>
                                        </p>
                                    <?php endif; ?>
                                    <small style="color: var(--gray-400);">
                                        <?= formatTanggal($a['created_at'], 'd M Y H:i') ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer_user.php'; ?>
