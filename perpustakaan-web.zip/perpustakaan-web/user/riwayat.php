<?php
/**
 * ============================================================
 * RIWAYAT PEMINJAMAN
 * Halaman riwayat peminjaman user
 * ============================================================
 */

$pageTitle = 'Riwayat Peminjaman';
require_once '../includes/header_user.php';

$db = db();
$userId = $_SESSION['user_id'];

// Proses pengembalian buku
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'kembalikan') {
    if (validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $peminjamanId = intval($_POST['peminjaman_id'] ?? 0);
        
        // Ambil data peminjaman
        $stmt = $db->prepare("SELECT * FROM peminjaman WHERE id = ? AND user_id = ? AND status = 'dipinjam'");
        $stmt->execute([$peminjamanId, $userId]);
        $peminjaman = $stmt->fetch();
        
        if ($peminjaman) {
            $tanggalKembali = date('Y-m-d');
            $denda = 0;
            
            // Hitung denda jika terlambat
            $hariTerlambat = (strtotime($tanggalKembali) - strtotime($peminjaman['tanggal_harus_kembali'])) / (60 * 60 * 24);
            if ($hariTerlambat > 0) {
                $dendaPerHari = getSetting('denda_per_hari', 3000);
                $denda = $hariTerlambat * $dendaPerHari;
            }
            
            // Update peminjaman
            $stmt = $db->prepare("
                UPDATE peminjaman 
                SET status = 'dikembalikan', tanggal_kembali = ?, denda = ?
                WHERE id = ?
            ");
            $stmt->execute([$tanggalKembali, $denda, $peminjamanId]);
            
            // Note: stok_tersedia akan diupdate otomatis oleh TRIGGER tr_after_kembali
            
            // Log aktivitas
            logActivity($userId, 'Pengembalian', "Mengembalikan buku ID: {$peminjaman['buku_id']}");
            
            if ($denda > 0) {
                setFlash('warning', 'Buku berhasil dikembalikan. Anda dikenakan denda keterlambatan sebesar ' . formatRupiah($denda));
            } else {
                setFlash('success', 'Buku berhasil dikembalikan. Terima kasih!');
            }
        } else {
            setFlash('error', 'Data peminjaman tidak ditemukan.');
        }
    }
    redirect(APP_URL . '/user/riwayat.php');
}

// Filter
$status = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build query
$where = "p.user_id = ?";
$params = [$userId];

if ($status === 'aktif') {
    $where .= " AND p.status = 'dipinjam'";
} elseif ($status === 'selesai') {
    $where .= " AND p.status = 'dikembalikan'";
} elseif ($status === 'denda') {
    $where .= " AND p.denda > 0 AND p.denda_dibayar = 0";
}

// Hitung total
$stmtCount = $db->prepare("SELECT COUNT(*) as total FROM peminjaman p WHERE {$where}");
$stmtCount->execute($params);
$totalData = $stmtCount->fetch()['total'];
$totalPages = ceil($totalData / $perPage);

// Ambil data
$stmt = $db->prepare("
    SELECT p.*, b.judul, b.penulis, b.cover_buku,
           DATEDIFF(CURDATE(), p.tanggal_harus_kembali) as hari_terlambat
    FROM peminjaman p
    JOIN buku b ON p.buku_id = b.id
    WHERE {$where}
    ORDER BY p.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$stmt->execute($params);
$peminjamanList = $stmt->fetchAll();

// Hitung statistik
$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ? AND status = 'dipinjam'");
$stmt->execute([$userId]);
$totalAktif = $stmt->fetch()['total'];

$stmt = $db->prepare("SELECT COUNT(*) as total FROM peminjaman WHERE user_id = ? AND status = 'dikembalikan'");
$stmt->execute([$userId]);
$totalSelesai = $stmt->fetch()['total'];

$stmt = $db->prepare("SELECT SUM(denda) as total FROM peminjaman WHERE user_id = ? AND denda > 0 AND denda_dibayar = 0");
$stmt->execute([$userId]);
$totalDenda = $stmt->fetch()['total'] ?? 0;
?>

<!-- Stats Cards -->
<div class="stats-grid" style="grid-template-columns: repeat(3, 1fr);">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class='bx bx-book-open'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalAktif ?></h3>
            <p>Sedang Dipinjam</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class='bx bx-check-circle'></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalSelesai ?></h3>
            <p>Sudah Dikembalikan</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon <?= $totalDenda > 0 ? 'red' : 'green' ?>">
            <i class='bx bx-money'></i>
        </div>
        <div class="stat-info">
            <h3><?= formatRupiah($totalDenda) ?></h3>
            <p>Denda Belum Bayar</p>
        </div>
    </div>
</div>

<!-- Filter Tabs -->
<div class="dashboard-card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 0.75rem 1rem;">
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <a href="?status=" class="btn <?= empty($status) ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
                Semua
            </a>
            <a href="?status=aktif" class="btn <?= $status === 'aktif' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
                <i class='bx bx-book-open'></i> Sedang Dipinjam (<?= $totalAktif ?>)
            </a>
            <a href="?status=selesai" class="btn <?= $status === 'selesai' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
                <i class='bx bx-check'></i> Dikembalikan
            </a>
            <?php if ($totalDenda > 0): ?>
                <a href="?status=denda" class="btn <?= $status === 'denda' ? 'btn-danger' : 'btn-secondary' ?> btn-sm">
                    <i class='bx bx-error'></i> Ada Denda
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Daftar Peminjaman -->
<div class="dashboard-card">
    <div class="card-header">
        <h2><i class='bx bx-history'></i> Riwayat Peminjaman</h2>
    </div>
    <div class="card-body">
        <?php if (empty($peminjamanList)): ?>
            <div style="text-align: center; padding: 3rem;">
                <i class='bx bx-book' style="font-size: 5rem; color: var(--gray-300);"></i>
                <h3 style="color: var(--gray-600); margin-top: 1rem;">Belum ada data peminjaman</h3>
                <p style="color: var(--gray-500);">Silakan pinjam buku dari katalog</p>
                <a href="<?= APP_URL ?>/user/katalog.php" class="btn btn-primary" style="margin-top: 1rem;">
                    <i class='bx bx-search'></i> Cari Buku
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Jatuh Tempo</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                            <th>Denda</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($peminjamanList as $p): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=50&h=70&fit=crop" 
                                             alt="<?= e($p['judul']) ?>"
                                             style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px;">
                                        <div>
                                            <a href="<?= APP_URL ?>/user/detail-buku.php?id=<?= $p['buku_id'] ?>" 
                                               style="font-weight: 500; color: var(--gray-800);">
                                                <?= e($p['judul']) ?>
                                            </a>
                                            <small style="display: block; color: var(--gray-500);"><?= e($p['penulis']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= formatTanggal($p['tanggal_pinjam']) ?></td>
                                <td><?= formatTanggal($p['tanggal_harus_kembali']) ?></td>
                                <td>
                                    <?= $p['tanggal_kembali'] ? formatTanggal($p['tanggal_kembali']) : '-' ?>
                                </td>
                                <td>
                                    <?php if ($p['status'] === 'dipinjam'): ?>
                                        <?php if ($p['hari_terlambat'] > 0): ?>
                                            <span class="badge badge-danger">Terlambat <?= $p['hari_terlambat'] ?> hari</span>
                                        <?php elseif ($p['hari_terlambat'] >= -2): ?>
                                            <span class="badge badge-warning">Segera Jatuh Tempo</span>
                                        <?php else: ?>
                                            <span class="badge badge-primary">Dipinjam</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge badge-success">Dikembalikan</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['denda'] > 0): ?>
                                        <span style="color: var(--danger); font-weight: 500;">
                                            <?= formatRupiah($p['denda']) ?>
                                        </span>
                                        <?php if ($p['denda_dibayar']): ?>
                                            <span class="badge badge-success">Lunas</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Belum Bayar</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['status'] === 'dipinjam'): ?>
                                        <form method="POST" action="" style="display: inline;">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="kembalikan">
                                            <input type="hidden" name="peminjaman_id" value="<?= $p['id'] ?>">
                                            <button type="submit" class="btn btn-success btn-sm" 
                                                    onclick="return confirm('Kembalikan buku ini?')">
                                                <i class='bx bx-check'></i> Kembalikan
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <a href="<?= APP_URL ?>/user/detail-buku.php?id=<?= $p['buku_id'] ?>" 
                                           class="btn btn-secondary btn-sm">
                                            <i class='bx bx-book'></i> Pinjam Lagi
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?status=<?= $status ?>&page=<?= $page - 1 ?>">
                            <i class='bx bx-chevron-left'></i>
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <?php if ($i === $page): ?>
                            <span class="active"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?status=<?= $status ?>&page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?status=<?= $status ?>&page=<?= $page + 1 ?>">
                            <i class='bx bx-chevron-right'></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer_user.php'; ?>
