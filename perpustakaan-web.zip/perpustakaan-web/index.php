<?php
/**
 * ============================================================
 * INDEX.PHP - Landing Page
 * Perpustakaan Digital
 * ============================================================
 */
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Perpustakaan Digital - Sistem Manajemen Perpustakaan Modern">
    <title>Perpustakaan Digital - Baca, Pinjam, Kembangkan Diri</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <!-- Custom CSS with cache buster -->
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css?v=<?= time() ?>">
</head>
<body>
    <!-- ==================== NAVBAR ==================== -->
    <nav class="navbar" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-brand">
                <i class='bx bxs-book-reader' style="font-size: 2rem; color: var(--primary);"></i>
                <h1>Perpustakaan</h1>
            </a>
            
            <ul class="navbar-nav" id="navMenu">
                <li><a href="#home" class="nav-link active">Beranda</a></li>
                <li><a href="#features" class="nav-link">Fitur</a></li>
                <li><a href="#books" class="nav-link">Koleksi</a></li>
                <li><a href="#about" class="nav-link">Tentang</a></li>
                <li><a href="#contact" class="nav-link">Kontak</a></li>
            </ul>
            
            <div class="navbar-actions">
                <a href="auth/login.php" class="btn btn-secondary btn-sm">Masuk</a>
                <a href="auth/register.php" class="btn btn-primary btn-sm">Daftar</a>
                <button class="navbar-toggle" id="navToggle">
                    <i class='bx bx-menu'></i>
                </button>
            </div>
        </div>
    </nav>

    <!-- ==================== HERO SECTION ==================== -->
    <section class="hero" id="home">
        <div class="hero-container">
            <div class="hero-content"><br><br>
                <h1>Jelajahi Dunia <span>Pengetahuan</span> Tanpa Batas</h1>
                <p>Akses ribuan buku, pinjam dengan mudah, dan kembangkan dirimu bersama Perpustakaan Digital. Semua dalam genggaman tanganmu.</p>
                
                <div class="hero-buttons">
                    <a href="auth/register.php" class="btn btn-outline btn-lg">
                        <i class='bx bx-user-plus'></i>
                        Daftar Sekarang
                    </a>
                    <a href="#books" class="btn btn-primary btn-lg" style="background: white; color: var(--primary);">
                        <i class='bx bx-book-open'></i>
                        Lihat Koleksi
                    </a>
                </div>
                
                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-number">1000+</div>
                        <div class="stat-label">Koleksi Buku</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">500+</div>
                        <div class="stat-label">Anggota Aktif</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">50+</div>
                        <div class="stat-label">Kategori</div>
                    </div>
                </div>
            </div>
            
            <div class="hero-image">
                <!-- Modern Book Illustration -->
                <svg viewBox="0 0 500 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Glow effect -->
                    <defs>
                        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                            <feGaussianBlur stdDeviation="10" result="coloredBlur"/>
                            <feMerge>
                                <feMergeNode in="coloredBlur"/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    
                    <!-- Books Stack Illustration -->
                    <rect x="100" y="200" width="120" height="160" rx="8" fill="#FFF" opacity="0.9" filter="url(#glow)"/>
                    <rect x="110" y="210" width="100" height="12" rx="2" fill="#2563EB"/>
                    <rect x="110" y="232" width="80" height="6" rx="2" fill="#E2E8F0"/>
                    <rect x="110" y="248" width="90" height="6" rx="2" fill="#E2E8F0"/>
                    <rect x="110" y="264" width="70" height="6" rx="2" fill="#E2E8F0"/>
                    
                    <rect x="150" y="150" width="120" height="160" rx="8" fill="#FFF" opacity="0.95" filter="url(#glow)"/>
                    <rect x="160" y="160" width="100" height="12" rx="2" fill="#F97316"/>
                    <rect x="160" y="182" width="80" height="6" rx="2" fill="#E2E8F0"/>
                    <rect x="160" y="198" width="90" height="6" rx="2" fill="#E2E8F0"/>
                    <rect x="160" y="214" width="70" height="6" rx="2" fill="#E2E8F0"/>
                    
                    <rect x="200" y="100" width="120" height="160" rx="8" fill="#FFF" filter="url(#glow)"/>
                    <rect x="210" y="110" width="100" height="12" rx="2" fill="#10B981"/>
                    <rect x="210" y="132" width="80" height="6" rx="2" fill="#E2E8F0"/>
                    <rect x="210" y="148" width="90" height="6" rx="2" fill="#E2E8F0"/>
                    <rect x="210" y="164" width="70" height="6" rx="2" fill="#E2E8F0"/>
                    
                    <!-- Reading Person -->
                    <circle cx="380" cy="180" r="45" fill="rgba(255,255,255,0.2)"/>
                    <circle cx="380" cy="170" r="28" fill="#FFD6A5"/>
                    <rect x="348" y="200" width="64" height="85" rx="12" fill="#2563EB"/>
                    <rect x="335" y="255" width="90" height="55" rx="8" fill="#FFF" opacity="0.95"/>
                    <rect x="345" y="265" width="60" height="8" rx="2" fill="#2563EB"/>
                    <rect x="345" y="280" width="70" height="5" rx="2" fill="#E2E8F0"/>
                    <rect x="345" y="292" width="50" height="5" rx="2" fill="#E2E8F0"/>
                    
                    <!-- Floating elements -->
                    <circle cx="80" cy="120" r="8" fill="#F97316" opacity="0.6"/>
                    <circle cx="420" cy="80" r="6" fill="#10B981" opacity="0.6"/>
                    <circle cx="450" cy="320" r="10" fill="#2563EB" opacity="0.4"/>
                    <rect x="60" y="280" width="30" height="40" rx="4" fill="#FFF" opacity="0.3"/>
                    <rect x="430" cy="150" width="25" height="35" rx="4" fill="#FFF" opacity="0.3"/>
                </svg>
            </div>
        </div>
    </section>

    <!-- ==================== FEATURES SECTION ==================== -->
    <section class="features" id="features">
        <div class="container">
            <div class="section-header">
                <span class="subtitle">Fitur Unggulan</span>
                <h2>Mengapa Memilih Kami?</h2>
                <p>Nikmati berbagai kemudahan dalam mengakses dan meminjam buku dengan sistem perpustakaan digital kami</p>
            </div>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-search-alt-2'></i>
                    </div>
                    <h3>Pencarian Cepat</h3>
                    <p>Temukan buku yang kamu cari dengan mudah menggunakan fitur pencarian canggih kami</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-book-bookmark'></i>
                    </div>
                    <h3>Peminjaman Online</h3>
                    <p>Pinjam buku favorit dari mana saja tanpa perlu datang ke perpustakaan</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-bell'></i>
                    </div>
                    <h3>Notifikasi Otomatis</h3>
                    <p>Dapatkan pengingat sebelum batas waktu pengembalian buku berakhir</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-history'></i>
                    </div>
                    <h3>Riwayat Lengkap</h3>
                    <p>Lacak semua aktivitas peminjaman dan pengembalian bukumu dengan mudah</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-list-plus'></i>
                    </div>
                    <h3>Reservasi Buku</h3>
                    <p>Buku sedang dipinjam? Daftarkan dirimu dalam antrian dan dapatkan notifikasi</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-mobile-alt'></i>
                    </div>
                    <h3>Akses di Mana Saja</h3>
                    <p>Website responsive yang bisa diakses dari desktop, tablet, maupun smartphone</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ==================== BOOKS SECTION ==================== -->
    <section class="books" id="books">
        <div class="container">
            <div class="section-header">
                <span class="subtitle">Koleksi Buku</span>
                <h2>Buku Populer Minggu Ini</h2>
                <p>Jelajahi buku-buku yang paling banyak dipinjam oleh anggota kami</p>
            </div>
            
            <!-- Search Box -->
            <div class="search-box mb-5">
                <i class='bx bx-search search-icon'></i>
                <input type="text" class="form-control" placeholder="Cari judul buku, penulis, atau kategori...">
                <button class="btn btn-primary btn-sm">Cari</button>
            </div>
            
            <div class="books-grid">
                <!-- Book Card 1 -->
                <div class="book-card">
                    <div class="book-cover">
                        <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=300&h=400&fit=crop" alt="Atomic Habits">
                        <span class="book-badge">Tersedia</span>
                    </div>
                    <div class="book-info">
                        <h3>Atomic Habits</h3>
                        <p class="author">James Clear</p>
                        <span class="category">Self-Help</span>
                    </div>
                </div>
                
                <!-- Book Card 2 -->
                <div class="book-card">
                    <div class="book-cover">
                        <img src="https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=300&h=400&fit=crop" alt="Filosofi Teras">
                        <span class="book-badge">Tersedia</span>
                    </div>
                    <div class="book-info">
                        <h3>Filosofi Teras</h3>
                        <p class="author">Henry Manampiring</p>
                        <span class="category">Self-Help</span>
                    </div>
                </div>
                
                <!-- Book Card 3 -->
                <div class="book-card">
                    <div class="book-cover">
                        <img src="https://images.unsplash.com/photo-1512820790803-83ca734da794?w=300&h=400&fit=crop" alt="Laskar Pelangi">
                        <span class="book-badge unavailable">Dipinjam</span>
                    </div>
                    <div class="book-info">
                        <h3>Laskar Pelangi</h3>
                        <p class="author">Andrea Hirata</p>
                        <span class="category">Novel</span>
                    </div>
                </div>
                
                <!-- Book Card 4 -->
                <div class="book-card">
                    <div class="book-cover">
                        <img src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=300&h=400&fit=crop" alt="Struktur Data">
                        <span class="book-badge">Tersedia</span>
                    </div>
                    <div class="book-info">
                        <h3>Struktur Data & Algoritma</h3>
                        <p class="author">Thomas H. Cormen</p>
                        <span class="category">Pemrograman</span>
                    </div>
                </div>
                
                <!-- Book Card 5 -->
                <div class="book-card">
                    <div class="book-cover">
                        <img src="https://images.unsplash.com/photo-1476275466078-4007374efbbe?w=300&h=400&fit=crop" alt="Bumi Manusia">
                        <span class="book-badge">Tersedia</span>
                    </div>
                    <div class="book-info">
                        <h3>Bumi Manusia</h3>
                        <p class="author">Pramoedya Ananta Toer</p>
                        <span class="category">Novel</span>
                    </div>
                </div>
                
                <!-- Book Card 6 -->
                <div class="book-card">
                    <div class="book-cover">
                        <img src="https://images.unsplash.com/photo-1589998059171-988d887df646?w=300&h=400&fit=crop" alt="C++ Programming">
                        <span class="book-badge">Tersedia</span>
                    </div>
                    <div class="book-info">
                        <h3>Pemrograman C++</h3>
                        <p class="author">Rinaldi Munir</p>
                        <span class="category">Pemrograman</span>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <a href="auth/login.php" class="btn btn-primary btn-lg">
                    <i class='bx bx-book-open'></i>
                    Lihat Semua Koleksi
                </a>
            </div>
        </div>
    </section>

    <!-- ==================== ABOUT SECTION ==================== -->
    <section class="about bg-light" id="about">
        <div class="container">
            <div class="section-header">
                <span class="subtitle">Tentang Kami</span>
                <h2>Perpustakaan Digital Modern</h2>
                <p>Memberikan akses pengetahuan yang mudah dan nyaman untuk semua</p>
            </div>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-target-lock'></i>
                    </div>
                    <h3>Misi Kami</h3>
                    <p>Menyediakan akses literasi yang mudah, cepat, dan terjangkau untuk seluruh masyarakat Indonesia</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-bulb'></i>
                    </div>
                    <h3>Visi Kami</h3>
                    <p>Menjadi perpustakaan digital terdepan yang menginspirasi minat baca dan pengembangan diri</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class='bx bx-heart'></i>
                    </div>
                    <h3>Nilai Kami</h3>
                    <p>Keterbukaan, inovasi, dan pelayanan terbaik adalah landasan kami dalam berkarya</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ==================== CTA SECTION ==================== -->
    <section class="cta">
        <div class="container">
            <h2>Siap Memulai Perjalanan Membaca?</h2>
            <p>Bergabunglah dengan ribuan anggota lainnya dan nikmati akses ke koleksi buku terlengkap</p>
            <a href="auth/register.php" class="btn btn-outline btn-lg">
                <i class='bx bx-user-plus'></i>
                Daftar Gratis Sekarang
            </a>
        </div>
    </section>

    <!-- ==================== FOOTER ==================== -->
    <footer class="footer" id="contact">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <h3><i class='bx bxs-book-reader'></i> Perpustakaan Digital</h3>
                    <p>Sistem manajemen perpustakaan modern yang memudahkan akses literasi untuk semua kalangan.</p>
                    <div class="footer-social">
                        <a href="#"><i class='bx bxl-facebook'></i></a>
                        <a href="#"><i class='bx bxl-instagram'></i></a>
                        <a href="#"><i class='bx bxl-twitter'></i></a>
                        <a href="#"><i class='bx bxl-youtube'></i></a>
                    </div>
                </div>
                
                <div class="footer-links">
                    <h4>Tautan</h4>
                    <ul>
                        <li><a href="#home">Beranda</a></li>
                        <li><a href="#features">Fitur</a></li>
                        <li><a href="#books">Koleksi</a></li>
                        <li><a href="#about">Tentang</a></li>
                    </ul>
                </div>
                
                <div class="footer-links">
                    <h4>Layanan</h4>
                    <ul>
                        <li><a href="#">Peminjaman Buku</a></li>
                        <li><a href="#">Reservasi</a></li>
                        <li><a href="#">Perpanjangan</a></li>
                        <li><a href="#">Katalog Online</a></li>
                    </ul>
                </div>
                
                <div class="footer-links">
                    <h4>Kontak</h4>
                    <ul>
                        <li><i class='bx bx-map'></i> Jl. Pendidikan No. 123</li>
                        <li><i class='bx bx-phone'></i> (021) 12345678</li>
                        <li><i class='bx bx-envelope'></i> info@perpustakaan.com</li>
                        <li><i class='bx bx-time'></i> Sen-Jum: 08.00 - 17.00</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 Perpustakaan Digital. All rights reserved. | Dibuat dengan <i class='bx bx-heart' style="color: #EF4444;"></i> untuk Indonesia</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="assets/js/script.js"></script>
</body>
</html>